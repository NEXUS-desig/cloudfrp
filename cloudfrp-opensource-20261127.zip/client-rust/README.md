# CloudFRP Rust 启动器

基于 Rust + egui 的跨平台客户端。启动时显示旋转加载指示，数据到齐后淡入主界面。

## 功能

- 登录面板（Cookie 会话，密码不落盘）
- 隧道卡片网格 + 在线状态灯（启动/停止/删除，删除需二次确认）
- 累计上传/下载、客户端连接数、节点在线数
- 捐赠节点页（状态、CPU/内存、客户端数）
- 使用文档按钮（浏览器打开面板文档）
- 节点延迟检测（TCP 实测）
- 一键连接/断开，自动下载对应平台 frpc（多镜像）
- 每日签到（顶部按钮，签到后自动刷新积分）
- 客户端内创建隧道（名称/类型/本地端口/远程端口/节点/域名）
- 实时日志、5 秒自动刷新（原地更新，不重建列表）
- 深色主题，Windows / Linux / macOS

## 构建

需要 Rust 1.80+。

```bash
cd client-rust
cargo build --release
```

产物：

- Windows：`target/release/cloudfrp-launcher.exe`（已加 `windows_subsystem`，无黑框）
- Linux：`target/release/cloudfrp-launcher`

Linux 构建依赖（Debian/Ubuntu）：

```bash
sudo apt install -y build-essential pkg-config libxkbcommon-dev libgl1-mesa-dev \
     libx11-dev libxcursor-dev libxrandr-dev libxi-dev
```

## 运行

直接双击 exe，或命令行运行。默认面板地址 `http://127.0.0.1:3592`，可改成你的公网面板。

配置与 frpc 存放于 `~/.cloudfrp/`：

- `client-settings.json`：面板地址、用户名（不含密码）
- `frpc.toml`：当前隧道配置
- `frpc(.exe)`：自动下载的客户端

## 发布到面板

把 exe 复制到：

```
webpanel/app/static/client/CloudFRP-Launcher.exe
```

用户即可从 `http://面板:3592/static/client/CloudFRP-Launcher.exe` 下载。
