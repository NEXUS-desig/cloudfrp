#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use eframe::egui;
use serde_json::Value;
use std::collections::BTreeMap;
use std::io::{BufRead, BufReader, Cursor, Read};
use std::net::{TcpStream, ToSocketAddrs};
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

const VERSION: &str = "1.6.0";
const DEFAULT_PANEL: &str = "http://127.0.0.1:3592";
const FRP_VER: &str = "0.61.0";

const BG: egui::Color32 = egui::Color32::from_rgb(11, 22, 26);
const CARD: egui::Color32 = egui::Color32::from_rgb(16, 33, 36);
const SURFACE: egui::Color32 = egui::Color32::from_rgb(24, 47, 53);
const LINE: egui::Color32 = egui::Color32::from_rgb(35, 66, 74);
const INK: egui::Color32 = egui::Color32::from_rgb(211, 226, 228);
const MUTED: egui::Color32 = egui::Color32::from_rgb(140, 170, 176);
const FAINT: egui::Color32 = egui::Color32::from_rgb(122, 154, 160);
const ACCENT: egui::Color32 = egui::Color32::from_rgb(47, 143, 136);
const ACCENT_HOVER: egui::Color32 = egui::Color32::from_rgb(58, 163, 154);
const OK: egui::Color32 = egui::Color32::from_rgb(67, 197, 158);
const ERR: egui::Color32 = egui::Color32::from_rgb(224, 122, 116);

#[derive(Clone, Default)]
struct Tunnel {
    id: String,
    name: String,
    ttype: String,
    local_ip: String,
    local_port: u64,
    remote_port: Option<u64>,
    node_host: String,
    node_port: u64,
    status: String,
}

impl Tunnel {
    fn from_json(v: &Value) -> Self {
        let num = |k: &str| v.get(k).and_then(|x| x.as_u64()).unwrap_or(0);
        Tunnel {
            id: v.get("tunnel_id").or_else(|| v.get("id"))
                .map(|x| x.to_string().trim_matches('"').to_string())
                .unwrap_or_default(),
            name: v.get("name").and_then(|x| x.as_str()).unwrap_or("未命名").to_string(),
            ttype: v.get("type").and_then(|x| x.as_str()).unwrap_or("tcp").to_string(),
            local_ip: v.get("local_ip").and_then(|x| x.as_str()).unwrap_or("127.0.0.1").to_string(),
            local_port: num("local_port"),
            remote_port: v.get("remote_port").and_then(|x| x.as_u64()),
            node_host: v.get("node_host").and_then(|x| x.as_str()).unwrap_or("").to_string(),
            node_port: v.get("node_port").and_then(|x| x.as_u64()).unwrap_or(7000),
            status: v.get("status").and_then(|x| x.as_str()).unwrap_or("stopped").to_string(),
        }
    }

    fn online(&self) -> bool {
        matches!(self.status.as_str(), "online" | "running")
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Page {
    Tunnels,
    Nodes,
}

#[derive(Clone, Default)]
struct NodeFull {
    id: String,
    name: String,
    host: String,
    port: u64,
    status: String,
    approved: i64,
    cpu: f64,
    mem: f64,
    clients: i64,
}

#[derive(Clone, Default)]
struct NodeInfo {
    id: String,
    name: String,
    host: String,
    port: u64,
}

struct Data {
    tunnels: Vec<Tunnel>,
    user: Value,
    stats: Value,
    nodes: Value,
    levels: BTreeMap<i64, String>,
    checkin: Value,
    node_list: Vec<NodeInfo>,
    all_nodes: Vec<NodeFull>,
    server: Value,
}

#[derive(Clone)]
struct Panel {
    base: String,
    client: reqwest::blocking::Client,
}

impl Panel {
    fn login(base: &str, user: &str, pass: &str) -> Result<Panel, String> {
        let mut headers = reqwest::header::HeaderMap::new();
        headers.insert("X-CloudFRP-Client", reqwest::header::HeaderValue::from_static("launcher"));
        let client = reqwest::blocking::Client::builder()
            .cookie_store(true)
            .default_headers(headers)
            .redirect(reqwest::redirect::Policy::none())
            .timeout(Duration::from_secs(15))
            .build()
            .map_err(|e| e.to_string())?;
        let base = base.trim_end_matches('/').to_string();
        let resp = client
            .post(format!("{base}/login"))
            .form(&[
                ("username", user),
                ("password", pass),
                ("captcha", "verified"),
                ("remember", "on"),
            ])
            .send()
            .map_err(|e| format!("无法连接面板：{e}"))?;
        let code = resp.status().as_u16();
        if code >= 400 {
            return Err(format!("登录失败（HTTP {code}）"));
        }
        let panel = Panel { base, client };
        let info = panel.get("/api/user-info")?;
        if info.get("username").and_then(|v| v.as_str()).unwrap_or("").is_empty() {
            return Err("用户名或密码错误".into());
        }
        Ok(panel)
    }

    fn get(&self, path: &str) -> Result<Value, String> {
        let resp = self
            .client
            .get(format!("{}{}", self.base, path))
            .send()
            .map_err(|e| e.to_string())?;
        if !resp.status().is_success() {
            return Err(format!("HTTP {}", resp.status().as_u16()));
        }
        resp.json::<Value>().map_err(|e| e.to_string())
    }

    fn post(&self, path: &str, body: &Value) -> Result<Value, String> {
        let resp = self
            .client
            .post(format!("{}{}", self.base, path))
            .json(body)
            .send()
            .map_err(|e| e.to_string())?;
        let status = resp.status();
        let v: Value = resp.json().unwrap_or_else(|_| serde_json::json!({}));
        if status.is_success() {
            if v.get("success").and_then(|x| x.as_bool()) == Some(false) {
                return Err(v.get("message").or_else(|| v.get("error"))
                    .and_then(|x| x.as_str()).unwrap_or("请求失败").to_string());
            }
            Ok(v)
        } else {
            Err(v.get("error").or_else(|| v.get("message"))
                .and_then(|x| x.as_str()).unwrap_or("请求失败").to_string())
        }
    }

    fn delete(&self, path: &str) -> Result<(), String> {
        let resp = self
            .client
            .delete(format!("{}{}", self.base, path))
            .send()
            .map_err(|e| e.to_string())?;
        if resp.status().is_success() {
            Ok(())
        } else {
            let v: Value = resp.json().unwrap_or_else(|_| serde_json::json!({}));
            Err(v.get("error").and_then(|x| x.as_str()).unwrap_or("删除失败").to_string())
        }
    }

    fn fetch(&self) -> Result<Data, String> {
        let tunnels_json = self.get("/api/tunnels")?;
        let user = self.get("/api/user-info")?;
        let stats = self.get("/api/user/stats")?;
        let nodes = self.get("/api/nodes/stats")?;
        let levels_json = self.get("/api/membership/levels")?;
        let checkin = self.get("/api/checkin/stats")?;
        let nodes_json = self.get("/api/nodes")?;
        let server = self.get("/api/server/status")?;

        let mut tunnels = Vec::new();
        if let Some(arr) = tunnels_json.get("tunnels").and_then(|v| v.as_array()) {
            for item in arr {
                tunnels.push(Tunnel::from_json(item));
            }
        }
        let mut levels = BTreeMap::new();
        if let Some(arr) = levels_json.get("levels").and_then(|v| v.as_array()) {
            for item in arr {
                let id = item.get("id").and_then(|v| v.as_i64()).unwrap_or(0);
                let name = item.get("level_name").and_then(|v| v.as_str()).unwrap_or("");
                levels.insert(id, name.to_string());
            }
        }
        let mut node_list = Vec::new();
        let mut all_nodes = Vec::new();
        if let Some(arr) = nodes_json.get("nodes").and_then(|v| v.as_array()) {
            for item in arr {
                let approved = item.get("approved").and_then(|v| v.as_i64()).unwrap_or(0);
                let stats = item.get("stats").cloned().unwrap_or(serde_json::json!({}));
                all_nodes.push(NodeFull {
                    id: item.get("node_id").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                    name: item.get("name").and_then(|v| v.as_str()).unwrap_or("节点").to_string(),
                    host: item.get("host").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                    port: item.get("port").and_then(|v| v.as_u64()).unwrap_or(7000),
                    status: item.get("status").and_then(|v| v.as_str()).unwrap_or("offline").to_string(),
                    approved,
                    cpu: stats.get("cpu_usage").and_then(|v| v.as_f64()).unwrap_or(0.0),
                    mem: stats.get("memory_usage").and_then(|v| v.as_f64()).unwrap_or(0.0),
                    clients: stats.get("client_count").and_then(|v| v.as_i64()).unwrap_or(0),
                });
                if approved == 1 {
                    node_list.push(NodeInfo {
                        id: item.get("node_id").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                        name: item.get("name").and_then(|v| v.as_str()).unwrap_or("节点").to_string(),
                        host: item.get("host").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                        port: item.get("port").and_then(|v| v.as_u64()).unwrap_or(7000),
                    });
                }
            }
        }
        Ok(Data { tunnels, user, stats, nodes, levels, checkin, node_list, all_nodes, server })
    }

    fn tunnel_config(&self, id: &str) -> Result<String, String> {
        let v = self.get(&format!("/api/tunnels/{}/config", id))?;
        Ok(v.get("toml").and_then(|x| x.as_str()).unwrap_or("").to_string())
    }
}

enum Msg {
    LoginOk(Panel, Box<Data>),
    LoginErr(String),
    Data(Box<Data>),
    Log(String),
    Latency(Option<u128>),
    FrpcExit,
    Checked(Result<String, String>),
    Created(Result<(), String>),
    Started(Option<String>),
    Deleted(Result<(), String>),
}

enum State {
    Login,
    Loading(Instant),
    Main,
}

struct App {
    panel_url: String,
    user: String,
    pass: String,
    state: State,
    panel: Option<Panel>,
    data: Option<Data>,
    selected: Option<String>,
    tx: Sender<Msg>,
    rx: Receiver<Msg>,
    log: Vec<String>,
    latency: Option<Option<u128>>,
    runner: Arc<Mutex<Option<Child>>>,
    fade_until: Option<Instant>,
    refreshing: bool,
    last_refresh: Instant,
    err: Option<String>,
    auto_login: bool,
    auto_tried: bool,
    checkin_busy: bool,
    running_id: Option<String>,
    page: Page,
    auto_connect: Option<String>,
    auto_connect_done: bool,
    delete_target: Option<(String, String)>,
    deleting: bool,
    show_create: bool,
    creating: bool,
    f_name: String,
    f_type: String,
    f_local_ip: String,
    f_local_port: String,
    f_remote_port: String,
    f_domain: String,
    f_node: Option<String>,
    form_error: Option<String>,
}

impl App {
    fn new() -> Self {
        let (tx, rx) = channel();
        let (_, _saved_user) = load_settings();
        let panel_url = std::env::var("CLOUDFRP_PANEL")
            .unwrap_or_else(|_| DEFAULT_PANEL.to_string());
        // 默认留空，由用户填写（支持用户名或邮箱）
        let user = std::env::var("CLOUDFRP_USER").unwrap_or_default();
        let pass = std::env::var("CLOUDFRP_PASSWORD").unwrap_or_default();
        let auto_login = !pass.is_empty();
        dbg(&format!("new auto_connect={:?}", std::env::var("CLOUDFRP_AUTOCONNECT").ok()));
        App {
            panel_url,
            user,
            pass,
            state: State::Login,
            panel: None,
            data: None,
            selected: None,
            tx,
            rx,
            log: vec!["等待登录…".into()],
            latency: None,
            runner: Arc::new(Mutex::new(None)),
            fade_until: None,
            refreshing: false,
            last_refresh: Instant::now() - Duration::from_secs(60),
            err: None,
            auto_login,
            auto_tried: false,
            checkin_busy: false,
            running_id: None,
            page: if std::env::var("CLOUDFRP_PAGE").map(|v| v == "nodes").unwrap_or(false) {
                Page::Nodes
            } else {
                Page::Tunnels
            },
            auto_connect: std::env::var("CLOUDFRP_AUTOCONNECT").ok(),
            auto_connect_done: false,
            delete_target: None,
            deleting: false,
            show_create: false,
            creating: false,
            f_name: String::new(),
            f_type: "tcp".into(),
            f_local_ip: "127.0.0.1".into(),
            f_local_port: "8080".into(),
            f_remote_port: String::new(),
            f_domain: String::new(),
            f_node: None,
            form_error: None,
        }
    }

    fn log(&mut self, msg: impl Into<String>) {
        self.log.push(format!("{}  {}", now_hms(), msg.into()));
        if self.log.len() > 400 {
            self.log.remove(0);
        }
    }

    fn start_login(&mut self) {
        let url = self.panel_url.trim().to_string();
        let user = self.user.trim().to_string();
        let pass = self.pass.clone();
        if url.is_empty() || user.is_empty() || pass.is_empty() {
            self.err = Some("请填写完整".into());
            return;
        }
        self.err = None;
        self.state = State::Loading(Instant::now());
        save_settings(&url, &user);
        let tx = self.tx.clone();
        std::thread::spawn(move || match Panel::login(&url, &user, &pass) {
            Ok(panel) => match panel.fetch() {
                Ok(data) => {
                    let _ = tx.send(Msg::LoginOk(panel.clone(), Box::new(data)));
                    let _ = tx.send(Msg::Log("登录成功".into()));
                }
                Err(e) => {
                    let _ = tx.send(Msg::LoginErr(format!("读取数据失败：{e}")));
                }
            },
            Err(e) => {
                let _ = tx.send(Msg::LoginErr(e));
            }
        });
    }

    fn refresh(&mut self) {
        if self.refreshing {
            return;
        }
        let Some(panel) = self.panel.clone() else { return };
        self.refreshing = true;
        let tx = self.tx.clone();
        std::thread::spawn(move || match panel.fetch() {
            Ok(data) => {
                let _ = tx.send(Msg::Data(Box::new(data)));
            }
            Err(e) => {
                let _ = tx.send(Msg::Log(format!("刷新失败：{e}")));
            }
        });
    }

    fn selected_tunnel(&self) -> Option<&Tunnel> {
        let id = self.selected.as_ref()?;
        self.data.as_ref()?.tunnels.iter().find(|t| &t.id == id)
    }

    fn connect(&mut self) {
        let Some(t) = self.selected_tunnel().cloned() else {
            self.log("请先选择隧道");
            return;
        };
        let Some(panel) = self.panel.clone() else { return };
        let tx = self.tx.clone();
        let runner = self.runner.clone();
        dbg(&format!("connect start {}", t.name));
        self.log(format!("连接 {}", t.name));
        let tid = t.id.clone();
        self.running_id = None;
        std::thread::spawn(move || {
            let _ = tx.send(Msg::Log("正在获取隧道配置…".into()));
            let toml = match panel.tunnel_config(&t.id) {
                Ok(v) => v,
                Err(e) => {
                    let _ = tx.send(Msg::Log(format!("获取配置失败：{e}")));
                    let _ = tx.send(Msg::Started(None));
                    return;
                }
            };
            if !frpc_path().exists() {
                let _ = tx.send(Msg::Log("首次使用，正在下载 frpc（约 13MB），请稍候…".into()));
            }
            let bin = match ensure_frpc() {
                Ok(p) => p,
                Err(e) => {
                    let _ = tx.send(Msg::Log(e));
                    let _ = tx.send(Msg::Started(None));
                    return;
                }
            };
            let _ = tx.send(Msg::Log(format!("使用 frpc：{}", bin.display())));
            let dir = data_dir();
            let _ = std::fs::create_dir_all(&dir);
            let cfg = dir.join("frpc.toml");
            if let Err(e) = std::fs::write(&cfg, toml) {
                let _ = tx.send(Msg::Log(format!("写入配置失败：{e}")));
                let _ = tx.send(Msg::Started(None));
                return;
            }
            let mut cmd = Command::new(&bin);
            cmd.arg("-c").arg(&cfg)
                .stdout(Stdio::piped())
                .stderr(Stdio::piped());
            #[cfg(windows)]
            {
                use std::os::windows::process::CommandExt;
                cmd.creation_flags(0x08000000);
            }
            match cmd.spawn() {
                Ok(mut child) => {
                    let out = child.stdout.take();
                    let err = child.stderr.take();
                    *runner.lock().unwrap() = Some(child);
                    let _ = tx.send(Msg::Started(Some(tid.clone())));
                    let _ = tx.send(Msg::Log(format!("frpc 已启动：{}", bin.display())));
                    if let Some(out) = out {
                        let tx2 = tx.clone();
                        std::thread::spawn(move || {
                            for line in BufReader::new(out).lines().map_while(Result::ok) {
                                let _ = tx2.send(Msg::Log(line));
                            }
                        });
                    }
                    if let Some(err) = err {
                        let tx2 = tx.clone();
                        std::thread::spawn(move || {
                            for line in BufReader::new(err).lines().map_while(Result::ok) {
                                let _ = tx2.send(Msg::Log(line));
                            }
                        });
                    }
                }
                Err(e) => {
                    let _ = tx.send(Msg::Log(format!("启动 frpc 失败：{e}")));
                    let _ = tx.send(Msg::Started(None));
                }
            }
        });
    }

    fn disconnect(&mut self) {
        let taken = { self.runner.lock().unwrap().take() };
        match taken {
            Some(mut child) => {
                let _ = child.kill();
                self.running_id = None;
                self.log("frpc 已停止");
            }
            None => self.log("未在运行"),
        }
    }

    fn probe_latency(&mut self, host: String, port: u64) {
        let tx = self.tx.clone();
        self.latency = None;
        std::thread::spawn(move || {
            let start = Instant::now();
            let ms = format!("{host}:{port}")
                .to_socket_addrs()
                .ok()
                .and_then(|mut it| it.next())
                .and_then(|addr| TcpStream::connect_timeout(&addr, Duration::from_secs(2)).ok())
                .map(|_| start.elapsed().as_millis());
            let _ = tx.send(Msg::Latency(ms));
        });
    }


    fn checkin(&mut self) {
        if self.checkin_busy {
            return;
        }
        let Some(panel) = self.panel.clone() else { return };
        self.checkin_busy = true;
        let tx = self.tx.clone();
        std::thread::spawn(move || {
            let res = panel
                .post("/api/checkin", &serde_json::json!({}))
                .map(|v| v.get("message").and_then(|x| x.as_str()).unwrap_or("签到成功").to_string());
            let _ = tx.send(Msg::Checked(res));
        });
    }

    fn submit_create(&mut self) {
        if self.creating {
            return;
        }
        let local_port: u64 = match self.f_local_port.trim().parse() {
            Ok(v) if v > 0 => v,
            _ => {
                self.form_error = Some("本地端口无效".into());
                return;
            }
        };
        let remote_port: Option<u64> = if self.f_remote_port.trim().is_empty() {
            None
        } else {
            match self.f_remote_port.trim().parse() {
                Ok(v) if v > 0 => Some(v),
                _ => {
                    self.form_error = Some("远程端口无效（留空则自动分配）".into());
                    return;
                }
            }
        };
        let name = if self.f_name.trim().is_empty() {
            "新隧道".to_string()
        } else {
            self.f_name.trim().to_string()
        };
        let local_ip = if self.f_local_ip.trim().is_empty() {
            "127.0.0.1".to_string()
        } else {
            self.f_local_ip.trim().to_string()
        };
        let ttype = self.f_type.clone();
        let domain = self.f_domain.trim().to_string();
        let node = self.f_node.clone();
        let Some(panel) = self.panel.clone() else { return };
        self.creating = true;
        self.form_error = None;
        let tx = self.tx.clone();
        std::thread::spawn(move || {
            let mut body = serde_json::json!({
                "name": name,
                "type": ttype,
                "local_ip": local_ip,
                "local_port": local_port,
            });
            match remote_port {
                Some(rp) => body["remote_port"] = serde_json::json!(rp),
                None => {
                    let rp_path = match node.as_deref() {
                        Some(id) => format!("/api/random-port?node_id={}", id),
                        None => "/api/random-port".to_string(),
                    };
                    match panel.get(&rp_path) {
                        Ok(v) => {
                            if let Some(p) = v.get("port") {
                                body["remote_port"] = p.clone();
                            }
                        }
                        Err(e) => {
                            let _ = tx.send(Msg::Created(Err(format!("获取随机端口失败：{e}"))));
                            return;
                        }
                    }
                },
            }
            if let Some(id) = node {
                body["node_id"] = serde_json::json!(id);
            }
            if !domain.is_empty() {
                body["custom_domain"] = serde_json::json!(domain);
            }
            let res = panel.post("/api/tunnels", &body).map(|_| ());
            let _ = tx.send(Msg::Created(res));
        });
    }

    fn submit_delete(&mut self) {
        let Some((id, name)) = self.delete_target.clone() else { return };
        if self.deleting {
            return;
        }
        let Some(panel) = self.panel.clone() else { return };
        self.deleting = true;
        if self.running_id.as_deref() == Some(id.as_str()) {
            self.disconnect();
        }
        let tx = self.tx.clone();
        std::thread::spawn(move || {
            let res = panel.delete(&format!("/api/tunnels/{}", id)).map(|_| ());
            let _ = tx.send(Msg::Deleted(res));
        });
        self.log(format!("删除隧道 {}", name));
    }

    fn delete_window(&mut self, ctx: &egui::Context) {
        if self.delete_target.is_none() {
            return;
        }
        let name = self
            .delete_target
            .as_ref()
            .map(|(_, n)| n.clone())
            .unwrap_or_default();
        let mut open = true;
        egui::Window::new("删除隧道")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(360.0)
            .show(ctx, |ui| {
                ui.label(egui::RichText::new(format!(
                    "确定删除隧道「{name}」？删除后配置文件失效，无法恢复。"
                )).size(13.0).color(INK));
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    let label = if self.deleting { "删除中..." } else { "删除" };
                    let btn = egui::Button::new(egui::RichText::new(label).strong().color(INK))
                        .fill(ERR).min_size(egui::vec2(80.0, 32.0));
                    if ui.add_enabled(!self.deleting, btn).clicked() {
                        self.submit_delete();
                    }
                    if ui.add_sized([72.0, 32.0], egui::Button::new("取消")).clicked() {
                        self.delete_target = None;
                    }
                });
            });
        if !open {
            self.delete_target = None;
        }
    }

    fn create_window(&mut self, ctx: &egui::Context) {
        if !self.show_create {
            return;
        }
        let mut open = self.show_create;
        let nodes = self
            .data
            .as_ref()
            .map(|d| d.node_list.clone())
            .unwrap_or_default();
        egui::Window::new("创建隧道")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(440.0)
            .show(ctx, |ui| {
                egui::Grid::new("create_grid")
                    .num_columns(2)
                    .spacing([10.0, 8.0])
                    .show(ui, |ui| {
                        ui.label("名称");
                        ui.add(egui::TextEdit::singleline(&mut self.f_name).desired_width(270.0));
                        ui.end_row();
                        ui.label("类型");
                        egui::ComboBox::from_id_salt("ctype")
                            .selected_text(self.f_type.to_uppercase())
                            .show_ui(ui, |ui| {
                                for t in ["tcp", "udp", "http", "https"] {
                                    if ui.selectable_label(self.f_type == t, t.to_uppercase()).clicked() {
                                        self.f_type = t.to_string();
                                    }
                                }
                            });
                        ui.end_row();
                        ui.label("本地地址");
                        ui.add(egui::TextEdit::singleline(&mut self.f_local_ip).desired_width(270.0));
                        ui.end_row();
                        ui.label("本地端口");
                        ui.add(egui::TextEdit::singleline(&mut self.f_local_port).desired_width(270.0));
                        ui.end_row();
                        ui.label("远程端口");
                        ui.add(egui::TextEdit::singleline(&mut self.f_remote_port)
                            .hint_text("留空自动分配")
                            .desired_width(270.0));
                        ui.end_row();
                        ui.label("节点");
                        let selected = self
                            .f_node
                            .as_ref()
                            .and_then(|id| nodes.iter().find(|n| &n.id == id))
                            .map(|n| n.name.clone())
                            .unwrap_or_else(|| "自动（默认节点）".to_string());
                        egui::ComboBox::from_id_salt("cnode")
                            .selected_text(selected)
                            .show_ui(ui, |ui| {
                                if ui.selectable_label(self.f_node.is_none(), "自动（默认节点）").clicked() {
                                    self.f_node = None;
                                }
                                for n in &nodes {
                                    let active = self.f_node.as_deref() == Some(n.id.as_str());
                                    if ui.selectable_label(active, format!("{} · {}:{}", n.name, n.host, n.port)).clicked() {
                                        self.f_node = Some(n.id.clone());
                                    }
                                }
                            });
                        ui.end_row();
                        ui.label("自定义域名");
                        ui.add(egui::TextEdit::singleline(&mut self.f_domain)
                            .hint_text("仅 HTTP/HTTPS，可选")
                            .desired_width(270.0));
                        ui.end_row();
                    });
                if let Some(err) = &self.form_error {
                    ui.add_space(6.0);
                    ui.label(egui::RichText::new(err).color(ERR));
                }
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    let label = if self.creating { "创建中..." } else { "创建" };
                    let btn = egui::Button::new(egui::RichText::new(label).strong().color(INK))
                        .fill(ACCENT).min_size(egui::vec2(96.0, 34.0));
                    if ui.add_enabled(!self.creating, btn).clicked() {
                        self.submit_create();
                    }
                    if ui.add_sized([76.0, 34.0], egui::Button::new("取消")).clicked() {
                        self.show_create = false;
                    }
                });
            });
        self.show_create = open;
    }

    fn drain(&mut self) {
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                Msg::LoginOk(panel, data) => {
                    self.panel = Some(panel);
                    dbg(&format!("loginok tunnels={}", data.tunnels.len()));
                    self.selected = data.tunnels.first().map(|t| t.id.clone());
                    self.data = Some(*data);
                    self.state = State::Main;
                    self.fade_until = Some(Instant::now() + Duration::from_millis(420));
                    self.refreshing = false;
                    self.last_refresh = Instant::now();
                    if std::env::var("CLOUDFRP_OPEN_CREATE").is_ok() {
                        self.show_create = true;
                    }
                    if let Some(sel) = self.auto_connect.clone() {
                        if !self.auto_connect_done {
                            self.auto_connect_done = true;
                            if let Some(t) = self.data.as_ref().and_then(|d| {
                                d.tunnels.iter().find(|t| t.id == sel || t.name == sel)
                            }) {
                                dbg(&format!("autoconnect match {}", t.name));
                                self.selected = Some(t.id.clone());
                                self.connect();
                            }
                        }
                    }
                    self.select_first_latency();
                }
                Msg::LoginErr(e) => {
                    self.err = Some(e);
                    self.state = State::Login;
                }
                Msg::Data(data) => {
                    let keep = self.selected.clone();
                    self.data = Some(*data);
                    if keep.as_ref().map_or(true, |id| {
                        !self.data.as_ref().unwrap().tunnels.iter().any(|t| &t.id == id)
                    }) {
                        self.selected = self.data.as_ref().unwrap().tunnels.first().map(|t| t.id.clone());
                    }
                    self.refreshing = false;
                    self.last_refresh = Instant::now();
                }
                Msg::Log(line) => self.log(line),
                Msg::Latency(ms) => self.latency = Some(ms),
                Msg::FrpcExit => {
                    self.log("frpc 已退出");
                    *self.runner.lock().unwrap() = None;
                    self.running_id = None;
                }
                Msg::Checked(res) => {
                    self.checkin_busy = false;
                    match res {
                        Ok(msg) => self.log(msg),
                        Err(e) => self.log(format!("签到失败：{e}")),
                    }
                    self.refresh();
                }
                Msg::Started(id) => {
                    self.running_id = id;
                }
                Msg::Deleted(res) => {
                    self.deleting = false;
                    match res {
                        Ok(()) => {
                            self.delete_target = None;
                            self.log("隧道已删除");
                            self.refresh();
                        }
                        Err(e) => self.log(format!("删除失败：{e}")),
                    }
                }
                Msg::Created(res) => {
                    self.creating = false;
                    match res {
                        Ok(()) => {
                            self.show_create = false;
                            self.log("隧道创建成功");
                            self.refresh();
                        }
                        Err(e) => self.form_error = Some(e),
                    }
                }
            }
        }
    }

    fn select_first_latency(&mut self) {
        if let Some(t) = self.selected_tunnel().cloned() {
            let host = if t.node_host.is_empty() { "127.0.0.1".to_string() } else { t.node_host.clone() };
            self.probe_latency(host, t.node_port);
        }
    }

    fn level_name(&self, value: &Value) -> String {
        let raw = value.get("membership_level").cloned().unwrap_or(Value::Null);
        let mut name = match &raw {
            Value::String(s) => s.clone(),
            Value::Number(n) => n.to_string(),
            _ => String::new(),
        };
        if let Some(levels) = self.data.as_ref().map(|d| &d.levels) {
            if let Ok(id) = name.parse::<i64>() {
                if let Some(n) = levels.get(&id) {
                    name = n.clone();
                }
            }
        }
        if name.eq_ignore_ascii_case("free") || name == "免费" || name == "免费档" {
            "免费".into()
        } else if name.is_empty() {
            "免费".into()
        } else {
            name
        }
    }
}

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.drain();
        if self.auto_login && !self.auto_tried && matches!(self.state, State::Login) {
            self.auto_tried = true;
            self.start_login();
        }

        if matches!(self.state, State::Main) && !self.refreshing
            && self.last_refresh.elapsed() > Duration::from_secs(5)
        {
            self.refresh();
        }

        match self.state {
            State::Login => {
                egui::CentralPanel::default()
                    .frame(egui::Frame::default().fill(BG))
                    .show(ctx, |ui| self.login_ui(ui));
            }
            State::Loading(start) => {
                egui::CentralPanel::default()
                    .frame(egui::Frame::default().fill(BG))
                    .show(ctx, |ui| self.loading_ui(ui, start));
                ctx.request_repaint_after(Duration::from_millis(33));
            }
            State::Main => {
                self.main_ui(ctx);
                ctx.request_repaint_after(Duration::from_millis(200));
            }
        }

        if let Some(until) = self.fade_until {
            let now = Instant::now();
            if now < until {
                let remain = (until - now).as_secs_f32() / 0.42;
                let painter = ctx.layer_painter(egui::LayerId::new(
                    egui::Order::Foreground,
                    egui::Id::new("fade"),
                ));
                let rect = ctx.screen_rect();
                let alpha = (remain.clamp(0.0, 1.0) * 255.0) as u8;
                painter.rect_filled(rect, 0.0, egui::Color32::from_rgba_unmultiplied(11, 22, 26, alpha));
                ctx.request_repaint_after(Duration::from_millis(16));
            } else {
                self.fade_until = None;
            }
        }
    }
}

impl App {
    fn login_ui(&mut self, ui: &mut egui::Ui) {
        ui.vertical_centered(|ui| {
            ui.add_space(90.0);
            egui::Frame::default()
                .fill(CARD)
                .stroke(egui::Stroke::new(1.0, LINE))
                .corner_radius(16)
                .inner_margin(egui::Margin::symmetric(40, 30))
                .show(ui, |ui| {
                    ui.set_width(340.0);
                    ui.vertical_centered(|ui| {
                        ui.label(egui::RichText::new("CloudFRP").size(30.0).strong().color(INK));
                        ui.label(egui::RichText::new("FRP 内网穿透启动器").size(13.0).color(MUTED));
                    });
                    ui.add_space(18.0);
                    ui.vertical_centered(|ui| {
                        ui.label(egui::RichText::new("127.0.0.1:3592").size(12.0).color(FAINT));
                    });
                    ui.add_space(14.0);
                    label(ui, "用户名 / 邮箱");
                    ui.add(egui::TextEdit::singleline(&mut self.user)
                        .desired_width(f32::INFINITY)
                        .hint_text("用户名或邮箱"));
                    ui.add_space(10.0);
                    label(ui, "密码");
                    let pass = ui.add(egui::TextEdit::singleline(&mut self.pass)
                        .password(true)
                        .desired_width(f32::INFINITY));
                    ui.add_space(18.0);
                    let clicked = ui
                        .add_sized(
                            [ui.available_width(), 40.0],
                            egui::Button::new(egui::RichText::new("登 录").size(15.0).strong().color(INK))
                                .fill(ACCENT),
                        )
                        .clicked()
                        || (pass.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)));
                    if clicked {
                        self.start_login();
                    }
                    if let Some(err) = &self.err {
                        ui.add_space(10.0);
                        ui.label(egui::RichText::new(err).color(ERR).size(12.0));
                    }
                });
        });
    }

    fn loading_ui(&mut self, ui: &mut egui::Ui, start: Instant) {
        ui.vertical_centered(|ui| {
            ui.add_space(220.0);
            let t = start.elapsed().as_secs_f32();
            spinner(ui, t);
            ui.add_space(18.0);
            ui.label(egui::RichText::new("正在连接面板…").size(14.0).color(MUTED));
        });
    }

    fn main_ui(&mut self, ctx: &egui::Context) {
        let Some(d) = &self.data else { return };
        let tunnels = d.tunnels.clone();
        let user = d.user.clone();
        let nodes = d.nodes.clone();
        let username = user.get("username").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let points = user.get("points").and_then(|v| v.as_i64()).unwrap_or(0);
        let level = self.level_name(&user);
        let online = tunnels.iter().filter(|t| t.online()).count();
        let total = tunnels.len();
        let nodes_online = nodes.get("online_nodes").and_then(|v| v.as_i64()).unwrap_or(0);
        let nodes_total = nodes.get("total_nodes").and_then(|v| v.as_i64()).unwrap_or(0);
        let checked = d.checkin.get("streak").and_then(|v| v.as_i64()).unwrap_or(0) >= 1;

        egui::TopBottomPanel::top("top")
            .frame(egui::Frame::default().fill(CARD).inner_margin(egui::Margin::symmetric(16, 10)))
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.label(egui::RichText::new("CloudFRP").size(20.0).strong().color(INK));
                    ui.add_space(8.0);
                    ui.label(egui::RichText::new(format!("{username} · {level} · 积分 {points}")).color(MUTED));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button("刷新").clicked() {
                            self.refresh();
                        }
                        let label = if checked { "今日已签到" } else { "签到" };
                        if ui.add_enabled(!checked && !self.checkin_busy, egui::Button::new(label)).clicked() {
                            self.checkin();
                        }
                        ui.label(egui::RichText::new(format!(
                            "隧道 {total} · 在线 {online} · 节点 {nodes_online}/{nodes_total}"
                        )).color(MUTED));
                    });
                });
            });

        egui::SidePanel::left("nav")
            .resizable(false)
            .exact_width(176.0)
            .frame(egui::Frame::default().fill(CARD).inner_margin(egui::Margin::same(14)))
            .show(ctx, |ui| {
                ui.label(egui::RichText::new("CloudFRP").size(17.0).strong().color(INK));
                ui.label(egui::RichText::new("内网穿透启动器").size(11.0).color(FAINT));
                ui.add_space(20.0);
                if nav_button(ui, "隧道", self.page == Page::Tunnels) {
                    self.page = Page::Tunnels;
                }
                ui.add_space(4.0);
                if nav_button(ui, "节点", self.page == Page::Nodes) {
                    self.page = Page::Nodes;
                }
                ui.add_space(4.0);
                if nav_button(ui, "使用文档", false) {
                    open_url(&format!("{}/docs", self.panel_url));
                }
                ui.add_space(18.0);
                if ui.add_sized([ui.available_width(), 34.0],
                    egui::Button::new(egui::RichText::new("+ 新建隧道").strong().color(INK)).fill(ACCENT)).clicked() {
                    self.show_create = true;
                    self.form_error = None;
                }
                ui.with_layout(egui::Layout::bottom_up(egui::Align::LEFT), |ui| {
                    ui.label(egui::RichText::new(format!("v{VERSION}")).size(10.0).color(FAINT));
                    ui.add_space(6.0);
                    ui.label(egui::RichText::new(&username).size(12.5).color(MUTED));
                });
            });

        egui::TopBottomPanel::bottom("log")
            .resizable(true)
            .default_height(150.0)
            .frame(egui::Frame::default().fill(CARD).inner_margin(egui::Margin::same(12)))
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.label(egui::RichText::new("运行日志").size(13.0).color(MUTED));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.small_button("清空").clicked() {
                            self.log.clear();
                        }
                    });
                });
                ui.separator();
                egui::ScrollArea::vertical()
                    .stick_to_bottom(true)
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        for line in &self.log {
                            ui.label(egui::RichText::new(line).monospace().size(11.0).color(INK));
                        }
                    });
            });

        egui::CentralPanel::default()
            .frame(egui::Frame::default().fill(BG).inner_margin(egui::Margin::same(18)))
            .show(ctx, |ui| {
                let node_total = self.data.as_ref().map(|d| d.all_nodes.len()).unwrap_or(0);
                let node_online = self.data.as_ref().map(|d| {
                    d.all_nodes.iter().filter(|n| n.status == "online").count()
                }).unwrap_or(0);
                ui.horizontal(|ui| {
                    let (title, sub) = if self.page == Page::Nodes {
                        ("捐赠节点", format!("{node_total} 个 · {node_online} 在线"))
                    } else {
                        ("我的隧道", format!("{total} 条 · {online} 在线"))
                    };
                    ui.label(egui::RichText::new(title).size(19.0).strong().color(INK));
                    ui.add_space(8.0);
                    ui.label(egui::RichText::new(sub).size(12.0).color(FAINT));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let up = nodes.get("total_upload").and_then(|v| v.as_u64()).unwrap_or(0);
                        let down = nodes.get("total_download").and_then(|v| v.as_u64()).unwrap_or(0);
                        let clients = nodes.get("total_clients").and_then(|v| v.as_u64()).unwrap_or(0);
                        ui.label(egui::RichText::new(format!(
                            "累计 ↑{} · ↓{} · 连接 {}",
                            fmt_bytes(up), fmt_bytes(down), clients
                        )).size(11.5).color(FAINT));
                    });
                });
                ui.add_space(12.0);

                if self.page == Page::Tunnels {
                    let local_down = self
                        .data
                        .as_ref()
                        .map(|d| d.server.get("running").and_then(|v| v.as_bool()) == Some(false))
                        .unwrap_or(false);
                    let has_auto = tunnels.iter().any(|t| t.node_host.is_empty());
                    if has_auto && local_down {
                        egui::Frame::default()
                            .fill(egui::Color32::from_rgb(53, 29, 28))
                            .corner_radius(8)
                            .inner_margin(egui::Margin::same(10))
                            .show(ui, |ui| {
                                ui.label(egui::RichText::new(
                                    "本机 frps 未运行：使用「自动节点」的隧道无法连接。请到面板 FRPS 卡片点「启动」。",
                                ).size(12.0).color(ERR));
                            });
                        ui.add_space(10.0);
                    }
                }

                let mut act_select: Option<String> = None;
                let mut act_toggle: Option<String> = None;
                let mut act_delete: Option<(String, String)> = None;
                let running_id = self.running_id.clone();
                let selected_id = self.selected.clone();
                let latency_text = match &self.latency {
                    None => "检测中…".to_string(),
                    Some(Some(ms)) => format!("{ms} ms"),
                    Some(None) => "不可达".to_string(),
                };

                if self.page == Page::Nodes {
                    let all = self.data.as_ref().map(|d| d.all_nodes.clone()).unwrap_or_default();
                    nodes_grid(ui, &all);
                } else if tunnels.is_empty() {
                    ui.add_space(40.0);
                    ui.vertical_centered(|ui| {
                        ui.label(egui::RichText::new("还没有隧道").size(15.0).color(FAINT));
                        ui.add_space(4.0);
                        ui.label(egui::RichText::new("点击左侧「+ 新建隧道」创建第一条").size(12.0).color(FAINT));
                    });
                } else {
                    let gap = 12.0;
                    let col_w = ((ui.available_width() - gap) / 2.0).max(240.0);
                    egui::ScrollArea::vertical().show(ui, |ui| {
                        egui::Grid::new("tunnel_grid")
                            .num_columns(2)
                            .spacing([gap, gap])
                            .show(ui, |ui| {
                                for (idx, t) in tunnels.iter().enumerate() {
                                    let selected = selected_id.as_deref() == Some(t.id.as_str());
                                    let running = running_id.as_deref() == Some(t.id.as_str());
                                    ui.allocate_ui_with_layout(
                                        egui::vec2(col_w, 172.0),
                                        egui::Layout::top_down(egui::Align::LEFT),
                                        |ui| {
                                        let (sel, toggle, del) = tunnel_card(ui, t, selected, running, &latency_text);
                                        if sel {
                                            act_select = Some(t.id.clone());
                                        }
                                        if toggle {
                                            act_toggle = Some(t.id.clone());
                                        }
                                        if del {
                                            act_delete = Some((t.id.clone(), t.name.clone()));
                                        }
                                        },
                                    );
                                    if idx % 2 == 1 {
                                        ui.end_row();
                                    }
                                }
                            });
                    });
                }

                if let Some(id) = act_select {
                    self.selected = Some(id.clone());
                    if let Some(t) = tunnels.iter().find(|x| x.id == id) {
                        let host = if t.node_host.is_empty() { "127.0.0.1".to_string() } else { t.node_host.clone() };
                        self.probe_latency(host, t.node_port);
                    }
                }
                if let Some(target) = act_delete {
                    self.delete_target = Some(target);
                }
                if let Some(id) = act_toggle {
                    self.selected = Some(id.clone());
                    let running = self.running_id.as_deref() == Some(id.as_str());
                    if running {
                        self.disconnect();
                    } else {
                        self.connect();
                    }
                }
            });

        self.create_window(ctx);
        self.delete_window(ctx);
    }
}

fn nav_button(ui: &mut egui::Ui, text: &str, active: bool) -> bool {
    let fill = if active { SURFACE } else { CARD };
    let color = if active { INK } else { MUTED };
    ui.add_sized(
        [ui.available_width(), 32.0],
        egui::Button::new(egui::RichText::new(text).size(13.0).color(color)).fill(fill),
    ).clicked()
}

fn tunnel_card(ui: &mut egui::Ui, t: &Tunnel, selected: bool, running: bool, latency: &str) -> (bool, bool, bool) {
    let width = ui.available_width();
    let mut toggle = false;
    let mut select = false;
    let mut delete = false;
    let inner = egui::Frame::default()
        .fill(if selected { SURFACE } else { CARD })
        .stroke(egui::Stroke::new(1.0, if selected { ACCENT } else { LINE }))
        .corner_radius(12)
        .inner_margin(egui::Margin::same(14))
        .show(ui, |ui| {
            ui.set_max_width((width - 28.0).max(180.0));
            ui.vertical(|ui| {
            ui.set_width((width - 28.0).max(180.0));
            ui.horizontal(|ui| {
                let color = if running || t.online() { OK } else { FAINT };
                ui.label(egui::RichText::new("●").size(13.0).color(color));
                if ui.add(egui::Label::new(egui::RichText::new(&t.name).size(15.0).strong().color(INK))
                    .sense(egui::Sense::click())).clicked() {
                    select = true;
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let (txt, col) = if running {
                        ("运行中", OK)
                    } else if t.online() {
                        ("在线", OK)
                    } else {
                        ("离线", FAINT)
                    };
                    ui.label(egui::RichText::new(txt).size(11.0).color(col));
                });
            });
            ui.add_space(6.0);
            ui.label(egui::RichText::new(format!(
                "{} · {}:{}", t.ttype.to_uppercase(), t.local_ip, t.local_port
            )).size(12.0).color(MUTED));
            ui.label(egui::RichText::new(format!(
                "公网 {} · {}",
                t.remote_port.map(|p| p.to_string()).unwrap_or_else(|| "-".into()),
                if t.node_host.is_empty() { "自动节点".to_string() } else { format!("{}:{}", t.node_host, t.node_port) }
            )).size(11.5).color(FAINT));
            ui.add_space(10.0);
            ui.horizontal(|ui| {
                let label = if running { "停止" } else { "启动" };
                let fill = if running { SURFACE } else { ACCENT };
                if ui.add_sized([92.0, 32.0],
                    egui::Button::new(egui::RichText::new(label).strong().color(INK)).fill(fill)).clicked() {
                    toggle = true;
                }
                if ui.add_sized([56.0, 32.0],
                    egui::Button::new(egui::RichText::new("删除").color(ERR)).fill(SURFACE)).clicked() {
                    delete = true;
                }
                if selected && !latency.is_empty() {
                    ui.label(egui::RichText::new(latency).size(11.0).color(FAINT));
                }
            });
            });
        });
    (select, toggle, delete)
}

fn fmt_bytes(v: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    const TB: f64 = 1024.0 * 1024.0 * 1024.0 * 1024.0;
    let f = v as f64;
    if f >= TB {
        format!("{:.2} TB", f / TB)
    } else if f >= GB {
        format!("{:.2} GB", f / GB)
    } else if f >= MB {
        format!("{:.1} MB", f / MB)
    } else if f >= KB {
        format!("{:.1} KB", f / KB)
    } else {
        format!("{} B", v)
    }
}

fn open_url(url: &str) {
    #[cfg(windows)]
    {
        let _ = Command::new("cmd").args(["/C", "start", "", url]).spawn();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = Command::new("open").arg(url).spawn();
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        let _ = Command::new("xdg-open").arg(url).spawn();
    }
}

fn nodes_grid(ui: &mut egui::Ui, nodes: &[NodeFull]) {
    egui::Frame::default()
        .fill(egui::Color32::from_rgb(51, 40, 26))
        .stroke(egui::Stroke::new(1.0, egui::Color32::from_rgb(220, 174, 98)))
        .corner_radius(8)
        .inner_margin(egui::Margin::same(10))
        .show(ui, |ui| {
            ui.vertical(|ui| {
                ui.label(egui::RichText::new("注意").strong().size(13.0)
                    .color(egui::Color32::from_rgb(220, 174, 98)));
                ui.label(egui::RichText::new(
                    "节点在线状态基于心跳（30 秒无心跳判为离线），可能显示不准确；能否使用请以节点实际启动情况为准。",
                ).size(12.0).color(INK));
            });
        });
    ui.add_space(10.0);
    if nodes.is_empty() {
        ui.add_space(40.0);
        ui.vertical_centered(|ui| {
            ui.label(egui::RichText::new("还没有捐赠节点").size(15.0).color(FAINT));
            ui.add_space(4.0);
            ui.label(egui::RichText::new("在面板「捐赠节点」页生成一键脚本，到节点服务器执行").size(12.0).color(FAINT));
        });
        return;
    }
    let gap = 12.0;
    let col_w = ((ui.available_width() - gap) / 2.0).max(240.0);
    egui::ScrollArea::vertical().show(ui, |ui| {
        egui::Grid::new("nodes_grid")
            .num_columns(2)
            .spacing([gap, gap])
            .show(ui, |ui| {
                for (idx, n) in nodes.iter().enumerate() {
                    ui.allocate_ui_with_layout(
                        egui::vec2(col_w, 128.0),
                        egui::Layout::top_down(egui::Align::LEFT),
                        |ui| {
                            egui::Frame::default()
                                .fill(CARD)
                                .stroke(egui::Stroke::new(1.0, LINE))
                                .corner_radius(12)
                                .inner_margin(egui::Margin::same(14))
                                .show(ui, |ui| {
                                    ui.set_width((col_w - 28.0).max(180.0));
                                    ui.vertical(|ui| {
                                        ui.horizontal(|ui| {
                                            let online = n.status == "online";
                                            ui.label(egui::RichText::new("●").size(13.0)
                                                .color(if online { OK } else { FAINT }));
                                            ui.label(egui::RichText::new(&n.name).size(15.0).strong().color(INK));
                                            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                                                let (txt, col) = if n.approved == 1 {
                                                    (if online { "在线" } else { "离线" }, if online { OK } else { FAINT })
                                                } else {
                                                    ("待审核", MUTED)
                                                };
                                                ui.label(egui::RichText::new(txt).size(11.0).color(col));
                                            });
                                        });
                                        ui.add_space(5.0);
                                        ui.label(egui::RichText::new(format!("{}:{}", n.host, n.port))
                                            .size(12.0).color(MUTED));
                                        ui.label(egui::RichText::new(format!(
                                            "CPU {:.0}% · 内存 {:.0}% · 客户端 {}",
                                            n.cpu, n.mem, n.clients
                                        )).size(11.5).color(FAINT));
                                    });
                                });
                        },
                    );
                    if idx % 2 == 1 {
                        ui.end_row();
                    }
                }
            });
    });
}

fn label(ui: &mut egui::Ui, text: &str) {
    ui.label(egui::RichText::new(text).size(12.5).color(MUTED));
}

fn info_row(ui: &mut egui::Ui, key: &str, value: &str) {
    ui.horizontal(|ui| {
        ui.add_sized([90.0, 20.0], egui::Label::new(egui::RichText::new(key).size(12.0).color(FAINT)));
        ui.label(egui::RichText::new(value).size(12.5).color(INK));
    });
    ui.add_space(2.0);
}

fn spinner(ui: &mut egui::Ui, t: f32) {
    let (rect, _) = ui.allocate_exact_size(egui::vec2(56.0, 56.0), egui::Sense::hover());
    let center = rect.center();
    let painter = ui.painter();
    let start = t * 6.0;
    for i in 0..12 {
        let angle = start + i as f32 * std::f32::consts::TAU / 12.0;
        let fade = 1.0 - i as f32 / 12.0;
        let pos = center + egui::vec2(angle.cos(), angle.sin()) * 20.0;
        painter.circle_filled(
            pos,
            2.6,
            egui::Color32::from_rgba_unmultiplied(
                86,
                179,
                189,
                (fade * 255.0).clamp(0.0, 255.0) as u8,
            ),
        );
    }
}

fn dbg(msg: &str) {
    if std::env::var("CLOUDFRP_DEBUG").is_err() {
        return;
    }
    let dir = data_dir();
    let _ = std::fs::create_dir_all(&dir);
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(dir.join("debug.log")) {
        use std::io::Write;
        let _ = writeln!(f, "{} {}", now_hms(), msg);
    }
}

fn now_hms() -> String {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    format!("{:02}:{:02}:{:02}", (now / 3600) % 24, (now / 60) % 60, now % 60)
}

fn data_dir() -> PathBuf {
    let home = std::env::var("USERPROFILE")
        .or_else(|_| std::env::var("HOME"))
        .unwrap_or_else(|_| ".".into());
    PathBuf::from(home).join(".cloudfrp")
}

fn frpc_path() -> PathBuf {
    data_dir().join(if cfg!(windows) { "frpc.exe" } else { "frpc" })
}

fn settings_path() -> PathBuf {
    data_dir().join("client-settings.json")
}

fn load_settings() -> (String, String) {
    if let Ok(text) = std::fs::read_to_string(settings_path()) {
        if let Ok(v) = serde_json::from_str::<Value>(&text) {
            return (
                v.get("panel").and_then(|x| x.as_str()).unwrap_or("http://127.0.0.1:3592").to_string(),
                v.get("username").and_then(|x| x.as_str()).unwrap_or("").to_string(),
            );
        }
    }
    ("http://127.0.0.1:3592".into(), String::new())
}

fn save_settings(panel: &str, user: &str) {
    let _ = std::fs::create_dir_all(data_dir());
    let v = serde_json::json!({ "panel": panel, "username": user });
    if let Ok(text) = serde_json::to_string_pretty(&v) {
        let _ = std::fs::write(settings_path(), text);
    }
}

fn arch_tag() -> &'static str {
    match std::env::consts::ARCH {
        "x86_64" => "amd64",
        "aarch64" => "arm64",
        "arm" => "arm",
        "x86" => "386",
        other => other,
    }
}

fn frp_asset() -> (String, bool) {
    let arch = arch_tag();
    if cfg!(windows) {
        (format!("frp_{FRP_VER}_windows_{arch}.zip"), true)
    } else if cfg!(target_os = "macos") {
        (format!("frp_{FRP_VER}_darwin_{arch}.tar.gz"), false)
    } else {
        (format!("frp_{FRP_VER}_linux_{arch}.tar.gz"), false)
    }
}

fn ensure_frpc() -> Result<PathBuf, String> {
    let path = frpc_path();
    if path.is_file() {
        return Ok(path);
    }
    let (asset, is_zip) = frp_asset();
    let base = format!("https://github.com/fatedier/frp/releases/download/v{FRP_VER}/{asset}");
    let urls = [
        format!("https://ghfast.top/{base}"),
        format!("https://ghproxy.net/{base}"),
        format!("https://gh-proxy.com/{base}"),
        base,
    ];
    std::fs::create_dir_all(data_dir()).map_err(|e| e.to_string())?;
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(180))
        .build()
        .map_err(|e| e.to_string())?;
    for url in urls {
        let Ok(resp) = client.get(&url).send() else { continue };
        if !resp.status().is_success() {
            continue;
        }
        let Ok(bytes) = resp.bytes() else { continue };
        let ok = if is_zip {
            extract_zip(&bytes, &path)
        } else {
            extract_tar(&bytes, &path)
        };
        if ok {
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                let _ = std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755));
            }
            return Ok(path);
        }
    }
    Err(format!("frpc 下载失败，请手动把 frpc 放到 {}", path.display()))
}

fn extract_zip(bytes: &[u8], dest: &PathBuf) -> bool {
    let reader = Cursor::new(bytes);
    let Ok(mut archive) = zip::ZipArchive::new(reader) else { return false };
    for i in 0..archive.len() {
        let Ok(mut entry) = archive.by_index(i) else { continue };
        let name = entry.name().to_string();
        let is_target = if cfg!(windows) {
            name.ends_with("frpc.exe")
        } else {
            name.ends_with("/frpc")
        };
        if is_target {
            let mut out = Vec::new();
            if entry.read_to_end(&mut out).is_ok() {
                return std::fs::write(dest, out).is_ok();
            }
        }
    }
    false
}

fn extract_tar(bytes: &[u8], dest: &PathBuf) -> bool {
    let decoder = flate2::read::GzDecoder::new(Cursor::new(bytes));
    let mut archive = tar::Archive::new(decoder);
    let Ok(entries) = archive.entries() else { return false };
    for entry in entries.flatten() {
        let path = entry.path().map(|p| p.to_string_lossy().to_string()).unwrap_or_default();
        if path.ends_with("/frpc") || path == "frpc" {
            let mut out = Vec::new();
            let mut entry = entry;
            if entry.read_to_end(&mut out).is_ok() {
                return std::fs::write(dest, out).is_ok();
            }
        }
    }
    false
}

fn setup_fonts(ctx: &egui::Context) {
    let mut fonts = egui::FontDefinitions::default();
    let candidates: &[&str] = if cfg!(windows) {
        &[
            "C:/Windows/Fonts/msyh.ttc",
            "C:/Windows/Fonts/msyh.ttf",
            "C:/Windows/Fonts/simhei.ttf",
        ]
    } else if cfg!(target_os = "macos") {
        &[
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/Hiragino Sans GB.ttc",
        ]
    } else {
        &[
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ]
    };
    for path in candidates {
        if let Ok(bytes) = std::fs::read(path) {
            fonts
                .font_data
                .insert("cjk".to_owned(), Arc::new(egui::FontData::from_owned(bytes)));
            fonts
                .families
                .entry(egui::FontFamily::Proportional)
                .or_default()
                .push("cjk".to_owned());
            fonts
                .families
                .entry(egui::FontFamily::Monospace)
                .or_default()
                .push("cjk".to_owned());
            break;
        }
    }
    ctx.set_fonts(fonts);
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1000.0, 680.0])
            .with_min_inner_size([880.0, 560.0])
            .with_title(format!("CloudFRP 启动器 v{VERSION}")),
        ..Default::default()
    };
    eframe::run_native(
        "cloudfrp-launcher",
        options,
        Box::new(|cc| {
            setup_fonts(&cc.egui_ctx);
            let mut style = (*cc.egui_ctx.style()).clone();
            style.visuals = egui::Visuals::dark();
            style.visuals.panel_fill = BG;
            style.visuals.window_fill = BG;
            style.visuals.override_text_color = Some(INK);
            cc.egui_ctx.set_style(style);
            Ok(Box::new(App::new()))
        }),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn login_flow() {
        let Ok(pass) = std::env::var("CLOUDFRP_PASSWORD") else { return };
        let url = std::env::var("CLOUDFRP_PANEL").unwrap_or_else(|_| "http://127.0.0.1:3592".into());
        let user = std::env::var("CLOUDFRP_USER").unwrap_or_else(|_| "admin".into());
        let panel = Panel::login(&url, &user, &pass).expect("login failed");
        let data = panel.fetch().expect("fetch failed");
        println!("tunnels={} user={}", data.tunnels.len(),
                 data.user.get("username").and_then(|v| v.as_str()).unwrap_or(""));
    }
}

#[cfg(test)]
mod feature_tests {
    use super::*;

    #[test]
    fn checkin_and_create() {
        let Ok(pass) = std::env::var("CLOUDFRP_PASSWORD") else { return };
        let url = std::env::var("CLOUDFRP_PANEL").unwrap_or_else(|_| "http://127.0.0.1:3592".into());
        let user = std::env::var("CLOUDFRP_USER").unwrap_or_else(|_| "admin".into());
        let panel = Panel::login(&url, &user, &pass).expect("login");
        let checkin = panel.post("/api/checkin", &serde_json::json!({}));
        println!("checkin: {:?}", checkin);
        let rp = panel.get("/api/random-port").expect("random port");
        let body = serde_json::json!({
            "name": "rust-client-test",
            "type": "tcp",
            "local_ip": "127.0.0.1",
            "local_port": 8080,
            "remote_port": rp.get("port").cloned().unwrap_or(serde_json::json!(26000)),
        });
        let created = panel.post("/api/tunnels", &body);
        println!("create: {:?}", created);
        assert!(created.is_ok(), "create failed");
    }
}

#[cfg(test)]
mod feature_tests2 {
    use super::*;

    #[test]
    fn create_and_delete_tunnel() {
        let Ok(pass) = std::env::var("CLOUDFRP_PASSWORD") else { return };
        let url = std::env::var("CLOUDFRP_PANEL").unwrap_or_else(|_| "http://127.0.0.1:3592".into());
        let user = std::env::var("CLOUDFRP_USER").unwrap_or_else(|_| "admin".into());
        let panel = Panel::login(&url, &user, &pass).expect("login");
        let rp = panel.get("/api/random-port").expect("port");
        let body = serde_json::json!({
            "name": "rust-delete-test", "type": "tcp", "local_ip": "127.0.0.1",
            "local_port": 8080, "remote_port": rp.get("port").cloned().unwrap_or(serde_json::json!(27000)),
        });
        let created = panel.post("/api/tunnels", &body).expect("create");
        let id = created.get("tunnel_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
        assert!(!id.is_empty(), "no tunnel id");
        panel.delete(&format!("/api/tunnels/{id}")).expect("delete");
        println!("created and deleted {id}");
    }
}
