"""
CloudFRP Web Panel — application entrypoint.

Page routing + Flask app construction live here. All JSON APIs live in
blueprints under app/api/ (see app/api/__init__.py).

Run:  python server.py          (from the webpanel/ directory)
Port: 3592                      (override with PANEL_PORT in .env)
"""
import os
import secrets
from datetime import timedelta

from flask import Flask, render_template, request, session, redirect, url_for
from dotenv import load_dotenv
from werkzeug.middleware.proxy_fix import ProxyFix
from flask.sessions import SecureCookieSessionInterface

# ---- config -----------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_HERE, ".env"))

app = Flask(
    __name__,
    static_folder=os.path.join(_HERE, "app", "static"),
    static_url_path="/static",
)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
# 模板改动即时生效（开发/联调期）：前端文件更新无需重启服务
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config.update(
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=64 * 1024 * 1024,
)
# 兼容旧代码读取 app.permanent_session_lifetime
app.permanent_session_lifetime = timedelta(days=30)

# HTTPS 反代会注入 X-Forwarded-Proto: https，让生成的链接使用 https
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1)


class ProxyAwareSessionInterface(SecureCookieSessionInterface):
    """HTTPS（含反代 X-Forwarded-Proto）时给会话 Cookie 加 Secure，HTTP 下不加。"""

    def get_cookie_secure(self, app):
        return bool(request.is_secure or app.config.get("SESSION_COOKIE_SECURE", False))


app.session_interface = ProxyAwareSessionInterface()

# ---- services (single import point for the data layer) ----------------------
from app.database import db                    # noqa: E402
from app.api import register_api_blueprints    # noqa: E402
from app.api.captcha_api import captcha_ok  # noqa: E402
from app.security import (init_security, login_precheck, record_login_failure,
                          clear_login_failures, client_ip)  # noqa: E402

init_security(app)

db.init_tables()
register_api_blueprints(app)

from app.services.frps_service import start_background_sync  # noqa: E402
start_background_sync()
from app.services.backup_service import start_backup_scheduler  # noqa: E402
start_backup_scheduler()

PANEL_HOST = os.environ.get("PANEL_HOST", "0.0.0.0")
PANEL_PORT = int(os.environ.get("PANEL_PORT", 3592))


def _logged_in():
    return "username" in session


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("auth.html")

    username = request.form.get("username")
    password = request.form.get("password")
    ip = client_ip()

    ok, msg, retry = login_precheck(username, ip)
    if not ok:
        resp = app.make_response(render_template("auth.html", error=msg))
        resp.status_code = 429
        resp.headers["Retry-After"] = str(retry)
        return resp

    if not captcha_ok(request.form.get("captcha_id")):
        return render_template("auth.html", error="请完成图片验证码")

    from app.services.user_service import user_service as us
    success, user = us.login(username, password)
    if success:
        clear_login_failures(username, ip)
        # 防会话固定：登录成功后重建会话
        session.clear()
        # 勾选"保持登录状态"才使用长期会话
        session.permanent = request.form.get("remember") is not None
        session["username"] = user["username"]
        session["user_id"] = user["id"]
        return redirect(url_for("dashboard"))
    record_login_failure(username, ip)
    return render_template("auth.html", error="用户名/邮箱或密码错误")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("auth.html")

    from app.services import email_service
    from app.services.user_service import user_service as us

    username = request.form.get("username")
    password = request.form.get("password")
    email = (request.form.get("email") or "").strip().lower()
    email_code = request.form.get("email_code", "")

    if not email_service.is_configured():
        return render_template("auth.html", error="邮箱服务未配置，暂时无法注册，请联系管理员")

    # 先做能立即判断的检查，避免验证码被无谓消耗
    if us.get_by_username(username):
        return render_template("auth.html", error="用户名已被使用")
    if us.get_by_email(email):
        return render_template("auth.html", error="邮箱已被注册")

    ok, msg = email_service.consume_code_for_email(email, "register", email_code)
    if not ok:
        return render_template("auth.html", error=msg)

    success, message = us.register(username, password, email)
    if success:
        return render_template("auth.html", success="注册成功，请登录")
    return render_template("auth.html", error=message)


@app.route("/robots.txt")
def robots_txt():
    body = "User-agent: *" + chr(10) + "Disallow: /" + chr(10)
    return app.response_class(body, mimetype="text/plain")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---- authed pages (all render the app.html SPA shell) ----------------------
@app.route("/index")
@app.route("/dashboard")
def dashboard():
    if not _logged_in():
        return redirect(url_for("login"))
    return render_template("app.html", username=session["username"])


@app.route("/nodes")
def nodes_page():
    if not _logged_in():
        return redirect(url_for("login"))
    return render_template("app.html", username=session["username"])


@app.route("/user-center")
def user_center():
    if not _logged_in():
        return redirect(url_for("login"))
    return render_template("app.html", username=session["username"])


@app.route("/points-shop")
def points_shop():
    if not _logged_in():
        return redirect(url_for("login"))
    return render_template("app.html", username=session["username"])


@app.route("/docs")
def docs():
    """使用文档：独立页面（公开可读，已登录显示返回控制台）"""
    return render_template("docs.html", username=session.get("username"))


@app.route("/about")
def about():
    return redirect(url_for("docs"))


@app.route("/admin")
@app.route("/admin/users")
def admin_panel():
    if not _logged_in():
        return redirect(url_for("login"))
    from app.services.user_service import user_service
    if not user_service.is_admin(session["username"]):
        return "权限不足", 403
    return render_template("app.html", username=session["username"])


# ---- error handlers ---------------------------------------------------------
@app.errorhandler(404)
def page_not_found(_e):
    return render_template("error.html", error="页面未找到"), 404


@app.errorhandler(500)
def internal_error(_e):
    return render_template("error.html", error="服务器内部错误"), 500


# ---- entrypoint -------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 50)
    print("CloudFRP Web Panel")
    print("=" * 50)
    print(f"URL   : http://localhost:{PANEL_PORT}")
    print(f"Admin : admin / yunwang")
    print("=" * 50)
    app.run(host=PANEL_HOST, port=PANEL_PORT, debug=False)
