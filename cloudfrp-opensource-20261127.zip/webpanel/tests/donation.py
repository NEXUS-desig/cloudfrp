"""CloudFRP 捐赠节点后端测试（仅标准库）。

覆盖：
  1. GET /api/health 结构（无认证）
  2. 生成安装脚本：bash -n 语法检查、内嵌客户端 py_compile
  3. 脚本内容：EnvironmentFile（Token 不在命令行）、systemd 硬化、--uninstall、防火墙提示
  4. 注入尝试（name/host/port/panel）必须 400 拒绝，且不产生副作用
  5. 节点注册 / 幂等更新 / 心跳 token 校验 / 404 / 未授权管理操作
  6. 未认证注册限流 429 + Retry-After，且带 token 的幂等更新不受限流影响

针对正在运行的面板（默认 http://127.0.0.1:3592）。所有测试数据在结束时删除。
用法：
    python tests/donation.py
    PANEL_URL=http://127.0.0.1:3592 python tests/donation.py
"""
import hashlib
import http.cookiejar
import json
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

BASE = os.environ.get("PANEL_URL", "http://127.0.0.1:3592").rstrip("/")
HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("PANEL_DB", os.path.join(os.path.dirname(HERE), "frp_panel.db"))

RESULTS = []


def record(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(("PASS  " if ok else "FAIL  ") + name + (("  -- " + detail) if detail else ""))


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 8000")
    return conn


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar))
        self.last_headers = {}

    def request(self, method, path, form=None, payload=None, headers=None):
        hdrs = dict(headers or {})
        hdrs.setdefault("X-CloudFRP-Client", "launcher")
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            hdrs["Content-Type"] = "application/json"
        elif form is not None:
            body = urllib.parse.urlencode(form).encode("utf-8")
            hdrs["Content-Type"] = "application/x-www-form-urlencoded"
        req = urllib.request.Request(BASE + path, data=body, headers=hdrs, method=method)
        try:
            with self.opener.open(req, timeout=25) as resp:
                self.last_headers = dict(resp.headers)
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            self.last_headers = dict(exc.headers or {})
            return exc.code, exc.read()
        except Exception as exc:  # noqa: BLE001
            self.last_headers = {}
            return 0, str(exc).encode()

    def json(self, method, path, form=None, payload=None, headers=None):
        status, raw = self.request(method, path, form=form, payload=payload, headers=headers)
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            data = {}
        return status, data, raw


def install_url(params):
    return "/api/nodes/donate-install.sh?" + urllib.parse.urlencode(params)


def extract_embedded_client(script):
    match = re.search(r"<<'PYEOF_EMBED'\r?\n(.*?)\r?\nPYEOF_EMBED", script, re.S)
    return match.group(1) if match else ""


def main():
    suffix = secrets.token_hex(4)
    admin_name = "_don_admin_" + suffix
    admin_id = None
    created_nodes = []
    # 每次运行使用不同的合成 IP，避免上一轮 60 秒限流窗口影响本轮
    ip_octet = 20 + (int(suffix[:2], 16) % 200)
    remote_ip = "198.51.100.%d" % ip_octet
    rl_ip = "203.0.113.%d" % ip_octet
    tmpdir = tempfile.mkdtemp(prefix="cloudfrp_donation_")
    conn = db_connect()

    # ---------- 0. 服务可达 ----------
    anon = Client()
    status, raw = anon.request("GET", "/login")
    record("server reachable GET /login", status == 200, "status=%s" % status)
    if status != 200:
        print("服务不可达，终止。")
        return 1

    # ---------- 1. /api/health ----------
    status, hdata, _ = anon.json("GET", "/api/health")
    time_ok = False
    try:
        datetime.fromisoformat(str(hdata.get("time", "")).replace("Z", "+00:00"))
        time_ok = True
    except ValueError:
        pass
    record("GET /api/health shape",
           status == 200 and hdata.get("ok") is True
           and isinstance(hdata.get("version"), str) and bool(hdata.get("version"))
           and time_ok,
           "status=%s version=%s" % (status, hdata.get("version")))

    # ---------- 2. 未登录不能下载安装脚本 ----------
    status, sdata, _ = anon.json("GET", install_url({}))
    record("anonymous install script -> 401",
           status == 401 and bool(sdata.get("error")), "status=%s" % status)

    # ---------- 3. 登录临时管理员 ----------
    admin_pw = "DonPass123!"
    try:
        cur = conn.execute(
            "INSERT INTO users (username, password, email, token, role, points, membership_level) "
            "VALUES (?, ?, ?, ?, 'admin', 0, 0)",
            (admin_name, hashlib.md5(admin_pw.encode()).hexdigest(),
             "_%s@example.com" % admin_name, secrets.token_hex(16)))
        conn.commit()
        admin_id = cur.lastrowid
    except Exception as exc:  # noqa: BLE001
        record("create temp admin row", False, str(exc))
        return 1
    record("create temp admin row", admin_id is not None, "id=%s" % admin_id)

    client = Client()
    client.json("POST", "/login", form={
        "username": admin_name, "password": admin_pw,
        "captcha": "verified", "remember": "1"})
    status, info, _ = client.json("GET", "/api/user-info")
    record("login temp admin", status == 200 and info.get("username") == admin_name,
           "status=%s" % status)

    # ---------- 4. 正常生成脚本 + bash -n + py_compile ----------
    params = {"name": "hz01", "host": "198.51.100.10", "port": "7000",
              "panel": "http://127.0.0.1:3592"}
    status, raw = client.request("GET", install_url(params))
    script = raw.decode("utf-8", "replace")
    record("install script generated", status == 200 and "#!/usr/bin/env bash" in script,
           "status=%s bytes=%s" % (status, len(raw)))
    record("install script has no unresolved placeholders",
           status == 200 and "@@PANEL@@" not in script and "@@CLIENT_PY@@" not in script
           and "@@TOKEN@@" not in script)

    token_match = re.search(r"^FRPS_TOKEN='([^']*)'$", script, re.M)
    frp_token = token_match.group(1) if token_match else ""
    record("token emitted as shell-quoted assignment", bool(frp_token))

    exec_lines = [ln for ln in script.splitlines() if ln.startswith("ExecStart=")]
    exec_has_token = any(frp_token and frp_token in ln for ln in exec_lines)
    record("token not on systemd ExecStart",
           bool(exec_lines) and not exec_has_token, "exec=%s" % (exec_lines[:3],))

    record("systemd hardening present",
           "EnvironmentFile=${ENV_FILE}" in script
           and 'ENV_FILE="$ETC_DIR/node.env"' in script
           and "Restart=always" in script
           and "RestartSec=10" in script
           and "After=network-online.target" in script
           and "ProtectSystem=strict" in script)
    record("idempotent/uninstall/firewall hints present",
           "--uninstall" in script
           and "systemctl stop cloudfrp-node.service" in script
           and "REGEN" in script
           and "ufw allow" in script
           and "firewall-cmd" in script)

    bash = shutil.which("bash")
    if bash:
        proc = subprocess.run([bash, "-n"], input=raw,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        record("generated script passes bash -n", proc.returncode == 0,
               (proc.stderr.decode("utf-8", "replace").strip()[:300]))
    else:
        record("generated script passes bash -n", False, "bash not found")

    embedded = extract_embedded_client(script)
    record("embedded client extracted", bool(embedded.strip()), "bytes=%s" % len(embedded))
    if embedded:
        py_path = os.path.join(tmpdir, "node_client.py")
        with open(py_path, "w", encoding="utf-8") as fh:
            fh.write(embedded)
        proc = subprocess.run([sys.executable, "-m", "py_compile", py_path],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        record("embedded client passes py_compile", proc.returncode == 0,
               proc.stderr.decode("utf-8", "replace").strip()[:300])

    # 面板地址留空 -> 使用本站；host 留空 -> 脚本自动探测
    status, raw2 = client.request("GET", install_url({"name": "", "host": "", "port": "7000"}))
    body2 = raw2.decode("utf-8", "replace")
    record("empty host/panel fallbacks accepted",
           status == 200 and "NODE_NAME=''" in body2
           and "PANEL='%s'" % BASE in body2,
           "status=%s" % status)

    # ---------- 5. 注入尝试必须 400 ----------
    bad_cases = [
        ("name shell quote", {"name": "hz01'; touch /tmp/cloudfrp_pwned; echo '",
                              "host": "198.51.100.10", "port": "7000"}),
        ("name command substitution", {"name": "$(touch /tmp/cloudfrp_pwned)",
                                       "host": "198.51.100.10", "port": "7000"}),
        ("name newline", {"name": "hz01\nmalicious", "host": "198.51.100.10",
                          "port": "7000"}),
        ("name backtick", {"name": "hz01`id`", "host": "198.51.100.10",
                           "port": "7000"}),
        ("name too long", {"name": "x" * 101, "host": "198.51.100.10", "port": "7000"}),
        ("host shell metachar", {"name": "hz01", "host": "198.51.100.1;id",
                                 "port": "7000"}),
        ("host command substitution", {"name": "hz01", "host": "$(id)", "port": "7000"}),
        ("port injection", {"name": "hz01", "host": "198.51.100.10",
                            "port": "7000;id"}),
        ("port out of range", {"name": "hz01", "host": "198.51.100.10", "port": "99999"}),
        ("panel command injection", {"name": "hz01", "host": "198.51.100.10",
                                     "port": "7000",
                                     "panel": "http://127.0.0.1:3592;rm -rf /"}),
        ("panel path injection", {"name": "hz01", "host": "198.51.100.10",
                                  "port": "7000",
                                  "panel": "http://127.0.0.1:3592/$(id)"}),
        ("panel bad scheme", {"name": "hz01", "host": "198.51.100.10",
                              "port": "7000", "panel": "javascript:alert(1)"}),
    ]
    all_rejected = True
    for label, case in bad_cases:
        status, data, _ = client.json("GET", install_url(case))
        ok = status == 400 and data.get("success") is False and bool(data.get("error"))
        all_rejected = all_rejected and ok
        record("reject injection: " + label, ok, "status=%s" % status)
    record("no injection side effect created",
           not os.path.exists("/tmp/cloudfrp_pwned"))

    # ---------- 6. 注册 / 幂等更新 / 心跳 ----------
    node_id = ("_don_node_" + suffix)[:64]
    headers = {"X-CloudFRP-Client-IP": remote_ip}
    payload = {"node_id": node_id, "name": "don-smoke", "host": "198.51.100.10",
               "port": 7000, "donated_by": "don-smoke"}
    status, ndata, _ = client.json("POST", "/api/nodes/register", payload=payload,
                                   headers=headers)
    node_token = ndata.get("node_token")
    if status == 200:
        created_nodes.append(node_id)
    record("register node (pending)",
           status == 200 and ndata.get("success") is True and bool(node_token)
           and ndata.get("approved") is False,
           "status=%s approved=%s" % (status, ndata.get("approved")))

    payload_update = dict(payload, node_token=node_token)
    status2, ndata2, _ = client.json("POST", "/api/nodes/register", payload=payload_update,
                                     headers=headers)
    record("idempotent re-register with token",
           status2 == 200 and ndata2.get("node_token") == node_token,
           "status=%s" % status2)

    stats = {"cpu_usage": 5.5, "memory_usage": 30, "upload_speed": 1024,
             "download_speed": 2048, "total_upload": 10000,
             "total_download": 20000, "client_count": 1, "frps_healthy": True}
    status, hb, _ = client.json("POST", "/api/nodes/%s/heartbeat" % node_id,
                                payload={"node_token": node_token, "stats": stats},
                                headers=headers)
    record("heartbeat with correct token", status == 200 and hb.get("success") is True,
           "status=%s" % status)

    status, hb, _ = client.json("POST", "/api/nodes/%s/heartbeat" % node_id,
                                payload={"node_token": "wrong-token", "stats": stats},
                                headers=headers)
    record("heartbeat with wrong token -> 401",
           status == 401 and hb.get("code") == "INVALID_TOKEN", "status=%s" % status)

    status, hb, _ = client.json("POST", "/api/nodes/%s/heartbeat" % node_id,
                                payload={"stats": stats}, headers=headers)
    record("heartbeat without token -> 401", status == 401, "status=%s" % status)

    missing_id = "_don_missing_" + suffix
    status, hb, _ = client.json("POST", "/api/nodes/%s/heartbeat" % missing_id,
                                payload={"node_token": "x", "stats": stats},
                                headers=headers)
    record("heartbeat unknown node -> 404",
           status == 404 and hb.get("code") == "NODE_NOT_FOUND", "status=%s" % status)

    status, ddata, _ = anon.json("DELETE", "/api/nodes/%s" % node_id)
    record("anonymous delete node -> 401", status == 401 and bool(ddata.get("error")),
           "status=%s" % status)
    status, adata, _ = anon.json("PUT", "/api/nodes/%s/approve" % node_id,
                                 payload={"approved": True})
    record("anonymous approve node -> 401", status == 401 and bool(adata.get("error")),
           "status=%s" % status)

    # ---------- 7. 注册限流（5/min）+ 带 token 更新豁免 ----------
    statuses = []
    first_token = None
    first_id = None
    for i in range(7):
        rl_id = ("_don_rl_%s_%d" % (suffix, i))[:64]
        st, rd, _ = anon.json("POST", "/api/nodes/register", headers={"X-CloudFRP-Client-IP": rl_ip},
                              payload={"node_id": rl_id, "name": "rl-%d" % i,
                                       "host": "198.51.100.11", "port": 7000})
        statuses.append(st)
        if st == 200:
            created_nodes.append(rl_id)
            if first_token is None:
                first_token = rd.get("node_token")
                first_id = rl_id
    record("registration rate limit returns 429",
           429 in statuses and statuses.index(429) >= 1,
           "statuses=%s" % statuses)
    record("rate limited response has Retry-After",
           bool(anon.last_headers.get("Retry-After")),
           "retry_after=%s" % anon.last_headers.get("Retry-After"))
    if first_id and first_token:
        st, rd, _ = anon.json("POST", "/api/nodes/register",
                              headers={"X-CloudFRP-Client-IP": rl_ip},
                              payload={"node_id": first_id, "name": "rl-update",
                                       "host": "198.51.100.11", "port": 7000,
                                       "node_token": first_token})
        record("token-authenticated update bypasses rate limit",
               st == 200 and rd.get("success") is True, "status=%s" % st)

    # ---------- 清理 ----------
    try:
        for nid in created_nodes:
            conn.execute("DELETE FROM traffic_samples WHERE node_id = ?", (nid,))
            conn.execute("DELETE FROM tunnels WHERE node_id = ?", (nid,))
            conn.execute("DELETE FROM nodes WHERE node_id = ?", (nid,))
        if admin_id:
            conn.execute("DELETE FROM checkins WHERE user_id = ?", (admin_id,))
            conn.execute("DELETE FROM tunnels WHERE user_id = ?", (admin_id,))
            conn.execute("DELETE FROM users WHERE id = ?", (admin_id,))
        conn.commit()
    except Exception as exc:  # noqa: BLE001
        print("cleanup warning:", exc)
    finally:
        conn.close()
        shutil.rmtree(tmpdir, ignore_errors=True)

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = len(RESULTS) - passed
    print("\n===== donation summary: %d PASS / %d FAIL =====" % (passed, failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
