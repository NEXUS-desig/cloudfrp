"""CloudFRP 面板后端冒烟测试（仅标准库：urllib + sqlite3）。

针对正在运行的面板（默认 http://127.0.0.1:3592）执行：
  1. 登录（临时管理员账号，MD5 历史哈希，登录后服务端会升级为 bcrypt）
  2. 注册验证码流程（直接向 SQLite 插入验证码行）
  3. 节点注册 + 管理员审核
  4. 未审核节点 / 已审核节点建隧道
  5. 流量时序 API 结构 + 5 分钟桶对齐
  6. OTP 保护的高风险接口未带验证码必须 403
  7. 未登录访问受保护接口必须 401

所有测试数据（用户、节点、隧道、验证码、签到）在结束时删除。
用法：
    python tests/smoke.py
    PANEL_URL=http://127.0.0.1:3592 python tests/smoke.py
"""
import hashlib
import http.cookiejar
import json
import os
import secrets
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

BASE = os.environ.get("PANEL_URL", "http://127.0.0.1:3592").rstrip("/")
HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("PANEL_DB", os.path.join(os.path.dirname(HERE), "frp_panel.db"))

RESULTS = []


def record(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(("PASS  " if ok else "FAIL  ") + name + (("  -- " + detail) if detail else ""))


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 8000")
    return conn


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar))

    def request(self, method, path, form=None, payload=None):
        headers = {"X-CloudFRP-Client": "launcher"}
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        elif form is not None:
            body = urllib.parse.urlencode(form).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        req = urllib.request.Request(BASE + path, data=body, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=20) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()
        except Exception as exc:  # noqa: BLE001
            return 0, str(exc).encode()

    def json(self, method, path, form=None, payload=None):
        status, raw = self.request(method, path, form=form, payload=payload)
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            data = {}
        return status, data, raw


def main():
    suffix = secrets.token_hex(4)
    admin_name = "_smoke_admin_" + suffix
    user_name = "_smoke_user_" + suffix
    email = "_smoke_%s@example.com" % suffix
    node_ok_id = "_smoke_node_ok_" + suffix
    node_pending_id = "_smoke_node_pending_" + suffix
    admin_id = None
    created_user_ids = []
    remote_port = 20000 + (int(suffix, 16) % 30000)
    tunnel_id = None

    conn = db_connect()

    # ---------- 0. 服务可达 ----------
    client = Client()
    status, raw = client.request("GET", "/login")
    record("server reachable GET /login", status == 200, "status=%s" % status)
    if status != 200:
        print("服务不可达，终止。")
        return 1

    # ---------- 1. 登录 ----------
    admin_pw = "SmokePass123!"
    try:
        cur = conn.execute(
            "INSERT INTO users (username, password, email, token, role, points, membership_level) "
            "VALUES (?, ?, ?, ?, 'admin', 0, 0)",
            (admin_name, hashlib.md5(admin_pw.encode()).hexdigest(),
             "_%s@example.com" % admin_name, secrets.token_hex(16)))
        conn.commit()
        admin_id = cur.lastrowid
    except Exception as exc:  # noqa: BLE001
        record("create temp admin row", False, str(exc))
        return 1
    record("create temp admin row", admin_id is not None, "id=%s" % admin_id)

    status, data, raw = client.json("POST", "/login", form={
        "username": admin_name, "password": admin_pw,
        "captcha": "verified", "remember": "1"})
    # /login 成功是 302 -> /dashboard，urllib 自动跟随；用受保护接口确认登录态
    status2, info, _ = client.json("GET", "/api/user-info")
    record("login temp admin", status2 == 200 and info.get("username") == admin_name,
           "login=%s user_info=%s" % (status, status2))

    # ---------- 2. 注册验证码流程 ----------
    reg_code = "%06d" % (secrets.randbelow(1000000))
    expires = (datetime.now() + timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")
    conn.execute(
        "INSERT INTO email_codes (user_id, purpose, code_hash, attempts, expires_at, used, target) "
        "VALUES (0, 'register', ?, 0, ?, 0, ?)",
        (hashlib.sha256(reg_code.encode()).hexdigest(), expires, email))
    conn.commit()
    reg_pw = "SmokeReg123!"
    status, raw = client.request("POST", "/register", form={
        "username": user_name, "password": reg_pw,
        "email": email, "email_code": reg_code})
    row = conn.execute("SELECT id FROM users WHERE username = ?", (user_name,)).fetchone()
    record("register with email code", status == 200 and row is not None,
           "status=%s user_created=%s" % (status, row is not None))
    if row:
        created_user_ids.append(row["id"])
    used = conn.execute(
        "SELECT used FROM email_codes WHERE target = ? ORDER BY id DESC LIMIT 1",
        (email,)).fetchone()
    record("register code consumed atomically", used is not None and int(used["used"]) == 1)

    # 已使用验证码不能再次注册
    status2, raw2 = client.request("POST", "/register", form={
        "username": user_name + "b", "password": reg_pw,
        "email": email, "email_code": reg_code})
    row2 = conn.execute("SELECT id FROM users WHERE username = ?", (user_name + "b",)).fetchone()
    record("reused register code rejected", row2 is None, "status=%s" % status2)

    # ---------- 3. 节点注册 + 审核 ----------
    status, ndata, _ = client.json("POST", "/api/nodes/register", payload={
        "node_id": node_ok_id, "name": "smoke-ok", "host": "127.0.0.1", "port": 7005})
    node_token = ndata.get("node_token")
    node_row = conn.execute("SELECT approved FROM nodes WHERE node_id = ?", (node_ok_id,)).fetchone()
    record("register node (pending by default)",
           status == 200 and ndata.get("success") is True and node_token
           and node_row is not None and int(node_row["approved"]) == 0,
           "status=%s approved=%s" % (status, node_row["approved"] if node_row else "missing"))

    status, ndata, _ = client.json("POST", "/api/nodes/register", payload={
        "node_id": node_pending_id, "name": "smoke-pending", "host": "127.0.0.1", "port": 7006})
    record("register second node", status == 200 and ndata.get("success") is True)

    status, adata, _ = client.json("PUT", "/api/nodes/%s/approve" % node_ok_id,
                                   payload={"approved": True})
    approved = conn.execute("SELECT approved FROM nodes WHERE node_id = ?", (node_ok_id,)).fetchone()
    record("admin approves node",
           status == 200 and adata.get("success") is True
           and approved is not None and int(approved["approved"]) == 1,
           "status=%s approved=%s" % (status, approved["approved"] if approved else "missing"))

    # ---------- 4. 建隧道：未审核 vs 已审核 ----------
    status, tdata, _ = client.json("POST", "/api/tunnels", payload={
        "name": "smoke-pending", "type": "tcp", "local_ip": "127.0.0.1",
        "local_port": 18080, "remote_port": remote_port, "node_id": node_pending_id})
    record("tunnel rejected on pending node", status == 400,
           "status=%s error=%s" % (status, tdata.get("error", "")))

    status, tdata, _ = client.json("POST", "/api/tunnels", payload={
        "name": "smoke-ok", "type": "tcp", "local_ip": "127.0.0.1",
        "local_port": 18080, "remote_port": remote_port, "node_id": node_ok_id})
    tunnel_id = tdata.get("tunnel_id")
    record("tunnel created on approved node",
           status == 200 and tdata.get("success") is True and tunnel_id,
           "status=%s tunnel_id=%s" % (status, tunnel_id))

    # 更新时省略 remote_port 应保持原端口
    if tunnel_id:
        status, udata, _ = client.json("PUT", "/api/tunnels/%s" % tunnel_id, payload={
            "name": "smoke-ok-edited", "local_ip": "127.0.0.1",
            "local_port": 18081, "node_id": node_ok_id})
        trow = conn.execute("SELECT remote_port, local_port FROM tunnels WHERE tunnel_id = ?",
                            (tunnel_id,)).fetchone()
        record("tunnel update keeps remote_port",
               status == 200 and trow is not None
               and int(trow["remote_port"]) == int(remote_port)
               and int(trow["local_port"]) == 18081,
               "status=%s remote_port=%s" % (status, trow["remote_port"] if trow else "missing"))

        status, tdata, _ = client.json("POST", "/api/tunnels", payload={
            "name": "smoke-invalid", "type": "ftp", "local_ip": "127.0.0.1",
            "local_port": 18080, "remote_port": remote_port + 1, "node_id": node_ok_id})
        record("tunnel invalid type rejected", status == 400,
               "status=%s error=%s" % (status, tdata.get("error", "")))

    # ---------- 5. 流量 API 结构 + 5 分钟 UTC 桶 ----------
    status, sdata, _ = client.json("GET", "/api/stats/traffic?hours=168")
    keys_ok = all(k in sdata for k in
                  ("hours", "points", "peak_up", "peak_down", "avg_up", "avg_down"))
    point_ok = isinstance(sdata.get("points"), list) and all(
        all(k in p for k in ("t", "up", "down", "cpu", "mem", "clients"))
        for p in sdata.get("points", []))
    aligned = all(int(p["t"]) % 300000 == 0 for p in sdata.get("points", []))
    record("traffic API shape", status == 200 and keys_ok and point_ok,
           "status=%s points=%s" % (status, len(sdata.get("points", []))))
    record("traffic buckets aligned to 5min UTC", aligned)

    # ---------- 6. OTP 保护接口未带验证码 -> 403 ----------
    for path in ("/api/regenerate-token", "/api/stop-all-tunnels", "/api/delete-account"):
        status, odata, _ = client.json("POST", path, payload={})
        record("OTP gate %s -> 403" % path,
               status == 403 and bool(odata.get("error")),
               "status=%s" % status)

    # ---------- 7. 未登录 -> 401 JSON ----------
    anon = Client()
    status, adata, _ = anon.json("GET", "/api/tunnels")
    record("anonymous /api/tunnels -> 401 JSON",
           status == 401 and adata.get("error") == "未登录", "status=%s" % status)

    # ---------- 清理 ----------
    try:
        conn.execute("DELETE FROM tunnels WHERE node_id IN (?, ?)", (node_ok_id, node_pending_id))
        conn.execute("DELETE FROM nodes WHERE node_id IN (?, ?)", (node_ok_id, node_pending_id))
        conn.execute("DELETE FROM email_codes WHERE target = ?", (email,))
        ids = [i for i in created_user_ids if i]
        if admin_id:
            ids.append(admin_id)
        for uid in ids:
            conn.execute("DELETE FROM checkins WHERE user_id = ?", (uid,))
            conn.execute("DELETE FROM tunnels WHERE user_id = ?", (uid,))
            conn.execute("DELETE FROM users WHERE id = ?", (uid,))
        conn.commit()
    except Exception as exc:  # noqa: BLE001
        print("cleanup warning:", exc)
    finally:
        conn.close()

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = len(RESULTS) - passed
    print("\n===== smoke summary: %d PASS / %d FAIL =====" % (passed, failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
