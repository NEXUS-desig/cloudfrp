"""Tunnel online/offline status via node heartbeat (stdlib only).

Runs against a live panel at 127.0.0.1:3592.
Prints PASS/FAIL per case and cleans up every row it creates.
"""
import http.cookiejar
import json
import secrets
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:3592"
DB = "frp_panel.db"
PASSWORD = "StatusTest#2026"
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS  " if cond else "FAIL  ") + name + (("  -- " + detail) if detail else ""))


def api(opener, method, path, body=None, form=False):
    headers = {}
    data = None
    if body is not None:
        if form:
            data = urllib.parse.urlencode(body).encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
    headers.setdefault("X-CloudFRP-Client", "launcher")
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    try:
        with opener.open(req, timeout=15) as resp:
            text = resp.read().decode("utf-8", "ignore")
            try:
                payload = json.loads(text) if text.strip() else {}
            except json.JSONDecodeError:
                payload = {}
            return resp.status, payload
    except urllib.error.HTTPError as exc:
        try:
            payload = json.loads(exc.read().decode("utf-8", "ignore") or "{}")
        except Exception:
            payload = {}
        return exc.code, payload


def main():
    # --- temp admin ---
    import bcrypt
    db = sqlite3.connect(DB)
    username = "z_status_" + secrets.token_hex(3)
    pw_hash = bcrypt.hashpw(PASSWORD.encode(), bcrypt.gensalt(rounds=10)).decode()
    db.execute("INSERT INTO users (username,password,email,role,points,membership_level,created_at) "
               "VALUES (?,?,?,'admin',0,'free',datetime('now'))",
               (username, pw_hash, username + "@local.test"))
    db.commit()
    db.close()

    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    status, _ = api(opener, "POST", "/login",
                    {"username": username, "password": PASSWORD, "captcha": "verified"},
                    form=True)
    check("login temp admin", status in (200, 302), "status=%s" % status)

    node_name = "z-status-node-" + secrets.token_hex(2)
    tunnel_name = "z-status-tunnel-" + secrets.token_hex(2)
    node_id = node_token = tunnel_id = None
    try:
        status, reg = api(opener, "POST", "/api/nodes/register", {
            "name": node_name, "host": "127.0.0.1", "port": 7000,
            "donated_by": username})
        node_id = reg.get("node_id")
        node_token = reg.get("node_token")
        check("register node", status == 200 and bool(node_id) and bool(node_token),
              "status=%s" % status)

        status, _ = api(opener, "PUT", "/api/nodes/%s/approve" % node_id, {"approved": True})
        check("approve node", status == 200, "status=%s" % status)

        status, created = api(opener, "POST", "/api/tunnels", {
            "name": tunnel_name, "type": "tcp", "local_ip": "127.0.0.1",
            "local_port": 8080, "remote_port": 20000 + secrets.randbelow(20000),
            "node_id": node_id})
        tunnel_id = created.get("tunnel_id")
        check("create tunnel on node", status == 200 and bool(tunnel_id),
              "status=%s" % status)

        def heartbeat(proxies_marker):
            payload = {"node_token": node_token,
                       "stats": {"cpu_usage": 1, "memory_usage": 2, "upload_speed": 3,
                                 "download_speed": 4, "total_upload": 5, "total_download": 6,
                                 "client_count": 1, "frps_healthy": True}}
            if proxies_marker is not None:
                payload["running_proxies"] = proxies_marker
            return api(opener, "POST", "/api/nodes/%s/heartbeat" % node_id, payload)

        def tunnel_status():
            st, data = api(opener, "GET", "/api/tunnels")
            for t in data.get("tunnels", []):
                if t.get("tunnel_id") == tunnel_id:
                    return t.get("status")
            return None

        check("initial status is stopped", tunnel_status() == "stopped", str(tunnel_status()))

        status, _ = heartbeat([tunnel_name])
        check("heartbeat reports running proxy", status == 200, "status=%s" % status)
        check("tunnel -> running", tunnel_status() == "running", str(tunnel_status()))

        status, _ = heartbeat([])
        check("heartbeat reports empty proxy list", status == 200, "status=%s" % status)
        check("tunnel -> stopped", tunnel_status() == "stopped", str(tunnel_status()))

        heartbeat([tunnel_name])
        before = tunnel_status()
        status, _ = heartbeat(None)
        check("heartbeat without key keeps state", status == 200 and tunnel_status() == before,
              "%s -> %s" % (before, tunnel_status()))

        heartbeat([tunnel_name, "x" * 500, 12345, "", "bad\x00name"])
        check("invalid proxy names ignored", tunnel_status() == "running", str(tunnel_status()))

        status, _ = api(opener, "POST", "/api/nodes/%s/heartbeat" % node_id,
                        {"node_token": node_token, "stats": {}, "running_proxies": "oops"})
        check("non-list running_proxies rejected", status == 400, "status=%s" % status)
    finally:
        if tunnel_id:
            api(opener, "DELETE", "/api/tunnels/%s" % tunnel_id)
        if node_id:
            api(opener, "DELETE", "/api/nodes/%s" % node_id)
        db = sqlite3.connect(DB)
        db.execute("DELETE FROM users WHERE username=?", (username,))
        db.commit()
        left = db.execute("SELECT COUNT(*) FROM users WHERE username=?", (username,)).fetchone()[0]
        db.close()
        check("cleanup", left == 0, "left=%s" % left)

    passed = sum(1 for _, ok, _ in results if ok)
    failed = len(results) - passed
    print("\n===== tunnel status summary: %d PASS / %d FAIL =====" % (passed, failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
