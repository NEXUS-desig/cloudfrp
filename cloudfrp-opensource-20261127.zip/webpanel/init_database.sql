-- 创建数据库
CREATE DATABASE IF NOT EXISTS frp_panel DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE frp_panel;

-- 面板配置表
CREATE TABLE IF NOT EXISTS panel_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_config_key (config_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    token VARCHAR(64) UNIQUE,
    avatar_url VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_token (token),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 隧道表
CREATE TABLE IF NOT EXISTS tunnels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tunnel_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    node_id VARCHAR(64) DEFAULT 'auto',
    type VARCHAR(20) DEFAULT 'tcp',
    local_ip VARCHAR(50) DEFAULT '127.0.0.1',
    local_port INT NOT NULL,
    remote_port INT NOT NULL,
    use_encryption BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'stopped',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_tunnel_id (tunnel_id),
    INDEX idx_remote_port (remote_port),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 节点表
CREATE TABLE IF NOT EXISTS nodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    node_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    host VARCHAR(255) NOT NULL,
    port INT NOT NULL,
    auth_token VARCHAR(255),
    node_token VARCHAR(64) UNIQUE NOT NULL,
    donated_by VARCHAR(100) DEFAULT '匿名',
    status VARCHAR(20) DEFAULT 'offline',
    last_heartbeat DATETIME,
    cpu_usage FLOAT DEFAULT 0,
    memory_usage FLOAT DEFAULT 0,
    upload_speed BIGINT DEFAULT 0,
    download_speed BIGINT DEFAULT 0,
    total_upload BIGINT DEFAULT 0,
    total_download BIGINT DEFAULT 0,
    client_count INT DEFAULT 0,
    daily_upload BIGINT DEFAULT 0,
    daily_download BIGINT DEFAULT 0,
    last_reset_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_node_id (node_id),
    INDEX idx_host (host),
    INDEX idx_status (status),
    INDEX idx_last_heartbeat (last_heartbeat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 节点统计表
CREATE TABLE IF NOT EXISTS node_stats (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    node_id VARCHAR(64) NOT NULL,
    cpu_usage FLOAT DEFAULT 0,
    memory_usage FLOAT DEFAULT 0,
    upload_speed BIGINT DEFAULT 0,
    download_speed BIGINT DEFAULT 0,
    total_upload BIGINT DEFAULT 0,
    total_download BIGINT DEFAULT 0,
    client_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_node_id (node_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 插入默认面板配置
INSERT INTO panel_config (config_key, config_value) VALUES
('server_port', '7001'),
('auth_token', 'yunwang'),
('dashboard_port', '8081')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- 插入默认管理员用户（密码: yunwang）
INSERT INTO users (username, password, email, token) 
VALUES ('admin', '057174c2c12b000e12e08626373452e1', 'admin@example.com', 'admin_token_001')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;
