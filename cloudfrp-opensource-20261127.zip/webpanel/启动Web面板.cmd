@echo off
chcp 936 >nul
title Cloud FRP Panel
cd /d "%~dp0"

echo ================================================
echo        Cloud FRP - Web Panel
echo ================================================
echo   URL:  http://localhost:3592
echo   Admin: admin / yunwang
echo   Ctrl+C to stop
echo ================================================
echo.

python server.py
pause
