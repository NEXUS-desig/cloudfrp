"""邮件服务：SMTP 发信 + 一次性验证码（高风险操作二次确认）。

配置（webpanel/.env）：
    SMTP_HOST=smtp.qq.com      # QQ 邮箱；163 为 smtp.163.com
    SMTP_PORT=465              # 465=SSL, 587=STARTTLS
    SMTP_USER=xxxx@qq.com      # 发件邮箱地址
    SMTP_PASS=<授权码>          # 邮箱设置里生成的 SMTP 授权码，不是登录密码
    SMTP_FROM=xxxx@qq.com      # 可省略，默认同 SMTP_USER
    SMTP_SSL=1                 # 默认 1；587 端口请设为 0

邮件模板：统一的品牌化 HTML（table + 内联样式，兼容 QQ/163/Outlook/Gmail），
logo 以 CID 内嵌（不依赖公网地址）。邮件只发送 HTML 版本，不再附带纯文本副本。
以后要新增通知邮件（登录提醒、会员到期等），直接调用 render_brand_email()
或 send_system_mail()，保持风格一致。
"""
import hashlib
import os
import secrets
import smtplib
from datetime import datetime, timedelta, timezone
from email.header import Header
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr, make_msgid

from app.database import db

CODE_TTL_MINUTES = 10
RESEND_SECONDS = 60
MAX_ATTEMPTS = 5

PURPOSES = {
    "register": "注册账号",
    "delete_account": "注销账户",
    "stop_all_tunnels": "停止所有隧道",
    "regenerate_token": "重新生成 Token",
}

_LOGO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "..", "static", "img", "email-logo.png")

# ---------- 模板 ----------
_PALETTE = {
    "bg": "#f7f9f8", "card": "#ffffff", "line": "#e3ebe9",
    "ink": "#06525c", "muted": "#2f737d", "faint": "#8aa5a8", "code_bg": "#f4f8f7",
}


def _brand_header() -> str:
    """logo（CID 内嵌，缺文件时回退 FR 方块）+ 品牌名"""
    if os.path.exists(_LOGO_PATH):
        mark = ('<img src="cid:logo" width="46" height="24" alt="CloudFRP" '
                'style="display:block;border-radius:5px;">')
    else:
        mark = ('<div style="width:32px;height:32px;background:#06525c;border-radius:7px;'
                'color:#ffffff;font:600 12px/32px Arial,sans-serif;text-align:center;">FR</div>')
    return ('<table role="presentation" cellpadding="0" cellspacing="0"><tr>'
            f'<td style="vertical-align:middle;">{mark}</td>'
            '<td style="padding-left:10px;font:600 17px/1 Arial,\'Microsoft YaHei\',sans-serif;'
            'color:#06525c;vertical-align:middle;">CloudFRP</td>'
            '</tr></table>')


def _otp_row(code: str) -> str:
    cells = []
    for i, d in enumerate(code):
        if i:
            cells.append('<td style="width:8px;font-size:0;line-height:0;">&nbsp;</td>')
        cells.append(
            f'<td width="42" height="52" align="center" valign="middle" '
            f'style="width:42px;height:52px;background:#ffffff;border:1px solid #e3ebe9;'
            f'border-radius:8px;font:600 22px/52px Consolas,\'Courier New\',monospace;color:#06525c;">'
            f'{d}</td>')
    return ('<table role="presentation" cellpadding="0" cellspacing="0" align="center" '
            'style="margin:0 auto;"><tr>' + "".join(cells) + "</tr></table>")


def render_brand_email(title: str, intro: str, code: str | None = None,
                       note: str | None = None, warning: str | None = None) -> str:
    """统一品牌邮件模板（未来所有通知邮件复用）。

    title   —— 主标题（如：操作验证）
    intro   —— 一段说明（可含简单 HTML）
    code    —— 6 位验证码，传了才显示 OTP 格
    note    —— 验证码下方的小字（如：10 分钟内有效）
    warning —— 底部安全提示
    """
    p = _PALETTE
    code_block = ""
    if code:
        code_block = f"""
      <tr><td style="padding:22px 32px 0;">
        {_otp_row(code)}
        <p style="margin:12px 0 0;font:13px/1.6 Arial,'Microsoft YaHei',sans-serif;color:{p['faint']};text-align:center;">
          {note or f'{CODE_TTL_MINUTES} 分钟内有效 · 仅可使用一次'}
        </p>
      </td></tr>"""
    warn_block = ""
    if warning:
        warn_block = f"""
      <tr><td style="padding:18px 32px 0;">
        <p style="margin:0;font:13px/1.75 Arial,'Microsoft YaHei',sans-serif;color:{p['faint']};">
          {warning}
        </p>
      </td></tr>"""

    return f"""<!doctype html>
<html lang="zh-CN"><body style="margin:0;padding:0;background:{p['bg']};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:{p['bg']};padding:32px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
           style="max-width:560px;background:{p['card']};border:1px solid {p['line']};border-radius:12px;">
      <tr><td style="padding:26px 32px 0;">{_brand_header()}</td></tr>
      <tr><td style="padding:22px 32px 0;">
        <h1 style="margin:0 0 8px;font:600 20px/1.4 Arial,'Microsoft YaHei',sans-serif;color:{p['ink']};">{title}</h1>
        <p style="margin:0;font:14px/1.75 Arial,'Microsoft YaHei',sans-serif;color:{p['muted']};">{intro}</p>
      </td></tr>{code_block}
      <tr><td style="padding:22px 32px 0;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
          <tr><td style="border-top:1px solid {p['line']};font-size:0;line-height:0;">&nbsp;</td></tr>
        </table>
      </td></tr>{warn_block}
      <tr><td style="padding:18px 32px 26px;">
        <p style="margin:0;font:12px/1.6 Arial,'Microsoft YaHei',sans-serif;color:#a3b8ba;">
          本邮件由系统自动发送，请勿直接回复。&nbsp;&nbsp;© 2026 CloudFRP
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>"""


def _render_code_email(action: str, code: str, ttl: int) -> str:
    return render_brand_email(
        title="操作验证",
        intro=f"您正在执行高风险操作「{action}」。请输入以下验证码完成确认：",
        code=code,
        note=f"验证码 {ttl} 分钟内有效，仅可使用一次。",
        warning="如非本人操作，请忽略本邮件，并尽快修改密码或联系管理员。",
    )


# ---------- SMTP ----------
def _cfg(key, default=""):
    return (os.environ.get(key) or default).strip()


def is_configured() -> bool:
    return bool(_cfg("SMTP_HOST") and _cfg("SMTP_USER") and _cfg("SMTP_PASS"))


def _hash(code: str) -> str:
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def _build_message(to_addr: str, subject: str, body: str, html: str | None = None,
                   inline_images: list[tuple[str, str]] | None = None):
    """构造邮件。有 HTML 时只发送 HTML（不再附带纯文本副本）。"""
    if html:
        if inline_images:
            msg = MIMEMultipart("related")
            msg.attach(MIMEText(html, "html", "utf-8"))
            for cid, path in inline_images:
                try:
                    with open(path, "rb") as f:
                        img = MIMEImage(f.read())
                    img.add_header("Content-ID", f"<{cid}>")
                    img.add_header("Content-Disposition", "inline", filename=os.path.basename(path))
                    msg.attach(img)
                except OSError:
                    pass
        else:
            msg = MIMEText(html, "html", "utf-8")
    else:
        # 防御性回退：调用方未提供 HTML 时才发纯文本
        msg = MIMEText(body, "plain", "utf-8")

    msg["Subject"] = Header(subject, "utf-8")
    sender_addr = _cfg("SMTP_FROM", _cfg("SMTP_USER"))
    msg["From"] = formataddr((str(Header("CloudFRP", "utf-8")), sender_addr))
    msg["To"] = to_addr
    msg["Message-ID"] = make_msgid(domain=sender_addr.split("@")[-1] if "@" in sender_addr else None)
    return msg


def _send_mail(to_addr: str, subject: str, body: str, html: str | None = None,
               inline_images: list[tuple[str, str]] | None = None) -> None:
    host = _cfg("SMTP_HOST")
    port = int(_cfg("SMTP_PORT", "465") or 465)
    user = _cfg("SMTP_USER")
    password = _cfg("SMTP_PASS")
    sender = _cfg("SMTP_FROM", user)
    use_ssl = _cfg("SMTP_SSL", "1") != "0"

    msg = _build_message(to_addr, subject, body, html=html, inline_images=inline_images)

    if use_ssl:
        server = smtplib.SMTP_SSL(host, port, timeout=15)
    else:
        server = smtplib.SMTP(host, port, timeout=15)
        server.starttls()
    try:
        server.login(user, password)
        server.sendmail(sender, [to_addr], msg.as_string())
    finally:
        try:
            server.quit()
        except Exception:
            pass


def _logo_inline() -> list[tuple[str, str]]:
    return [("logo", os.path.abspath(_LOGO_PATH))] if os.path.exists(_LOGO_PATH) else []


def send_system_mail(to_addr: str, subject: str, title: str, intro: str,
                     note: str | None = None, warning: str | None = None) -> tuple[bool, str]:
    """通用通知邮件（登录提醒、会员到期等复用它）。"""
    if not is_configured():
        return False, "邮件服务未配置"
    html = render_brand_email(title=title, intro=intro, note=note, warning=warning)
    try:
        _send_mail(to_addr, subject, "", html=html, inline_images=_logo_inline())
        return True, "已发送"
    except Exception as e:  # noqa: BLE001
        return False, str(e)[:120]


# ---------- 验证码 ----------
def issue_code(user_id: int, purpose: str, to_addr: str, target: str | None = None) -> tuple[bool, str]:
    if purpose not in PURPOSES:
        return False, "未知的验证用途"
    if not is_configured():
        return False, "邮件服务未配置：请在 webpanel/.env 填写 SMTP_HOST/SMTP_USER/SMTP_PASS 后重启"
    if not to_addr:
        return False, "当前账号没有绑定邮箱，请先在个人中心填写邮箱"

    if target:
        row = db.fetchone(
            "SELECT created_at FROM email_codes WHERE target = ? AND purpose = ? "
            "ORDER BY id DESC LIMIT 1", (target, purpose))
    else:
        row = db.fetchone(
            "SELECT created_at FROM email_codes WHERE user_id = ? AND purpose = ? "
            "ORDER BY id DESC LIMIT 1", (user_id, purpose))
    if row and row.get("created_at"):
        try:
            last = datetime.fromisoformat(str(row["created_at"]))
            # created_at 由 SQLite CURRENT_TIMESTAMP 生成（UTC，无时区标记）
            if last.tzinfo is None:
                last = last.replace(tzinfo=timezone.utc)
            elapsed = (datetime.now(timezone.utc) - last).total_seconds()
            if 0 <= elapsed < RESEND_SECONDS:
                wait = RESEND_SECONDS - int(elapsed)
                return False, f"发送太频繁，请 {wait} 秒后再试"
        except ValueError:
            pass

    code = f"{secrets.randbelow(1000000):06d}"
    expires = (datetime.now() + timedelta(minutes=CODE_TTL_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
    if target:
        db.execute(
            "INSERT INTO email_codes (user_id, purpose, code_hash, attempts, expires_at, used, target) "
            "VALUES (0, ?, ?, 0, ?, 0, ?)",
            (purpose, _hash(code), expires, target))
    else:
        db.execute(
            "INSERT INTO email_codes (user_id, purpose, code_hash, attempts, expires_at, used) "
            "VALUES (?, ?, ?, 0, ?, 0)",
            (user_id, purpose, _hash(code), expires))

    action = PURPOSES[purpose]
    try:
        _send_mail(to_addr, f"「CloudFRP」操作验证码：{action}", "",
                   html=_render_code_email(action, code, CODE_TTL_MINUTES),
                   inline_images=_logo_inline())
    except Exception as e:  # noqa: BLE001
        return False, "邮件发送失败：" + str(e)[:120]
    return True, "验证码已发送到 " + to_addr


def consume_code(user_id: int, purpose: str, code: str) -> tuple[bool, str]:
    if not code or not code.strip():
        return False, "请输入邮箱验证码"
    row = db.fetchone(
        "SELECT id, code_hash, attempts, expires_at, used FROM email_codes "
        "WHERE user_id = ? AND purpose = ? ORDER BY id DESC LIMIT 1",
        (user_id, purpose))
    return _consume_row(row, code)


def consume_code_for_email(email: str, purpose: str, code: str) -> tuple[bool, str]:
    """注册场景：验证码按目标邮箱校验（账号尚未创建）。"""
    if not code or not code.strip():
        return False, "请输入邮箱验证码"
    row = db.fetchone(
        "SELECT id, code_hash, attempts, expires_at, used FROM email_codes "
        "WHERE target = ? AND purpose = ? ORDER BY id DESC LIMIT 1",
        (email, purpose))
    return _consume_row(row, code)


def _consume_row(row, code: str) -> tuple[bool, str]:
    if not row:
        return False, "请先获取邮箱验证码"
    if int(row["used"] or 0):
        return False, "验证码已使用，请重新获取"
    try:
        if datetime.now() > datetime.fromisoformat(str(row["expires_at"])):
            return False, "验证码已过期，请重新获取"
    except ValueError:
        return False, "验证码已失效，请重新获取"
    if int(row["attempts"] or 0) >= MAX_ATTEMPTS:
        return False, "尝试次数过多，请重新获取验证码"

    if _hash(code.strip()) != row["code_hash"]:
        # 原子累加尝试次数，避免并发绕过次数限制
        db.execute_rowcount(
            "UPDATE email_codes SET attempts = attempts + 1 "
            "WHERE id = ? AND used = 0 AND attempts < ?",
            (row["id"], MAX_ATTEMPTS))
        return False, "验证码不正确"

    # 原子消费：used/过期/次数条件全部放进 UPDATE，rowcount 判定唯一赢家
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    consumed = db.execute_rowcount(
        "UPDATE email_codes SET used = 1 "
        "WHERE id = ? AND used = 0 AND attempts < ? AND expires_at > ?",
        (row["id"], MAX_ATTEMPTS, now_str))
    if consumed != 1:
        return False, "验证码已使用或已过期，请重新获取"
    return True, "ok"
