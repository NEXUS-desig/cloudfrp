"""面板数据容灾：SQLite 自动快照、手动备份、在线恢复。"""
import glob
import os
import sqlite3
import threading
import time

from config import config

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BACKUP_DIR = os.path.join(ROOT, "backups")
KEEP = 12
_lock = threading.Lock()
_started = False


def _require_sqlite():
    if config.USE_MYSQL:
        raise RuntimeError("当前使用 MySQL，请在服务器上用 mysqldump 备份/恢复")


def ensure_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    return BACKUP_DIR


def _stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def create_backup(prefix="manual"):
    """用 SQLite 在线备份 API 生成一致快照，返回文件路径。"""
    _require_sqlite()
    ensure_dir()
    with _lock:
        name = "cloudfrp-%s-%s.db" % (prefix, _stamp())
        path = os.path.join(BACKUP_DIR, name)
        src = sqlite3.connect(config.SQLITE_DB_PATH, timeout=15)
        dst = sqlite3.connect(path)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        prune()
        return path


def prune(keep=KEEP):
    files = sorted(glob.glob(os.path.join(BACKUP_DIR, "cloudfrp-*.db")),
                   key=os.path.getmtime, reverse=True)
    for old in files[keep:]:
        try:
            os.remove(old)
        except OSError:
            pass


def list_backups():
    ensure_dir()
    items = []
    for path in sorted(glob.glob(os.path.join(BACKUP_DIR, "cloudfrp-*.db")),
                       key=os.path.getmtime, reverse=True):
        try:
            stat = os.stat(path)
        except OSError:
            continue
        items.append({
            "name": os.path.basename(path),
            "size": stat.st_size,
            "mtime": int(stat.st_mtime),
        })
    return items


def validate_backup(path):
    """校验上传文件确实是本面板的 SQLite 数据库。返回 (ok, message)。"""
    try:
        if os.path.getsize(path) < 4096:
            return False, "备份文件过小，不是有效数据库"
        conn = sqlite3.connect(path)
        try:
            check = conn.execute("PRAGMA integrity_check").fetchone()
            if not check or check[0] != "ok":
                return False, "数据库完整性校验失败"
            tables = {row[0] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
        required = {"users", "tunnels", "nodes"}
        missing = required - tables
        if missing:
            return False, "缺少数据表：" + ", ".join(sorted(missing))
        return True, "ok"
    except sqlite3.DatabaseError:
        return False, "不是有效的 SQLite 数据库"
    except OSError:
        return False, "无法读取备份文件"


def restore_backup(path):
    """在线把备份内容写回当前库；恢复前自动生成 pre-restore 快照。"""
    _require_sqlite()
    ok, message = validate_backup(path)
    if not ok:
        return False, message
    pre = create_backup("pre-restore")
    with _lock:
        src = sqlite3.connect(path, timeout=15)
        dst = sqlite3.connect(config.SQLITE_DB_PATH, timeout=30)
        try:
            src.backup(dst)
        except sqlite3.DatabaseError as exc:
            return False, "恢复失败：%s（恢复前快照：%s）" % (exc, os.path.basename(pre))
        finally:
            dst.close()
            src.close()
    # 恢复旧库后补齐新增字段
    try:
        from app.database import db
        db.init_tables()
    except Exception as exc:  # noqa: BLE001
        print("[!] 恢复后迁移失败: %s" % exc)
    return True, "恢复完成，恢复前快照：%s" % os.path.basename(pre)


def start_backup_scheduler():
    """每 6 小时自动快照一次，保留最近 12 份。"""
    global _started
    if _started or config.USE_MYSQL:
        return
    _started = True

    def loop():
        time.sleep(30)
        while True:
            try:
                path = create_backup("auto")
                print("[backup] 自动快照: %s" % path)
            except Exception as exc:  # noqa: BLE001
                print("[!] 自动备份失败: %s" % exc)
            time.sleep(6 * 3600)

    threading.Thread(target=loop, daemon=True, name="cloudfrp-backup").start()
