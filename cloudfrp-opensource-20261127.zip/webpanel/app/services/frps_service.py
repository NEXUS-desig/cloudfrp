"""
Cross-platform FRP server process management.

Abstracts the Windows-specific tasklist/taskkill/frps.exe calls that were
hard-coded in the original server.py so the panel runs identically on
Windows and Linux. Resolves the frps binary name per-OS and uses pure-Python
process checks (psutil) instead of shelling out to tasklist.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
import urllib.request

try:
    import psutil
except ImportError:            # psutil is in requirements, but degrade gracefully
    psutil = None

# frps binary name differs between Windows and everything else
FRPS_BINARY = "frps.exe" if os.name == "nt" else "frps"

# 本机 frps 的管理 API（只监听 127.0.0.1），用于查询已连上的 proxy
LOCAL_ADMIN_PORT = 7401
LOCAL_ADMIN_USER = "cfpanel"

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _arch_tag() -> str:
    machine = platform.machine().lower()
    return {
        "x86_64": "amd64", "amd64": "amd64",
        "aarch64": "arm64", "arm64": "arm64",
        "armv7l": "arm", "armv6l": "arm", "armhf": "arm",
        "i386": "386", "i686": "386",
    }.get(machine, machine)


def _candidate_bins():
    env = os.environ.get("FRPS_BIN")
    if env:
        yield env
    yield os.path.join(_BASE_DIR, FRPS_BINARY)
    if os.name != "nt":
        yield "/usr/local/bin/frps"
        yield os.path.join(_BASE_DIR, "app", "static", "bin", "frps-linux-" + _arch_tag())


def _frps_path() -> str:
    """Absolute path to the frps binary (first existing candidate)."""
    candidates = list(_candidate_bins())
    for path in candidates:
        if os.path.isfile(path):
            if os.name != "nt" and not os.access(path, os.X_OK):
                try:
                    os.chmod(path, 0o755)
                except OSError:
                    pass
            return path
    return candidates[0]


def _admin_password() -> str:
    token = (os.environ.get("DEFAULT_AUTH_TOKEN") or "yunwang").strip() or "yunwang"
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


def _default_config_text() -> str:
    token = (os.environ.get("DEFAULT_AUTH_TOKEN") or "yunwang").strip() or "yunwang"
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", token):
        token = "yunwang"
    return (
        'bindAddr = "0.0.0.0"\n'
        'bindPort = 7000\n'
        'auth.token = "%s"\n'
        'webServer.addr = "127.0.0.1"\n'
        'webServer.port = %d\n'
        'webServer.user = "%s"\n'
        'webServer.password = "%s"\n'
        'transport.maxPoolCount = 1000\n'
        'transport.tcpMux = true\n'
        'log.level = "info"\n'
        % (token, LOCAL_ADMIN_PORT, LOCAL_ADMIN_USER, _admin_password())
    )


def _frps_config(create: bool = False) -> str:
    """Absolute path to frps config (toml preferred, ini fallback)."""
    for name in ("frps.toml", "frps.ini"):
        p = os.path.join(_BASE_DIR, name)
        if os.path.exists(p):
            return p
    path = os.path.join(_BASE_DIR, "frps.toml")
    if create:
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(_default_config_text())
            os.chmod(path, 0o600)
        except OSError:
            pass
    return path


def _admin_creds():
    """从 frps.toml 读取本机管理 API 的端口与凭据。"""
    try:
        with open(_frps_config(), "r", encoding="utf-8") as fh:
            text = fh.read()
    except OSError:
        return None
    port = re.search(r'^\s*webServer\.port\s*=\s*(\d+)', text, re.M)
    user = re.search(r'^\s*webServer\.user\s*=\s*"([^"]*)"', text, re.M)
    pwd = re.search(r'^\s*webServer\.password\s*=\s*"([^"]*)"', text, re.M)
    if not (port and user and pwd):
        return None
    return {"port": int(port.group(1)), "user": user.group(1), "password": pwd.group(1)}


def _ensure_admin_block(path: str) -> None:
    """老配置没有 webServer 段时补上（仅 TOML）。"""
    if not path.endswith(".toml"):
        return
    try:
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
    except OSError:
        return
    if "webServer.port" in text:
        return
    block = (
        '\nwebServer.addr = "127.0.0.1"\n'
        'webServer.port = %d\n'
        'webServer.user = "%s"\n'
        'webServer.password = "%s"\n'
        % (LOCAL_ADMIN_PORT, LOCAL_ADMIN_USER, _admin_password())
    )
    try:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(block)
    except OSError:
        pass


def collect_local_proxies():
    """查询本机 frps 已注册的 proxy 名；未配置/不可达 → None。"""
    creds = _admin_creds()
    if not creds:
        return None
    auth = base64.b64encode(
        ("%s:%s" % (creds["user"], creds["password"])).encode("utf-8")).decode("ascii")
    headers = {"Authorization": "Basic " + auth}
    names = set()
    got_any = False
    for kind in ("tcp", "udp", "http", "https"):
        url = "http://127.0.0.1:%d/api/proxy/%s" % (creds["port"], kind)
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=1) as resp:
                body = json.loads(resp.read().decode("utf-8", "replace") or "{}")
            got_any = True
        except Exception:  # noqa: BLE001
            continue
        for item in (body.get("proxies") or []):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            state = str(item.get("status") or "").strip().lower()
            if name and (not state or state in ("running", "online", "started")):
                names.add(name)
    if not got_any:
        return None
    clean = []
    for name in sorted(names)[:500]:
        name = name[:100]
        if name and all(ord(ch) >= 32 and ord(ch) != 127 for ch in name):
            clean.append(name)
    return clean


def sync_auto_tunnel_statuses():
    """按本机 frps 的 proxy 列表更新「自动节点」隧道的在线状态。"""
    names = collect_local_proxies()
    if names is None:
        return False
    try:
        from ..database import db
        reported = set(names)
        rows = db.fetchall(
            "SELECT t.tunnel_id, t.name, u.token FROM tunnels t "
            "LEFT JOIN users u ON u.id = t.user_id "
            "WHERE t.node_id = ? OR t.node_id IS NULL", ("auto",))
        for row in rows:
            name = str(row.get("name") or "")
            token = str(row.get("token") or "").strip()
            keys = {name}
            if token:
                keys.add(token + "." + name)
            status = "running" if keys & reported else "stopped"
            db.execute("UPDATE tunnels SET status = ? WHERE tunnel_id = ?",
                       (status, row.get("tunnel_id")))
        return True
    except Exception:  # noqa: BLE001 - 状态同步失败不能拖垮列表
        return False


def is_frps_running() -> bool:
    """True if a frps process is currently running (any platform)."""
    if psutil is None:
        return False
    for proc in psutil.process_iter(["name"]):
        try:
            name = (proc.info["name"] or "").lower()
            if name.startswith("frps"):
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return False


def start_frps() -> tuple[bool, str]:
    """Start the frps server. Returns (success, message)."""
    if is_frps_running():
        return False, "FRP服务端已在运行"

    bin_path = _frps_path()
    if not os.path.exists(bin_path):
        return False, f"找不到 {FRPS_BINARY}"

    cfg = _frps_config(create=True)
    _ensure_admin_block(cfg)
    try:
        if os.name == "nt":
            # Windows: open in a new console window so logs are visible
            subprocess.Popen(
                [bin_path, "-c", cfg],
                creationflags=subprocess.CREATE_NEW_CONSOLE,
                cwd=_BASE_DIR,
            )
        else:
            # Linux/macOS: detach into its own session, log to file
            log_path = os.path.join(_BASE_DIR, "frps.log")
            logf = open(log_path, "ab")
            subprocess.Popen(
                [bin_path, "-c", cfg],
                stdout=logf,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                cwd=_BASE_DIR,
            )
        return True, "FRP服务端启动成功"
    except Exception as e:  # noqa: BLE001 - surface any spawn failure to the client
        return False, str(e)


def stop_frps() -> tuple[bool, str]:
    """Stop any running frps process. Returns (success, message)."""
    if psutil is None:
        return False, "psutil 未安装，无法停止"
    killed = 0
    for proc in psutil.process_iter(["name"]):
        try:
            name = (proc.info["name"] or "").lower()
            if name.startswith("frps"):
                proc.terminate()
                killed += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if killed:
        return True, "FRP服务端已停止"
    return False, "没有正在运行的 FRP服务端"


# ── 后台状态同步（避免每次请求都查 frps） ─────────────────────────────
_sync_started = False
_sync_lock = threading.Lock()


def start_background_sync(interval=5):
    """每 N 秒刷新一次「自动节点」隧道状态；只启动一次。"""
    global _sync_started
    with _sync_lock:
        if _sync_started:
            return
        _sync_started = True

    def loop():
        while True:
            try:
                if is_frps_running():
                    sync_auto_tunnel_statuses()
            except Exception:  # noqa: BLE001
                pass
            time.sleep(interval)

    threading.Thread(target=loop, name="cloudfrp-status-sync", daemon=True).start()
