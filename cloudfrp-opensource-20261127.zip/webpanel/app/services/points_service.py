"""
积分服务 - 处理积分、签到、会员相关的业务逻辑
"""
import random
from datetime import datetime, timedelta
from app.database import db


class PointsService:
    """积分服务类"""
    
    @staticmethod
    def get_user_points(user_id):
        """获取用户积分信息"""
        user = db.fetchone('SELECT points, membership_level, membership_expiry FROM users WHERE id = ?', (user_id,))
        if not user:
            return None
        
        # 获取签到统计
        today = datetime.now().strftime('%Y-%m-%d')
        checkin_count = db.fetchone(
            'SELECT COUNT(*) as count FROM checkins WHERE user_id = ?',
            (user_id,)
        )['count']
        
        return {
            'points': user.get('points', 0) or 0,
            'membership_level': user.get('membership_level', 0) or 0,
            'membership_expiry': user.get('membership_expiry'),
            'checkin_count': checkin_count
        }
    
    @classmethod
    def checkin(cls, user_id):
        """用户签到（原子操作，防止并发重复发放积分）"""
        today = datetime.now().strftime('%Y-%m-%d')

        # 计算签到积分（基础5分，随机加成0-5分）+ 会员积分加成
        points = 5 + random.randint(0, 5)
        bonus = 0
        try:
            row = db.fetchone(
                "SELECT l.points_bonus FROM users u JOIN membership_levels l ON l.id = u.membership_level "
                "WHERE u.id = ?", (user_id,))
            if row:
                bonus = int(row.get("points_bonus") or 0)
        except Exception:
            bonus = 0
        if bonus > 0:
            points += int(round(points * bonus / 100.0))

        # 单条 UPDATE 完成 compare-and-set：只有更新成功（rowcount=1）才发放奖励
        updated = db.execute_rowcount('''
            UPDATE users SET
                points = COALESCE(points, 0) + ?,
                last_checkin_date = ?
            WHERE id = ? AND (last_checkin_date IS NULL OR last_checkin_date != ?)
        ''', (points, today, user_id, today))
        if updated != 1:
            return False, '今天已经签到过了'

        # 记录签到（仅在原子更新成功后）
        db.execute('''
            INSERT INTO checkins (user_id, points) VALUES (?, ?)
        ''', (user_id, points))

        message = f'签到成功，获得 {points} 积分'
        if bonus > 0:
            message += f'（会员加成 {bonus}%）'
        return True, {'points': points, 'message': message}
    
    @staticmethod
    def get_checkin_stats(user_id):
        """获取签到统计"""
        # 总签到次数
        total = db.fetchone(
            'SELECT COUNT(*) as count FROM checkins WHERE user_id = ?',
            (user_id,)
        )['count']
        
        # 本月签到次数
        month_start = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        month = db.fetchone(
            'SELECT COUNT(*) as count FROM checkins WHERE user_id = ? AND created_at >= ?',
            (user_id, month_start)
        )['count']
        
        # 连续签到天数
        streak = 0
        checkins = db.fetchall(
            'SELECT DATE(created_at) as date FROM checkins WHERE user_id = ? ORDER BY created_at DESC',
            (user_id,)
        )
        if checkins:
            today = datetime.now().date()
            for i, c in enumerate(checkins):
                expected_date = today - timedelta(days=i)
                if c['date'] == expected_date.strftime('%Y-%m-%d'):
                    streak += 1
                else:
                    break
        
        return {'total': total, 'month': month, 'streak': streak}
    
    @staticmethod
    def get_membership_levels():
        """获取会员等级列表"""
        return db.fetchall('SELECT * FROM membership_levels ORDER BY points_required ASC')
    
    @staticmethod
    def _is_free_level(level):
        """free / 免费档：积分 0 且有效期 0（如 level 1 'free'）。"""
        name = str(level.get('level_name') or '').strip().lower()
        if name in ('free', '免费', '免费档'):
            return True
        try:
            return int(level.get('points_required') or 0) == 0 and \
                int(level.get('duration_days') or 0) == 0
        except (TypeError, ValueError):
            return False

    @classmethod
    def exchange_membership(cls, user_id, level_id):
        """兑换会员（原子扣分，防止并发超额兑换）"""
        try:
            level_id = int(level_id)
        except (TypeError, ValueError):
            return False, '会员等级无效'
        user = db.fetchone('SELECT points FROM users WHERE id = ?', (user_id,))
        level = db.fetchone('SELECT * FROM membership_levels WHERE id = ?', (level_id,))
        
        if not user or not level:
            return False, '用户或会员等级不存在'
        
        cost = int(level.get('points_required') or 0)
        if cost < 0:
            cost = 0
        if (user.get('points', 0) or 0) < cost:
            return False, '积分不足'
        
        # 免费档不设置到期时间；付费档按等级时长计算
        duration = int(level.get('duration_days') or 30)
        if cls._is_free_level(level) or duration >= 99999:
            expiry = None  # 免费档或永久档
        else:
            expiry = datetime.now() + timedelta(days=duration)
        
        # 原子扣分：余额在条件中复核，避免两次请求同时通过余额检查
        claimed = db.execute_rowcount('''
            UPDATE users SET
                points = points - ?,
                membership_level = ?,
                membership_expiry = ?
            WHERE id = ? AND COALESCE(points, 0) >= ?
        ''', (cost, level_id, expiry, user_id, cost))
        if claimed != 1:
            return False, '积分不足'

        if expiry is None:
            return True, f'成功兑换 {level["level_name"]}（免费档）'
        return True, f'成功兑换 {level["level_name"]}，有效期至 {expiry.strftime("%Y-%m-%d")}'

    @staticmethod
    def _coerce_int(value, field):
        if isinstance(value, bool):
            raise ValueError(f'{field}必须为整数')
        if isinstance(value, float):
            if not value.is_integer():
                raise ValueError(f'{field}必须为整数')
            value = int(value)
        elif isinstance(value, str):
            value = int(value.strip())
        elif not isinstance(value, int):
            raise ValueError(f'{field}必须为整数')
        return value

    @staticmethod
    def update_user_points(user_id, points):
        """管理员修改用户积分（校验：非负整数、用户必须存在）"""
        try:
            points = PointsService._coerce_int(points, '积分')
        except (TypeError, ValueError):
            return False, '积分必须为非负整数'
        if points < 0:
            return False, '积分不能为负数'
        if not db.fetchone('SELECT id FROM users WHERE id = ?', (user_id,)):
            return False, '用户不存在'
        db.execute('UPDATE users SET points = ? WHERE id = ?', (points, user_id))
        return True, '积分已更新'

    @staticmethod
    def update_user_membership(user_id, level_id, days=30):
        """管理员修改用户会员（免费档写 NULL 到期时间，付费档校验天数）"""
        try:
            level_id = PointsService._coerce_int(level_id, '会员等级')
        except (TypeError, ValueError):
            return False, '会员等级无效'
        level = db.fetchone('SELECT * FROM membership_levels WHERE id = ?', (level_id,))
        if not level:
            return False, '会员等级不存在'

        if PointsService._is_free_level(level):
            expiry = None  # free 档无到期时间
        else:
            try:
                days = PointsService._coerce_int(days, '有效天数')
            except (TypeError, ValueError):
                return False, '有效天数无效'
            if days >= 99999:
                expiry = None  # 永久
            elif days < 1 or days > 3650:
                return False, '有效天数必须在 1-3650 之间（99999 = 永久）'
            else:
                expiry = datetime.now() + timedelta(days=days)

        if not db.fetchone('SELECT id FROM users WHERE id = ?', (user_id,)):
            return False, '用户不存在'
        db.execute('''
            UPDATE users SET membership_level = ?, membership_expiry = ? WHERE id = ?
        ''', (level_id, expiry, user_id))
        return True, '会员已更新'


class RedeemCodeService:
    """兑换码服务类"""
    
    @staticmethod
    def generate_code():
        """生成兑换码"""
        import secrets
        return secrets.token_hex(8).upper()
    
    @classmethod
    def use_code(cls, user_id, code):
        """使用兑换码（原子占用，防止同一兑换码被并发使用两次）"""
        code = (code or "").strip()
        if not code:
            return False, '兑换码不存在或已使用'
        code_info = db.fetchone('SELECT * FROM redeem_codes WHERE code = ? AND is_used = 0', (code,))

        if not code_info:
            return False, '兑换码不存在或已使用'

        # 先原子占用兑换码；rowcount=0 说明被其他请求抢先使用
        claimed = db.execute_rowcount('''
            UPDATE redeem_codes SET is_used = 1, used_by = ?, used_at = CURRENT_TIMESTAMP
            WHERE code = ? AND is_used = 0
        ''', (user_id, code))
        if claimed != 1:
            return False, '兑换码不存在或已使用'

        usage_type = code_info.get('usage_type', 'points')

        if usage_type == 'points':
            # 积分兑换
            db.execute('UPDATE users SET points = points + ? WHERE id = ?',
                      (int(code_info.get('points') or 0), user_id))
        elif usage_type == 'membership':
            # 会员兑换
            expiry = datetime.now() + timedelta(days=int(code_info.get('duration_days') or 30))
            db.execute('''
                UPDATE users SET membership_level = ?, membership_expiry = ? WHERE id = ?
            ''', (code_info['membership_level'], expiry, user_id))

        return True, '兑换成功'
    
    @staticmethod
    def get_all_codes():
        """获取所有兑换码"""
        return db.fetchall('''
            SELECT r.*, u.username as used_by_name
            FROM redeem_codes r
            LEFT JOIN users u ON r.used_by = u.id
            ORDER BY r.created_at DESC
        ''')
    
    @classmethod
    def create_code(cls, data, created_by):
        """创建兑换码"""
        code = data.get('code') or cls.generate_code()
        
        # 检查是否已存在
        existing = db.fetchone('SELECT id FROM redeem_codes WHERE code = ?', (code,))
        if existing:
            return False, '兑换码已存在'
        
        db.execute('''
            INSERT INTO redeem_codes 
            (code, points, membership_level, duration_days, usage_type, speed_upgrade, tunnel_upgrade, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            code,
            data.get('points', 0),
            data.get('membership_level'),
            data.get('duration_days', 30),
            data.get('usage_type', 'points'),
            data.get('speed_upgrade', 0),
            data.get('tunnel_upgrade', 0),
            created_by
        ))
        return True, code
    
    @staticmethod
    def delete_code(code_id):
        """删除兑换码"""
        db.execute('DELETE FROM redeem_codes WHERE id = ?', (code_id,))
        return True, '兑换码已删除'


# 全局服务实例
points_service = PointsService()
redeem_code_service = RedeemCodeService()
