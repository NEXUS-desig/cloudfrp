"""
节点服务 - 处理节点相关的业务逻辑
"""
import math
import re
import secrets
import time
from datetime import datetime, timezone
from app.database import db

_HOST_RE = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)"
                      r"(\.[A-Za-z0-9-]{1,63}(?<!-))*$")


def _valid_host(value):
    """节点 host：接受 IP 字面量或合法主机名，拒绝空白/控制字符。"""
    value = (value or "").strip()
    if not value or len(value) > 253:
        return False
    try:
        import ipaddress
        ipaddress.ip_address(value)
        return True
    except ValueError:
        pass
    return bool(_HOST_RE.match(value))


class NodeService:

    @staticmethod
    def _is_admin(username):
        from app.services.user_service import UserService
        return UserService.is_admin(username)
    """节点服务类"""
    
    @staticmethod
    def generate_node_token():
        """生成节点 Token"""
        return secrets.token_hex(16)
    
    @staticmethod
    def get_all_nodes():
        """获取所有节点"""
        nodes = db.fetchall('SELECT * FROM nodes ORDER BY created_at DESC')
        result = []
        for node in nodes:
            node_dict = dict(node)
            # 在线判定：优先用 epoch 秒（与数据库时区无关），兼容旧数据
            age = None
            hb_ts = node.get("last_heartbeat_ts")
            if hb_ts not in (None, ""):
                try:
                    age = time.time() - float(hb_ts)
                except (TypeError, ValueError):
                    age = None
            last_heartbeat = node.get('last_heartbeat')
            if age is None and last_heartbeat:
                if isinstance(last_heartbeat, str):
                    try:
                        last_heartbeat = datetime.fromisoformat(last_heartbeat.replace('Z', '+00:00'))
                    except Exception:
                        last_heartbeat = None
                if last_heartbeat:
                    # SQLite CURRENT_TIMESTAMP 是 UTC，统一按 UTC 比较
                    if last_heartbeat.tzinfo is None:
                        last_heartbeat = last_heartbeat.replace(tzinfo=timezone.utc)
                    age = (datetime.now(timezone.utc) - last_heartbeat).total_seconds()
            node_dict['heartbeat_age'] = int(max(0, age)) if age is not None else None
            node_dict['status'] = 'online' if (age is not None and age < 30) else 'offline'
            
            # 构建统计信息
            node_dict['stats'] = {
                'cpu_usage': node.get('cpu_usage', 0) or 0,
                'memory_usage': node.get('memory_usage', 0) or 0,
                'upload_speed': node.get('upload_speed', 0) or 0,
                'download_speed': node.get('download_speed', 0) or 0,
                'total_upload': node.get('total_upload', 0) or 0,
                'total_download': node.get('total_download', 0) or 0,
                'client_count': node.get('client_count', 0) or 0
            }
            result.append(node_dict)
        return result
    
    @staticmethod
    def get_node_by_id(node_id):
        """通过ID获取节点"""
        return db.fetchone('SELECT * FROM nodes WHERE node_id = ?', (node_id,))
    
    @classmethod
    def register_node(cls, node_id, data):
        """
        注册/更新节点
        返回: (success: bool, message: str, node_token: str|None)
        """
        node_id = str(node_id or "").strip()
        if not node_id or len(node_id) > 64:
            return False, '节点 ID 无效', None
        data = data or {}

        host = str(data.get('host') or '').strip()
        if not _valid_host(host):
            return False, '节点地址 host 格式无效', None
        try:
            port = int(data.get('port', 7001))
        except (TypeError, ValueError):
            return False, '节点端口必须为整数', None
        if port < 1 or port > 65535:
            return False, '节点端口必须在 1-65535 之间', None

        name = re.sub(r'[\x00-\x1f\x7f]', '', str(data.get('name') or '')).strip()[:100]
        if not name:
            name = f'节点-{node_id[:8]}'
        donated_by = re.sub(r'[\x00-\x1f\x7f]', '',
                            str(data.get('donated_by') or name or '匿名')).strip()[:100]
        auth_token = str(data.get('auth_token') or '').strip()
        # auth_token 会写入其他用户下载的 frpc TOML/INI，必须限制字符集，
        # 防止未认证注册者通过换行/引号注入配置。
        if auth_token and (len(auth_token) > 128
                           or not re.match(r'^[A-Za-z0-9._\-]+$', auth_token)):
            return False, 'auth_token 含不安全字符（仅允许字母、数字、点、下划线、连字符）', None

        existing = cls.get_node_by_id(node_id)

        if existing:
            # 节点已存在：必须先通过 node_token 认证，避免任意请求劫持节点
            provided = str(data.get('node_token') or '')
            expected = str(existing.get('node_token') or '')
            if not provided or not expected or not secrets.compare_digest(provided, expected):
                return False, '节点已存在，请提供有效的 node_token 以更新', None
            # 保留 node_token / approved / status 等既有状态
            db.execute('''
                UPDATE nodes SET
                    host = ?, port = ?, auth_token = ?, name = ?, donated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE node_id = ?
            ''', (host, port, auth_token, name, donated_by, node_id))
            return True, '节点更新成功', expected
        else:
            # 新建节点：approved 默认为 0（等待管理员审核）
            node_token = cls.generate_node_token()
            db.execute('''
                INSERT INTO nodes
                (node_id, name, host, port, auth_token, node_token, donated_by, status, approved)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'offline', 0)
            ''', (node_id, name, host, port, auth_token, node_token, donated_by))
            return True, '节点注册成功，等待管理员审核', node_token
    
    @classmethod
    def approve_node(cls, node_id, approved):
        """管理员审核节点：通过 / 取消"""
        node = cls.get_node_by_id(node_id)
        if not node:
            return False, '节点不存在'
        db.execute("UPDATE nodes SET approved = ?, updated_at = CURRENT_TIMESTAMP WHERE node_id = ?",
                   (1 if approved else 0, node_id))
        return True, ('节点已通过审核' if approved else '已取消节点审核')

    @staticmethod
    def _sanitize_stats(stats):
        """心跳统计清洗：强制数值、有限值、非负。"""
        stats = stats or {}

        def num(key, integer=False):
            try:
                v = float(stats.get(key, 0))
            except (TypeError, ValueError):
                v = 0.0
            if not math.isfinite(v) or v < 0:
                v = 0.0
            return int(v) if integer else v

        return {
            'cpu_usage': num('cpu_usage'),
            'memory_usage': num('memory_usage'),
            'upload_speed': num('upload_speed'),
            'download_speed': num('download_speed'),
            'total_upload': num('total_upload', integer=True),
            'total_download': num('total_download', integer=True),
            'client_count': num('client_count', integer=True),
        }

    @classmethod
    def update_heartbeat(cls, node_id, node_token, stats, running_proxies=None, proxy_traffic=None):
        """
        更新节点心跳 — 需验证 node_token
        running_proxies: None = 客户端未上报（不动隧道状态）；列表 = frps 当前已注册的 proxy 名
        返回: True / 'invalid_token' / 'not_found' / False
        """
        node = cls.get_node_by_id(node_id)
        if not node:
            return 'not_found'

        # 验证 node_token（常量时间比较，避免时序侧信道）
        expected = str(node.get('node_token') or '')
        provided = str(node_token or '')
        if not expected or not provided or not secrets.compare_digest(provided, expected):
            return 'invalid_token'

        stats = cls._sanitize_stats(stats)

        # 检查是否需要重置每日流量（SQLite CURRENT_TIMESTAMP 为 UTC，日期同样用 UTC）
        today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
        daily_upload = max(int(node.get('daily_upload') or 0), 0)
        daily_download = max(int(node.get('daily_download') or 0), 0)

        if node.get('last_reset_date') != today:
            daily_upload = 0
            daily_download = 0

        # 计算今日流量增量
        old_total_upload = max(int(node.get('total_upload') or 0), 0)
        old_total_download = max(int(node.get('total_download') or 0), 0)
        new_total_upload = stats['total_upload']
        new_total_download = stats['total_download']

        if new_total_upload > old_total_upload:
            daily_upload += (new_total_upload - old_total_upload)
        if new_total_download > old_total_download:
            daily_download += (new_total_download - old_total_download)

        db.execute('''
            UPDATE nodes SET
                status = 'online',
                last_heartbeat = CURRENT_TIMESTAMP,
                last_heartbeat_ts = ?,
                cpu_usage = ?, memory_usage = ?,
                upload_speed = ?, download_speed = ?,
                total_upload = ?, total_download = ?,
                client_count = ?,
                daily_upload = ?, daily_download = ?,
                last_reset_date = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE node_id = ?
        ''', (
            time.time(),
            stats['cpu_usage'],
            stats['memory_usage'],
            stats['upload_speed'],
            stats['download_speed'],
            new_total_upload,
            new_total_download,
            stats['client_count'],
            daily_upload,
            daily_download,
            today,
            node_id
        ))

        # 时序采样（折线图数据源）；顺带清理 7 天前的旧样本
        db.execute(
            "INSERT INTO traffic_samples (node_id, up_speed, down_speed, cpu_usage, memory_usage, client_count) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (node_id,
             stats['upload_speed'],
             stats['download_speed'],
             stats['cpu_usage'],
             stats['memory_usage'],
             stats['client_count']))
        try:
            db.execute("DELETE FROM traffic_samples WHERE sampled_at < datetime('now', '-7 days')")
        except Exception:
            pass

        # 节点上报了 frps 当前 proxy 列表 → 同步该节点下隧道的在线状态
        if running_proxies is not None:
            cls._sync_tunnel_statuses(node_id, running_proxies)
        if isinstance(proxy_traffic, dict) and proxy_traffic:
            cls._update_proxy_traffic(node_id, proxy_traffic)
        return True

    @staticmethod
    def _sync_tunnel_statuses(node_id, names):
        """按 frps 实际注册的 proxy 名更新隧道状态。

        frpc 生成的 proxy 名是 "<用户token>.<隧道名>"（配置里有 user = token），
        所以同时接受纯隧道名和带前缀的名字，避免错判离线。
        """
        reported = set()
        for raw in (names or [])[:500]:
            value = str(raw or "").strip()
            if value and len(value) <= 200 and all(ord(ch) >= 32 and ord(ch) != 127 for ch in value):
                reported.add(value)
        try:
            rows = db.fetchall(
                "SELECT t.tunnel_id, t.name, u.token FROM tunnels t "
                "LEFT JOIN users u ON u.id = t.user_id WHERE t.node_id = ?",
                (node_id,))
            for row in rows:
                name = str(row.get("name") or "")
                token = str(row.get("token") or "").strip()
                keys = {name}
                if token:
                    keys.add(token + "." + name)
                status = "running" if keys & reported else "stopped"
                db.execute("UPDATE tunnels SET status = ? WHERE tunnel_id = ?",
                           (status, row.get("tunnel_id")))
        except Exception as exc:  # noqa: BLE001 - 状态同步失败不能拖垮心跳
            print("[!] 同步隧道在线状态失败: %s" % exc)

    @staticmethod
    def _update_proxy_traffic(node_id, proxy_traffic):
        """按 frps 上报的 per-proxy 今日流量更新隧道计数，并给对应用户采样。"""
        rows = db.fetchall(
            "SELECT t.tunnel_id, t.name, t.user_id, u.token FROM tunnels t "
            "LEFT JOIN users u ON u.id = t.user_id WHERE t.node_id = ?", (node_id,))
        affected = set()
        for row in rows:
            name = str(row.get("name") or "")
            token = str(row.get("token") or "").strip()
            keys = [name]
            if token:
                keys.append(token + "." + name)
            for key in keys:
                item = proxy_traffic.get(key)
                if not isinstance(item, dict):
                    continue
                try:
                    up = max(0, int(item.get("up") or 0))
                    down = max(0, int(item.get("down") or 0))
                except (TypeError, ValueError):
                    break
                db.execute(
                    "UPDATE tunnels SET traffic_up = ?, traffic_down = ? WHERE tunnel_id = ?",
                    (up, down, row.get("tunnel_id")))
                affected.add(row.get("user_id"))
                break
        for user_id in affected:
            if user_id:
                NodeService._sample_user_traffic(user_id)

    @staticmethod
    def _sample_user_traffic(user_id):
        """每 5 分钟记录一次用户当日累计流量。"""
        try:
            row = db.fetchone(
                "SELECT COALESCE(SUM(traffic_up), 0) AS up, "
                "COALESCE(SUM(traffic_down), 0) AS down FROM tunnels WHERE user_id = ?",
                (user_id,))
            up = int((row or {}).get("up") or 0)
            down = int((row or {}).get("down") or 0)
            last = db.fetchone(
                "SELECT sampled_at FROM user_traffic_samples WHERE user_id = ? "
                "ORDER BY id DESC LIMIT 1", (user_id,))
            if last and last.get("sampled_at"):
                try:
                    ts = datetime.fromisoformat(str(last["sampled_at"]).replace("Z", "+00:00"))
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                    if (datetime.now(timezone.utc) - ts).total_seconds() < 300:
                        return
                except Exception:
                    pass
            db.execute(
                "INSERT INTO user_traffic_samples (user_id, up, down) VALUES (?, ?, ?)",
                (user_id, up, down))
            try:
                db.execute("DELETE FROM user_traffic_samples WHERE sampled_at < datetime('now', '-8 days')")
            except Exception:
                pass
        except Exception:
            pass

    @classmethod
    def delete_node(cls, node_id, username):
        """删除节点"""
        if not NodeService._is_admin(username):
            return False, '权限不足，只有管理员可以删除节点'
        
        node = cls.get_node_by_id(node_id)
        if not node:
            return False, '节点不存在'
        
        db.execute('DELETE FROM nodes WHERE node_id = ?', (node_id,))
        return True, '节点删除成功'
    
    @staticmethod
    def parse_port_spec(spec):
        """解析 "10000-20000,30000" → [(10000,20000),(30000,30000)]，非法抛 ValueError。"""
        ranges = []
        for part in str(spec or "").split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                a, b = int(a), int(b)
            else:
                a = b = int(part)
            if not (1 <= a <= 65535 and 1 <= b <= 65535 and a <= b):
                raise ValueError(part)
            ranges.append((a, b))
        return ranges

    @classmethod
    def update_meta(cls, node_id, description, allowed_ports, username):
        if not cls._is_admin(username):
            return False, "权限不足"
        node = cls.get_node_by_id(node_id)
        if not node:
            return False, "节点不存在"
        desc = str(description or "").strip()[:200]
        spec = str(allowed_ports or "").strip()[:200]
        if spec:
            try:
                cls.parse_port_spec(spec)
            except (TypeError, ValueError):
                return False, "端口范围格式无效，示例：10000-20000,30000"
        db.execute("UPDATE nodes SET description = ?, allowed_ports = ? WHERE node_id = ?",
                   (desc, spec, node_id))
        return True, "节点信息已更新"

    @classmethod
    def update_name(cls, node_id, new_name, username):
        """修改节点名称"""
        if not NodeService._is_admin(username):
            return False, '仅管理员可修改节点名称'
        
        if not new_name or not new_name.strip():
            return False, '节点名称不能为空'
        
        node = cls.get_node_by_id(node_id)
        if not node:
            return False, '节点不存在'
        
        db.execute('UPDATE nodes SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE node_id = ?',
                   (new_name.strip(), node_id))
        return True, '节点名称修改成功'
    
    @staticmethod
    def get_stats():
        """获取节点统计（在线状态按心跳时间实时推导）"""
        nodes = NodeService.get_all_nodes()
        online_count = sum(1 for n in nodes if n.get('status') == 'online')
        total_clients = sum(n.get('client_count', 0) or 0 for n in nodes)
        total_upload = sum(n.get('total_upload', 0) or 0 for n in nodes)
        total_download = sum(n.get('total_download', 0) or 0 for n in nodes)

        return {
            'total_nodes': len(nodes),
            'online_nodes': online_count,
            'offline_nodes': len(nodes) - online_count,
            'total_clients': total_clients,
            'total_upload': total_upload,
            'total_download': total_download
        }


# 全局服务实例
node_service = NodeService()
