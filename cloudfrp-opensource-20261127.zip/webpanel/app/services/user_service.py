"""
用户服务 - 处理用户相关的业务逻辑
"""
import hashlib
import secrets

import bcrypt
from datetime import datetime, timedelta
from app.database import db


class UserService:
    """用户服务类"""
    
    @staticmethod
    def hash_password(password):
        """密码哈希：bcrypt（新的默认算法）"""
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("ascii")
    
    @staticmethod
    def verify_password(password, password_hash):
        """验证密码：bcrypt 优先，兼容历史 MD5（登录成功后自动升级）"""
        if not password_hash:
            return False
        ph = str(password_hash)
        if ph.startswith(("$2a$", "$2b$", "$2y$")):
            try:
                return bcrypt.checkpw(password.encode("utf-8"), ph.encode("ascii"))
            except ValueError:
                return False
        return hashlib.md5(password.encode()).hexdigest() == ph
    
    @staticmethod
    def generate_token():
        """生成随机 Token"""
        return secrets.token_hex(16)
    
    @classmethod
    def effective_speed(cls, user):
        """用户有效限速（MB/s）：管理员覆盖优先，否则取会员等级 speed_limit。"""
        if not user:
            return 0
        try:
            override = int(user.get("bandwidth_limit") or 0)
        except (TypeError, ValueError):
            override = 0
        if override > 0:
            return override
        level = user.get("membership_level")
        row = None
        try:
            if level is None or str(level) == "":
                row = None
            elif str(level).isdigit():
                row = db.fetchone("SELECT speed_limit FROM membership_levels WHERE id = ?", (int(level),))
            else:
                row = db.fetchone("SELECT speed_limit FROM membership_levels WHERE level_name = ?", (level,))
        except Exception:
            row = None
        return int(row.get("speed_limit") or 0) if row else 0

    @classmethod
    def _level_row(cls, user):
        level = (user or {}).get("membership_level")
        if level in (None, ""):
            return None
        try:
            if str(level).isdigit():
                return db.fetchone("SELECT * FROM membership_levels WHERE id = ?", (int(level),))
            return db.fetchone("SELECT * FROM membership_levels WHERE level_name = ?", (level,))
        except Exception:
            return None

    @classmethod
    def effective_limits(cls, user):
        """有效额度：用户定制覆盖优先，否则取会员等级。"""
        level_row = cls._level_row(user)

        def pick(custom_key, level_key):
            try:
                value = int((user or {}).get(custom_key) or 0)
            except (TypeError, ValueError):
                value = 0
            if value > 0:
                return value
            try:
                return int((level_row or {}).get(level_key) or 0)
            except (TypeError, ValueError):
                return 0

        return {
            "tunnel": pick("custom_tunnel_limit", "tunnel_limit"),
            "node": pick("custom_node_limit", "node_limit"),
            "domain": pick("custom_domain_limit", "domain_limit"),
            "ssl": pick("custom_ssl_limit", "ssl_limit"),
        }

    @classmethod
    def update_custom_limits(cls, user_id, data):
        values = {}
        for key, column in (("tunnel", "custom_tunnel_limit"),
                            ("node", "custom_node_limit"),
                            ("domain", "custom_domain_limit"),
                            ("ssl", "custom_ssl_limit")):
            try:
                value = int((data or {}).get(key, 0) or 0)
            except (TypeError, ValueError):
                return False, "额度必须为整数"
            if value < 0 or value > 10000:
                return False, "额度范围 0–10000（0 = 跟随会员等级）"
            values[column] = value
        if not cls.get_by_id(user_id):
            return False, "用户不存在"
        db.execute(
            "UPDATE users SET custom_tunnel_limit = ?, custom_node_limit = ?, "
            "custom_domain_limit = ?, custom_ssl_limit = ? WHERE id = ?",
            (values["custom_tunnel_limit"], values["custom_node_limit"],
             values["custom_domain_limit"], values["custom_ssl_limit"], user_id))
        return True, "定制额度已更新"

    @classmethod
    def update_bandwidth(cls, user_id, limit):
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            return False, "限速必须为整数（MB/s）"
        if limit < 0 or limit > 10000:
            return False, "限速范围 0–10000 MB/s"
        user = cls.get_by_id(user_id)
        if not user:
            return False, "用户不存在"
        db.execute("UPDATE users SET bandwidth_limit = ? WHERE id = ?", (limit, user_id))
        return True, "已更新用户限速" if limit > 0 else "已恢复跟随会员等级"

    @classmethod
    def register(cls, username, password, email):
        """用户注册"""
        if not isinstance(username, str):
            return False, '用户名不能为空'
        username = username.strip()
        if not username or len(username) > 50 or any(ord(ch) < 32 for ch in username):
            return False, '用户名格式无效'
        if not isinstance(password, str):
            return False, '密码长度至少6位'
        if not isinstance(email, str):
            email = (email or '')

        # 检查用户名
        if cls.get_by_username(username):
            return False, '用户名已存在'

        # 检查邮箱
        if email and cls.get_by_email(email):
            return False, '邮箱已被注册'

        # 密码长度检查
        if len(password) < 6:
            return False, '密码长度至少6位'
        
        # 创建用户
        password_hash = cls.hash_password(password)
        token = cls.generate_token()
        
        try:
            user_id = db.execute('''
                INSERT INTO users (username, password, email, token, points)
                VALUES (?, ?, ?, ?, 0)
            ''', (username, password_hash, email, token))
            return True, '注册成功'
        except Exception as e:
            return False, f'注册失败: {str(e)}'
    
    @classmethod
    def login(cls, username_or_email, password):
        """用户登录"""
        # 先尝试用户名
        user = cls.get_by_username(username_or_email)
        
        # 再尝试邮箱
        if not user:
            user = cls.get_by_email(username_or_email)
        
        if not user:
            return False, None
        
        # 验证密码
        if cls.verify_password(password, user['password']):
            # 历史 MD5 哈希：登录成功后透明升级为 bcrypt
            if not str(user['password']).startswith("$2"):
                db.execute('UPDATE users SET password = ? WHERE id = ?',
                           (cls.hash_password(password), user['id']))
            return True, user
        
        return False, None
    
    @staticmethod
    def get_by_username(username):
        """通过用户名获取用户"""
        return db.fetchone('SELECT * FROM users WHERE username = ?', (username,))
    
    @staticmethod
    def is_admin(username):
        """True if the account is an administrator."""
        if not username:
            return False
        row = db.fetchone('SELECT role, username FROM users WHERE username = ?', (username,))
        if not row:
            return False
        try:
            role = row['role']
        except Exception:
            role = None
        return role == 'admin' or row['username'] == 'admin'

    @staticmethod
    def get_by_email(email):
        """通过邮箱获取用户"""
        if not email:
            return None
        return db.fetchone('SELECT * FROM users WHERE email = ?', (email,))

    @staticmethod
    def get_by_token(token):
        """通过Token获取用户"""
        if not token:
            return None
        return db.fetchone('SELECT * FROM users WHERE token = ?', (token,))
    
    @staticmethod
    def get_by_id(user_id):
        """通过ID获取用户"""
        return db.fetchone('SELECT * FROM users WHERE id = ?', (user_id,))
    
    @classmethod
    def update_password(cls, username, current_password, new_password):
        """更新密码"""
        if not isinstance(current_password, str) or not isinstance(new_password, str):
            return False, '密码不能为空'
        user = cls.get_by_username(username)
        if not user:
            return False, '用户不存在'

        if not cls.verify_password(current_password, user['password']):
            return False, '当前密码错误'

        if len(new_password) < 6:
            return False, '新密码长度至少6位'

        new_hash = cls.hash_password(new_password)
        db.execute('UPDATE users SET password = ? WHERE username = ?', (new_hash, username))
        return True, '密码更新成功'

    @classmethod
    def reset_password(cls, user_id, new_password):
        """重置密码（管理员用）"""
        if not isinstance(new_password, str) or len(new_password) < 6:
            return False, '密码长度至少6位'
        if not cls.get_by_id(user_id):
            return False, '用户不存在'

        new_hash = cls.hash_password(new_password)
        db.execute('UPDATE users SET password = ? WHERE id = ?', (new_hash, user_id))
        return True, '密码已重置'
    
    @staticmethod
    def regenerate_token(username):
        """重新生成 Token"""
        new_token = UserService.generate_token()
        db.execute('UPDATE users SET token = ? WHERE username = ?', (new_token, username))
        return new_token
    
    @staticmethod
    def update_email(username, new_email):
        """更新邮箱"""
        # 检查邮箱是否已被使用
        existing = db.fetchone('SELECT id FROM users WHERE email = ? AND username != ?', 
                               (new_email, username))
        if existing:
            return False, '邮箱已被其他用户使用'
        
        db.execute('UPDATE users SET email = ? WHERE username = ?', (new_email, username))
        return True, '邮箱更新成功'
    
    @staticmethod
    def update_username(user_id, new_username):
        """更新用户名"""
        # 检查用户名是否已存在
        existing = db.fetchone('SELECT id FROM users WHERE username = ?', (new_username,))
        if existing:
            return False, '用户名已存在'
        
        db.execute('UPDATE users SET username = ? WHERE id = ?', (new_username, user_id))
        return True, '用户名修改成功'
    
    @staticmethod
    def update_qq(user_id, qq):
        """更新 QQ 号"""
        db.execute('UPDATE users SET qq = ? WHERE id = ?', (qq, user_id))
        return True, 'QQ号更新成功'
    
    @staticmethod
    def update_avatar(user_id, avatar_url):
        """更新头像"""
        db.execute('UPDATE users SET avatar_url = ? WHERE id = ?', (avatar_url, user_id))
        return True, '头像更新成功'

    @staticmethod
    def update_background(user_id, background_url):
        """更新控制台背景图"""
        db.execute('UPDATE users SET background_url = ? WHERE id = ?', (background_url, user_id))
        return True, '背景图已更新'
    
    @staticmethod
    def get_all_users():
        """获取所有用户（管理员用）"""
        return db.fetchall('''
            SELECT u.*, COUNT(t.id) as tunnel_count 
            FROM users u 
            LEFT JOIN tunnels t ON u.id = t.user_id 
            GROUP BY u.id 
            ORDER BY u.created_at DESC
        ''')
    
    @staticmethod
    def delete_user(user_id, actor_id=None, forbid_self=False):
        """删除用户。

        forbid_self=True 时（管理员后台）禁止删除当前登录账号；
        任何情况下都禁止删除最后一个管理员。
        """
        user = UserService.get_by_id(user_id)
        if not user:
            return False, '用户不存在'

        if forbid_self and actor_id is not None and int(actor_id) == int(user_id):
            return False, '不能删除当前登录账号'

        if UserService.is_admin(user['username']):
            admins = db.fetchone(
                "SELECT COUNT(*) AS count FROM users WHERE role = 'admin' OR username = 'admin'"
            )
            if not admins or int(admins.get('count') or 0) <= 1:
                return False, '不能删除最后一个管理员'

        try:
            db.execute('DELETE FROM users WHERE id = ?', (user_id,))
        except Exception:
            return False, '删除失败：该账号仍有关联数据'
        return True, '用户已删除'
    
    @staticmethod
    def add_points(user_id, points):
        """增加积分"""
        db.execute('UPDATE users SET points = points + ? WHERE id = ?', (points, user_id))
        return True
    
    @staticmethod
    def get_user_stats(user_id):
        """获取用户统计"""
        # 隧道数量
        tunnel_count = db.fetchone(
            'SELECT COUNT(*) as count FROM tunnels WHERE user_id = ?', 
            (user_id,)
        )['count']
        
        # 在线隧道
        online_count = db.fetchone(
            "SELECT COUNT(*) as count FROM tunnels WHERE user_id = ? AND status = ?",
            (user_id, 'running')
        )['count']
        
        return {
            'tunnel_count': tunnel_count,
            'online_count': online_count
        }


# 全局服务实例
user_service = UserService()
