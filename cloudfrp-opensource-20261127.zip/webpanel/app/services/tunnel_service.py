"""
隧道服务 - 处理隧道相关的业务逻辑
"""
import ipaddress
import random
import re
import secrets
from datetime import datetime
from app.database import db

VALID_TUNNEL_TYPES = ("tcp", "udp", "http", "https")
_HOST_RE = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)"
                      r"(\.[A-Za-z0-9-]{1,63}(?<!-))*$")


def _valid_host(value, allow_localhost=True):
    """local_ip / node host: 接受 IP 字面量或合法主机名。"""
    value = (value or "").strip()
    if not value or len(value) > 253:
        return False
    if allow_localhost and value.lower() == "localhost":
        return True
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        pass
    return bool(_HOST_RE.match(value))


def _parse_port(value, field, required=True):
    """端口统一为 1..65535 的整数，返回 (port|None, error|None)。"""
    if value is None or value == "":
        if required:
            return None, f'{field}不能为空'
        return None, None
    if isinstance(value, bool):
        return None, f'{field}必须为 1-65535 的整数'
    try:
        port = int(value)
    except (TypeError, ValueError):
        return None, f'{field}必须为 1-65535 的整数'
    if port < 1 or port > 65535:
        return None, f'{field}必须为 1-65535 的整数'
    return port, None


def _normalize_type(value):
    t = (value or "tcp").strip().lower()
    return t


class TunnelService:
    """隧道服务类"""
    
    @staticmethod
    def generate_tunnel_id():
        """生成隧道ID"""
        return str(int(datetime.now().timestamp() * 1000))
    
    @staticmethod
    def stop_all(user_id):
        """停止该用户的所有隧道"""
        db.execute(
            "UPDATE tunnels SET status = 'stopped' WHERE user_id = ?",
            (user_id,)
        )

    @staticmethod
    def get_user_tunnels(user_id):
        """获取用户的所有隧道"""
        return db.fetchall('''
            SELECT t.*, n.host as node_host, n.port as node_port
            FROM tunnels t
            LEFT JOIN nodes n ON t.node_id = n.node_id
            WHERE t.user_id = ?
            ORDER BY t.created_at DESC
        ''', (user_id,))
    
    @staticmethod
    def get_tunnel_by_id(tunnel_id, user_id=None):
        """通过ID获取隧道"""
        if user_id:
            return db.fetchone(
                'SELECT * FROM tunnels WHERE tunnel_id = ? AND user_id = ?',
                (tunnel_id, user_id)
            )
        return db.fetchone('SELECT * FROM tunnels WHERE tunnel_id = ?', (tunnel_id,))
    
    @staticmethod
    def _check_node_ports(node_id, remote_port):
        """节点配置了 allowed_ports 时，远程端口必须落在范围内。"""
        if not node_id or node_id == "auto" or remote_port is None:
            return True, None
        try:
            from .node_service import node_service
            node = node_service.get_node_by_id(node_id)
            spec = str((node or {}).get("allowed_ports") or "").strip()
            if not spec:
                return True, None
            port = int(remote_port)
            for start, end in node_service.parse_port_spec(spec):
                if start <= port <= end:
                    return True, None
            return False, "远程端口不在节点允许范围内（%s）" % spec
        except Exception:
            return True, None

    @staticmethod
    def _check_node_approved(node_id):
        """非 auto 的节点必须存在且已通过审核"""
        if not node_id or node_id == 'auto':
            return True, None
        node = db.fetchone('SELECT approved FROM nodes WHERE node_id = ?', (node_id,))
        if not node:
            return False, '所选节点不存在'
        if not int(node.get('approved') or 0):
            return False, '所选节点尚未通过管理员审核'
        return True, None

    @classmethod
    def _validate_fields(cls, data, tunnel=None):
        """校验/归一化隧道字段（创建与更新共用）。

        返回 (fields:dict|None, error:str|None)。tunnel 非空时表示更新，
        未提供的字段沿用原值。
        """
        def pick(key, default=None):
            if key in data:
                return data.get(key)
            if tunnel is not None:
                return tunnel.get(key)
            return default

        ttype = _normalize_type(pick('type', 'tcp'))
        if ttype not in VALID_TUNNEL_TYPES:
            return None, '隧道类型必须为 tcp/udp/http/https'

        local_ip = str(pick('local_ip', '127.0.0.1') or '').strip()
        if not _valid_host(local_ip):
            return None, '本地地址格式无效（应为 IP 或主机名）'

        local_port, err = _parse_port(pick('local_port'), '本地端口', required=True)
        if err:
            return None, err

        # tcp/udp 必须有远程端口；http/https 可留空（使用自定义域名）
        remote_required = ttype in ('tcp', 'udp')
        remote_raw = pick('remote_port')
        if tunnel is not None and remote_raw in (None, ''):
            remote_required = False  # 更新时未传/留空则保持原值
            remote_raw = tunnel.get('remote_port')
        remote_port, err = _parse_port(remote_raw, '远程端口', required=remote_required)
        if err:
            return None, err

        name = str(pick('name', '') or '').strip()
        if len(name) > 100 or any(ord(ch) < 32 or ord(ch) == 127 for ch in name):
            return None, '隧道名称格式无效'
        if not name:
            name = (tunnel or {}).get('name') or '未命名隧道'

        domain = str(pick('custom_domain', '') or '').strip()
        if domain:
            check = domain[2:] if domain.startswith('*.') else domain
            if len(domain) > 253 or not _valid_host(check, allow_localhost=False):
                return None, '自定义域名格式无效'
            if ttype not in ('http', 'https'):
                return None, '自定义域名仅适用于 HTTP/HTTPS 隧道'
        else:
            domain = None

        node_id = pick('node_id') or (tunnel or {}).get('node_id') or 'auto'
        node_id = str(node_id).strip() or 'auto'

        if tunnel is not None and 'use_encryption' in data:
            enc = 1 if data.get('use_encryption') else 0
        elif tunnel is not None:
            enc = 1 if tunnel.get('use_encryption') else 0
        else:
            enc = 1 if data.get('use_encryption') else 0

        return {
            'name': name,
            'node_id': node_id,
            'type': ttype,
            'local_ip': local_ip,
            'local_port': local_port,
            'remote_port': remote_port,
            'use_encryption': enc,
            'custom_domain': domain,
        }, None

    @classmethod
    def create_tunnel(cls, user_id, data):
        """创建隧道"""
        data = dict(data or {})
        ttype = str(data.get("type") or "tcp").lower()
        if ttype in ("tcp", "udp") and not data.get("remote_port"):
            node_id = data.get("node_id")
            auto_port = cls.get_random_port(node_id if node_id not in (None, "", "auto") else None)
            if auto_port:
                data["remote_port"] = auto_port
        fields, err = cls._validate_fields(data)
        if err:
            return False, err

        ok, msg = cls._check_node_approved(fields['node_id'])
        if not ok:
            return False, msg
        ok, msg = cls._check_node_ports(fields['node_id'], fields.get('remote_port'))
        if not ok:
            return False, msg

        # 会员/定制额度校验
        try:
            from .user_service import user_service
            user = user_service.get_by_id(user_id)
            limits = user_service.effective_limits(user)
            if limits.get("tunnel", 0) > 0:
                row = db.fetchone("SELECT COUNT(*) AS c FROM tunnels WHERE user_id = ?", (user_id,))
                if int(row.get("c") or 0) >= limits["tunnel"]:
                    return False, "已达到当前会员隧道上限（%d 条）" % limits["tunnel"]
            if fields.get("custom_domain") and limits.get("domain", 0) > 0:
                row = db.fetchone(
                    "SELECT COUNT(*) AS c FROM tunnels WHERE user_id = ? "
                    "AND custom_domain IS NOT NULL AND custom_domain != ''", (user_id,))
                if int(row.get("c") or 0) >= limits["domain"]:
                    return False, "已达到当前会员自定义域名上限（%d 个）" % limits["domain"]
        except Exception:
            pass

        tunnel_id = cls.generate_tunnel_id()
        if 'name' not in (data or {}) or not str(data.get('name') or '').strip():
            fields['name'] = f'隧道-{tunnel_id[:8]}'

        # 检查端口是否被占用
        remote_port = fields['remote_port']
        if remote_port is not None and cls.is_port_used(remote_port):
            return False, '该远程端口已被使用'

        try:
            db.execute('''
                INSERT INTO tunnels
                (user_id, tunnel_id, name, node_id, type, local_ip, local_port, remote_port, use_encryption, custom_domain, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'stopped')
            ''', (
                user_id,
                tunnel_id,
                fields['name'],
                fields['node_id'],
                fields['type'],
                fields['local_ip'],
                fields['local_port'],
                remote_port,
                fields['use_encryption'],
                fields['custom_domain'],
            ))
            return True, tunnel_id
        except Exception as e:
            return False, str(e)
    
    @classmethod
    def delete_tunnel(cls, user_id, tunnel_id):
        """删除隧道"""
        tunnel = cls.get_tunnel_by_id(tunnel_id, user_id)
        if not tunnel:
            return False, '隧道不存在'
        
        db.execute('DELETE FROM tunnels WHERE tunnel_id = ? AND user_id = ?', (tunnel_id, user_id))
        return True, '隧道已删除'
    
    @classmethod
    def update_tunnel(cls, user_id, tunnel_id, data):
        """更新隧道"""
        tunnel = cls.get_tunnel_by_id(tunnel_id, user_id)
        if not tunnel:
            return False, '隧道不存在'

        data = data or {}
        fields, err = cls._validate_fields(data, tunnel)
        if err:
            return False, err

        ok, msg = cls._check_node_approved(fields['node_id'])
        if not ok:
            return False, msg
        ok, msg = cls._check_node_ports(fields['node_id'], fields.get('remote_port'))
        if not ok:
            return False, msg

        # 未传 remote_port 时保持原端口；显式修改则检查占用
        new_port = fields['remote_port']
        if new_port is not None and new_port != tunnel['remote_port'] and cls.is_port_used(new_port, tunnel_id):
            return False, '新端口已被使用'

        db.execute('''
            UPDATE tunnels SET
                name = ?,
                node_id = ?,
                type = ?,
                local_ip = ?,
                local_port = ?,
                remote_port = ?,
                use_encryption = ?,
                custom_domain = ?
            WHERE tunnel_id = ? AND user_id = ?
        ''', (
            fields['name'],
            fields['node_id'],
            fields['type'],
            fields['local_ip'],
            fields['local_port'],
            new_port,
            fields['use_encryption'],
            fields['custom_domain'],
            tunnel_id,
            user_id
        ))
        return True, '隧道已更新'
    
    @staticmethod
    def is_port_used(port, exclude_tunnel_id=None):
        """检查端口是否被使用"""
        if exclude_tunnel_id:
            result = db.fetchone(
                'SELECT id FROM tunnels WHERE remote_port = ? AND tunnel_id != ?',
                (port, exclude_tunnel_id)
            )
        else:
            result = db.fetchone('SELECT id FROM tunnels WHERE remote_port = ?', (port,))
        return result is not None
    
    @staticmethod
    def get_random_port(node_id=None):
        """获取随机可用端口；指定节点且配置了 allowed_ports 时只在范围内分配。"""
        ranges = None
        if node_id and node_id != "auto":
            try:
                node = db.fetchone("SELECT allowed_ports FROM nodes WHERE node_id = ?", (node_id,))
                spec = str((node or {}).get("allowed_ports") or "").strip()
                if spec:
                    from .node_service import node_service
                    ranges = node_service.parse_port_spec(spec)
            except Exception:
                ranges = None
        for _ in range(500):
            if ranges:
                start, end = random.choice(ranges)
                port = random.randint(start, end)
            else:
                port = random.randint(6000, 9000)
            if not TunnelService.is_port_used(port):
                return port
        if ranges:
            start, end = ranges[0]
            return random.randint(start, end)
        return random.randint(6000, 9000)
    
    @staticmethod
    def generate_config(user_id, tunnel_id, user_token):
        """生成FRP客户端配置"""
        tunnel = db.fetchone('''
            SELECT t.*, n.host as node_host, n.port as node_port, n.auth_token
            FROM tunnels t
            LEFT JOIN nodes n ON t.node_id = n.node_id
            WHERE t.tunnel_id = ? AND t.user_id = ?
        ''', (tunnel_id, user_id))
        
        if not tunnel:
            return None
        
        # 如果没有指定节点，使用默认配置
        server_addr = tunnel.get('node_host') or '127.0.0.1'
        server_port = tunnel.get('node_port') or 7000
        # 渲染时再次清洗：兼容历史数据，避免把换行/引号写进 TOML/INI
        auth_token = str(tunnel.get('auth_token') or '').strip()
        if not re.match(r'^[A-Za-z0-9._\-]{1,128}$', auth_token):
            auth_token = 'yunwang'
        
        # 用户有效限速（管理员覆盖优先，否则会员等级）
        speed = 0
        try:
            u = db.fetchone("SELECT bandwidth_limit, membership_level FROM users WHERE id = ?", (user_id,))
            if u:
                try:
                    speed = int(u.get("bandwidth_limit") or 0)
                except (TypeError, ValueError):
                    speed = 0
                if speed <= 0:
                    level = u.get("membership_level")
                    lrow = None
                    if level not in (None, ""):
                        if str(level).isdigit():
                            lrow = db.fetchone("SELECT speed_limit FROM membership_levels WHERE id = ?", (int(level),))
                        else:
                            lrow = db.fetchone("SELECT speed_limit FROM membership_levels WHERE level_name = ?", (level,))
                    speed = int(lrow.get("speed_limit") or 0) if lrow else 0
        except Exception:
            speed = 0
        bw_toml = f'transport.bandwidthLimit = "{speed}MB"' + chr(10) if speed > 0 else ""
        bw_ini = f"bandwidth_limit = {speed}MB" + chr(10) if speed > 0 else ""

        domain = (tunnel.get('custom_domain') or '').strip()
        domain_toml = ''
        domain_ini = ''
        if domain and tunnel['type'] in ('http', 'https'):
            domain_toml = 'customDomains = ["' + domain + '"]' + chr(10)
            domain_ini = 'custom_domains = ' + domain + chr(10)

        _rp = tunnel.get('remote_port')
        remote_toml = f"remotePort = {_rp}" + chr(10) if _rp else ""
        remote_ini = f"remote_port = {_rp}" + chr(10) if _rp else ""

        # TOML 格式
        toml = f"""# FRP 客户端配置 - {tunnel['name']}
serverAddr = "{server_addr}"
serverPort = {server_port}
auth.token = "{auth_token}"
user = "{user_token}"

[[proxies]]
name = "{tunnel['name']}"
type = "{tunnel['type']}"
localIP = "{tunnel['local_ip']}"
localPort = {tunnel['local_port']}
{remote_toml}transport.useEncryption = {str(tunnel.get('use_encryption', 0) == 1).lower()}
{bw_toml}{domain_toml}"""

        # INI 格式
        ini = f"""# FRP 客户端配置 - {tunnel['name']}
[common]
server_addr = {server_addr}
server_port = {server_port}
token = {auth_token}
user = {user_token}

[{tunnel['name']}]
type = {tunnel['type']}
local_ip = {tunnel['local_ip']}
local_port = {tunnel['local_port']}
{remote_ini}use_encryption = {tunnel.get('use_encryption', 0)}
{bw_ini}{domain_ini}"""
        
        return {'toml': toml, 'ini': ini}


# 全局服务实例
tunnel_service = TunnelService()
