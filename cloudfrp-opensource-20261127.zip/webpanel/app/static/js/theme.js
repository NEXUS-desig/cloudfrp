/* ============================================================
   CloudFRP — theme switch (light/dark)
   Driven by <html data-theme="light|dark">. The tiny inline
   script in each template's <head> applies the stored/system
   theme before stylesheets paint; this file only adds the
   toggle wiring, icon/label sync and the short color transition.
   ============================================================ */
(function () {
  'use strict';
  var KEY = 'cf-theme';
  var root = document.documentElement;

  function stored() {
    try { return localStorage.getItem(KEY); } catch (e) { return null; }
  }

  function systemTheme() {
    try {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (e) { return 'light'; }
  }

  function current() {
    return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function applyMeta(theme) {
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0b161a' : '#f7f9f8');
  }

  function set(theme, persist) {
    if (theme !== 'dark' && theme !== 'light') theme = 'light';
    /* brief, paint-only transition (~160ms), then removed so normal
       interaction styles are untouched. Skipped for reduced motion. */
    var reduce = false;
    try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    if (!reduce) root.classList.add('theme-switching');
    root.setAttribute('data-theme', theme);
    applyMeta(theme);
    if (persist) {
      try { localStorage.setItem(KEY, theme); } catch (e) { /* private mode */ }
    }
    window.clearTimeout(set._timer);
    set._timer = window.setTimeout(function () {
      root.classList.remove('theme-switching');
    }, 200);
    syncButtons();
  }

  function toggle() {
    set(current() === 'dark' ? 'light' : 'dark', true);
  }

  function syncButtons() {
    var dark = current() === 'dark';
    var label = dark ? '切换到浅色主题' : '切换到深色主题';
    var btns = document.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].setAttribute('aria-label', label);
      btns[i].setAttribute('title', label);
      btns[i].classList.toggle('is-dark', dark);
    }
  }

  function wire() {
    var btns = document.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute('data-cf-theme-bound')) continue;
      btns[i].setAttribute('data-cf-theme-bound', '1');
      btns[i].addEventListener('click', function (e) {
        e.preventDefault();
        toggle();
      });
    }
    syncButtons();
    /* No explicit stored choice yet: follow the OS setting live. */
    try {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onChange = function (ev) {
        if (!stored()) set(ev.matches ? 'dark' : 'light', false);
      };
      if (mq.addEventListener) mq.addEventListener('change', onChange);
      else if (mq.addListener) mq.addListener(onChange);
    } catch (e) { /* matchMedia unavailable */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire);
  } else {
    wire();
  }

  window.CFTheme = { get: current, set: set, toggle: toggle };
})();
