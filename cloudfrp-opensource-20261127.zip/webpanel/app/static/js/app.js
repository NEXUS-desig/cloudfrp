/* CloudFRP 控制台 — 前端应用逻辑（配合 templates/app.html）。
   所有接口契约与后端 app/api/*.py 一致；只做展示与交互，不改任何请求格式。 */
'use strict';

// ===== appState: 全局状态与行为 =====
const appState = {
  currentSection: 'dashboard',
  currentAdminTab: 'admin-frps',
  sidebarCollapsed: false,
  confirmCallback: null,
  formCallback: null,
  formFields: [],
  tunnelToDelete: null,
  tunnelToConfig: null,
  adminUsersData: [],
  trafficRange: 24,
  userEmail: '',

  // ===== 初始化 =====
  init() {
    this.checkAdmin();
    setInterval(() => {
      const userNodes = document.getElementById('section-nodes');
      if (userNodes && userNodes.classList.contains('active')) this.loadNodes();
      const adminNodes = document.getElementById('tab-admin-nodes');
      if (adminNodes && adminNodes.classList.contains('active')) this.loadAdminNodes();
    }, 10000);
    this.loadMembershipLevelsMap();
    this.loadDashboard();
    this.loadTunnels();
    this.loadNodes();
    this.loadPointsShop();
    this.loadProfile();
    // 首屏即应用头像与背景，避免要进个人中心才生效
    this.api('GET', '/api/user-info').then(d => {
      this.applyAvatar(d.avatar_url || '');
      this.applyBackground(d.background_url || '');
    }).catch(() => {});
    // 可点击的 div 导航项补齐键盘可达性（Enter / Space 触发）
    document.querySelectorAll('.menu-item, #adminTabs .tab-item').forEach(el => {
      if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
      if (!el.getAttribute('role')) el.setAttribute('role', 'button');
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }
      });
    });
    // 侧边栏折叠状态记忆在 localStorage（仅桌面端）
    if (localStorage.getItem('cf-sb') === '1' && window.innerWidth > 768) {
      this.sidebarCollapsed = true;
      document.getElementById('sidebar').classList.add('collapsed');
    }
    // Escape 关闭弹层
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if (document.getElementById('otpModal').classList.contains('open')) this.closeOtp();
      else if (document.getElementById('confirmModal').classList.contains('open')) this.closeConfirm();
      else if (document.getElementById('formModal').classList.contains('open')) this.closeForm();
      else if (document.getElementById('checkinModal').classList.contains('open')) this.closeCheckin();
      else if (document.getElementById('configModal').classList.contains('open')) this.closeConfig();
    });
  },

  // ===== 管理员识别 =====
  checkAdmin() {
    fetch('/api/user-info')
      .then(r => r.json())
      .then(data => {
        this.userEmail = data.email || '';
        if (data.role === 'admin' || data.username === 'admin') {
          document.getElementById('adminMenuGroup').style.display = '';
          // 仅管理员加载后台数据（避免普通用户触发 403 提示）
          this.loadAdminUsers();
          this.loadAdminNodes();
          this.loadAdminCodes();
          this.loadAdminFRPS();
          this.loadAdminMembershipLevels();
          this.loadTraffic();
        }
      })
      .catch(() => {});
  },

  // ===== 侧边栏 =====
  toggleSidebar() {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    document.getElementById('sidebar').classList.toggle('collapsed', this.sidebarCollapsed);
    localStorage.setItem('cf-sb', this.sidebarCollapsed ? '1' : '0');
  },

  openMobileSidebar() {
    document.getElementById('sidebar').classList.add('mobile-open');
    document.getElementById('sidebarOverlay').classList.add('open');
  },

  toggleMobileSidebar() {
    document.getElementById('sidebar').classList.remove('mobile-open');
    document.getElementById('sidebarOverlay').classList.remove('open');
  },

  closeMobileSidebarIfNeeded() {
    if (window.innerWidth <= 768) this.toggleMobileSidebar();
  },

  // ===== 分区切换 =====
  switchSection(id) {
    if (id === 'tunnels' || id === 'dashboard') this.loadTrafficSummary();
    if (id === 'dashboard') this.loadUserTraffic();
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    const target = document.getElementById('section-' + id);
    if (target) target.classList.add('active');
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    const menuItem = document.querySelector('.menu-item[data-section="' + id + '"]');
    if (menuItem) menuItem.classList.add('active');
    this.currentSection = id;
    this.closeMobileSidebarIfNeeded();
    switch (id) {
      case 'dashboard': this.loadDashboard(); break;
      case 'tunnels': this.loadTunnels(); break;
      case 'nodes': this.loadNodes(); break;
      case 'donate': this.loadDonateNodes(); break;
      case 'points': this.loadPointsShop(); break;
      case 'profile': this.loadProfile(); break;
      case 'admin':
        this.loadAdminUsers(); this.loadAdminNodes(); this.loadAdminCodes();
        this.loadAdminFRPS(); this.loadAdminMembershipLevels(); this.loadTraffic(); this.loadAdminCertificate(); break;
    }
  },

  logout() { window.location.href = '/logout'; },

  // ===== 基础组件 =====
  showToast(msg, type, duration) {
    type = type || 'info';
    duration = duration || 3200;
    const container = document.getElementById('toastContainer');
    const icons = {
      success: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m3.5 8.4 2.8 2.8 6.2-6.4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      error: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 4.8v4M8 11.1v.1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
      warning: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.8 15 14H1L8 1.8z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M8 6.2v3.2M8 11.6v.1" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
      info: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 7.2v3.6M8 4.9v.1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
    };
    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.setAttribute('role', 'status');
    toast.innerHTML = '<span class="toast-icon">' + (icons[type] || icons.info) + '</span><span>' + this.escapeHtml(msg) + '</span>';
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('toast-out');
      setTimeout(() => toast.remove(), 260);
    }, duration);
  },

  fmtNum(n) {
    if (n === null || n === undefined || n === '') return '-';
    const v = Number(n);
    return Number.isFinite(v) ? v.toLocaleString('zh-CN') : String(n);
  },

  fmtBytes(n) {
    const v = Number(n);
    if (!Number.isFinite(v)) return '-';
    if (v >= 1073741824) return (v / 1073741824).toFixed(2) + ' GB';
    if (v >= 1048576) return (v / 1048576).toFixed(1) + ' MB';
    if (v >= 1024) return (v / 1024).toFixed(1) + ' KB';
    return Math.round(v) + ' B';
  },

  memberLabel(v) {
    if (v === null || v === undefined || v === '' || v === 'free' || v === 0 || v === '0') return '免费';
    const key = String(v);
    if (this.membershipLevels[key]) return this.membershipLevels[key];
    return String(v);
  },

  // 会员等级名称表（数据库里 membership_level 可能存 id，也可能存名字）
  membershipLevels: {},
  setMembershipLevels(list) {
    (list || []).forEach(l => {
      const name = (l.level_name === 'free') ? '免费' : (l.level_name || ('等级 ' + l.id));
      this.membershipLevels[String(l.id)] = name;
    });
    if (this._myLevelRaw !== undefined) {
      const a = document.getElementById('statMembership');
      if (a) a.textContent = this.memberLabel(this._myLevelRaw);
      const b = document.getElementById('pointsMyMember');
      if (b) b.textContent = this.memberLabel(this._myLevelRaw);
      const c = document.getElementById('profileMembership');
      if (c) c.textContent = this.memberLabel(this._myLevelRaw);
      const d = document.getElementById('pointsExpire');
      if (d) d.textContent = this.memberLabel(this._myLevelRaw) === '免费'
        ? '长期' : (this._myExpiryRaw ? String(this._myExpiryRaw).slice(0, 10) : '永久');
    }
  },

  async loadMembershipLevelsMap() {
    if (this._levelsPromise) return this._levelsPromise;
    this._levelsPromise = (async () => {
      try {
        const data = await this.api('GET', '/api/membership/levels');
        this.setMembershipLevels(data.levels ?? data ?? []);
        if (this.currentSection === 'admin') this.loadAdminUsers();
      } catch (e) { /* 名称表加载失败时退回原值显示 */ }
      return this.membershipLevels;
    })();
    return this._levelsPromise;
  },

  escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str === null || str === undefined ? '' : String(str);
    return d.innerHTML;
  },

  // ===== 确认弹窗 =====
  showConfirm(msg, callback, title, danger) {
    document.getElementById('confirmMessage').textContent = msg;
    document.getElementById('confirmTitle').textContent = title || '确认';
    const btn = document.getElementById('confirmBtn');
    btn.textContent = danger ? '删除' : (btn.dataset.defaultText || '确认');
    btn.classList.toggle('btn-danger', !!danger);
    btn.classList.toggle('btn-primary', !danger);
    this.confirmCallback = callback;
    document.getElementById('confirmModal').classList.add('open');
  },

  closeConfirm() {
    document.getElementById('confirmModal').classList.remove('open');
    this.confirmCallback = null;
  },

  confirmAction() {
    if (typeof this.confirmCallback === 'function') this.confirmCallback();
    this.closeConfirm();
  },

  // ===== 表单弹窗（动态字段） =====
  showForm(title, fields, callback, opts) {
    opts = opts || {};
    document.getElementById('formModalTitle').textContent = title;
    this.formFields = fields;
    this.formCallback = callback;
    const body = document.getElementById('formModalBody');
    body.innerHTML = '';
    fields.forEach(f => {
      const group = document.createElement('div');
      group.className = 'form-group';
      const label = document.createElement('label');
      label.textContent = f.label || f.name;
      group.appendChild(label);
      let input;
      if (f.type === 'select') {
        input = document.createElement('select');
        input.className = 'form-select';
        (f.options || []).forEach(o => {
          const opt = document.createElement('option');
          opt.value = o.value;
          opt.textContent = o.label;
          if (o.disabled) opt.disabled = true;
          if (o.selected) opt.selected = true;
          input.appendChild(opt);
        });
      } else if (f.type === 'textarea') {
        input = document.createElement('textarea');
        input.className = 'form-input';
        input.rows = f.rows || 3;
      } else {
        input = document.createElement('input');
        input.className = 'form-input';
        input.type = f.type || 'text';
        input.placeholder = f.placeholder || '';
      }
      input.id = 'formField_' + f.name;
      if (f.type === 'select') {
        // 只有显式给了 value 且命中选项时才设置，避免 value='' 把选择清空
        if (f.value !== undefined && f.value !== null && f.value !== '') input.value = f.value;
      } else {
        input.value = f.value === null || f.value === undefined ? '' : f.value;
      }
      if (f.readonly) {
        input.readOnly = true;
        input.classList.add('is-plain');
      }
      if (f.required) input.required = true;
      group.appendChild(input);
      if (f.hint) {
        const hint = document.createElement('p');
        hint.className = 'form-hint';
        hint.textContent = f.hint;
        group.appendChild(hint);
      }
      body.appendChild(group);
    });
    const btn = document.getElementById('formModalBtn');
    btn.style.display = opts.submit === false ? 'none' : '';
    document.getElementById('formModal').classList.add('open');
    const first = body.querySelector('input:not(.is-plain), select, textarea');
    if (first && opts.submit !== false) setTimeout(() => first.focus(), 60);
  },

  closeForm() {
    document.getElementById('formModal').classList.remove('open');
    this.formCallback = null;
    this.formFields = [];
  },

  formSubmit() {
    const data = {};
    this.formFields.forEach(f => {
      const el = document.getElementById('formField_' + f.name);
      data[f.name] = el ? el.value : '';
    });
    if (typeof this.formCallback === 'function') this.formCallback(data);
    this.closeForm();
  },

  // ===== 复制 =====
  copyText(text) {
    if (!text) return;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => this.showCopyIndicator()).catch(() => this.fallbackCopy(text));
    } else {
      this.fallbackCopy(text);
    }
  },

  fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* 忽略 */ }
    ta.remove();
    this.showCopyIndicator();
  },

  showCopyIndicator() {
    const el = document.getElementById('copyIndicator');
    el.classList.add('show');
    clearTimeout(this._copyTimer);
    this._copyTimer = setTimeout(() => el.classList.remove('show'), 1500);
  },

  // ===== API 封装 =====
  async api(method, url, body) {
    const opts = { method: method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    try {
      const res = await fetch(url, opts);
      const text = await res.text();
      let data = null;
      try { data = text ? JSON.parse(text) : {}; } catch (e) { data = null; }
      if (!res.ok) {
        // 500 等错误会返回 HTML 错误页而不是 JSON —— 给出可读提示
        const msg = (data && (data.error || data.message))
          || (res.status >= 500 ? '服务器内部错误，请稍后重试（该功能可能暂不可用）'
                                : '请求失败 (' + res.status + ')');
        throw new Error(msg);
      }
      if (data === null) throw new Error('服务器响应格式异常');
      // 后端部分接口以 HTTP 200 + success:false 表示业务失败（积分不足、密码错误等）
      if (data && data.success === false && (data.error || data.message)) {
        throw new Error(data.error || data.message);
      }
      return data;
    } catch (err) {
      if (!(err instanceof Error)) throw err;
      this.showToast(err.message, 'error');
      throw err;
    }
  },

  // 数字滚动（reduced-motion 下直接显示）
  animateStat(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    if (value === null || value === undefined || value === '' || isNaN(Number(value))) {
      el.textContent = (value === null || value === undefined || value === '') ? '-' : String(value);
      return;
    }
    const target = Number(value);
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.textContent = this.fmtNum(target);
      return;
    }
    if (Math.abs(target) > 5000) { el.textContent = this.fmtNum(target); return; }
    const from = 0, dur = 620, t0 = performance.now();
    const step = (now) => {
      const k = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - k, 4);
      el.textContent = this.fmtNum(Math.round(from + (target - from) * eased));
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  },

  // ================================================================
  //  控制台
  // ================================================================
  async loadDashboard() {
    this.loadTrafficSummary();
    this.loadUserTraffic();
    try {
      const stats = await this.api('GET', '/api/user/stats');
      this.animateStat('statTunnels', stats.tunnel_count ?? stats.tunnels ?? stats.total);
      this.animateStat('statOnline', stats.online_count ?? stats.online);
    } catch (e) { /* 卡片保持 '-' */ }
    try {
      const pts = await this.api('GET', '/api/user/points');
      this.animateStat('statPoints', pts.points);
      this._myLevelRaw = pts.membership_level;
      document.getElementById('statMembership').textContent = this.memberLabel(pts.membership_level);
    } catch (e) { /* 忽略 */ }
    try {
      const nodeStats = await this.api('GET', '/api/nodes/stats');
      this.animateStat('statOnlineNodes', nodeStats.online_nodes ?? nodeStats.online);
      this.animateStat('statClients', nodeStats.total_clients ?? nodeStats.clients);
    } catch (e) { /* 忽略 */ }
    try {
      const ci = await this.api('GET', '/api/checkin/stats');
      this.renderCheckinCalendar(ci);
    } catch (e) { /* 忽略 */ }
  },

  renderCheckinCalendar(data) {
    const el = document.getElementById('checkinCalendar');
    if (!data) { el.innerHTML = '<span class="muted">暂无签到数据</span>'; return; }
    const items = [
      ['连续签到', (data.streak ?? 0) + ' 天'],
      ['本月签到', (data.month ?? 0) + ' 次'],
      ['累计签到', (data.total ?? 0) + ' 次'],
    ];
    el.innerHTML = items.map(it =>
      '<div class="mini-stat"><span class="mini-stat__k">' + it[0] + '</span><span class="mini-stat__v">' + this.fmtNum(it[1]) + '</span></div>'
    ).join('');
  },

  // ===== 每日签到 =====
  withCaptcha() {
    return new Promise((resolve) => {
      if (!window.CFCaptcha) {
        this.showToast('验证码组件未加载', 'error');
        resolve(null);
        return;
      }
      CFCaptcha.open({ onSuccess: (id) => resolve(id), onCancel: () => resolve(null) });
    });
  },

  showCheckin() {
    document.getElementById('checkinModal').classList.add('open');
    const btn = document.getElementById('checkinDoBtn');
    const sub = document.getElementById('checkinModalSub');
    this.api('GET', '/api/checkin/stats').then(stats => {
      const streak = stats.streak ?? 0;
      if (sub) sub.textContent = '连续签到 ' + streak + ' 天 · 本月 ' + (stats.month ?? 0) + ' 次';
      // streak 从今天往前数：>=1 说明今天已签到
      if (btn && streak >= 1) {
        btn.disabled = true;
        btn.textContent = '今日已签到';
      } else if (btn) {
        btn.disabled = false;
        btn.textContent = '签到';
      }
    }).catch(() => {});
  },

  closeCheckin() {
    document.getElementById('checkinModal').classList.remove('open');
    // 下次打开恢复初始视图
    const body = document.getElementById('checkinModalBody');
    if (body && this._checkinTpl) body.innerHTML = this._checkinTpl;
    const btn = document.getElementById('checkinDoBtn');
    if (btn) { btn.disabled = false; btn.textContent = '签到'; }
  },

  async doCheckin() {
    const captchaId = await this.withCaptcha();
    if (!captchaId) return;
    const btn = document.getElementById('checkinDoBtn');
    btn.disabled = true;
    btn.textContent = '签到中...';
    try {
      const res = await this.api('POST', '/api/checkin', { captcha_id: captchaId });
      document.getElementById('checkinModalBody').innerHTML =
        '<div class="checkin-result">' +
          '<div class="points-gained">+' + this.fmtNum(res.points ?? res.reward ?? 0) + '</div>' +
          '<div class="points-label">积分已到账</div>' +
          (res.streak ? '<div class="streak-info">连续签到 ' + res.streak + ' 天</div>' : '') +
          '<button class="checkin-btn-large" onclick="appState.closeCheckin()">完成</button>' +
        '</div>';
      this.showToast('签到成功！获得 ' + (res.points ?? res.reward ?? 0) + ' 积分', 'success');
      this.loadDashboard();
      this.loadPointsShop();
    } catch (e) {
      btn.disabled = false;
      btn.textContent = '签到';
    }
  },

  // ================================================================
  //  隧道
  // ================================================================
  fmtBytes(v) {
    v = Number(v) || 0;
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i === 0 ? Math.round(v) : v.toFixed(v >= 100 ? 0 : 1)) + ' ' + units[i];
  },

  async loadTrafficSummary() {
    try {
      const [s, ut] = await Promise.all([
        this.api('GET', '/api/nodes/stats'),
        this.api('GET', '/api/stats/user-traffic?hours=1').catch(() => ({})),
      ]);
      const up = this.fmtBytes(ut.today_up);
      const down = this.fmtBytes(ut.today_down);
      const clients = s.total_clients ?? 0;
      const nodes = s.online_nodes ?? 0;
      const set = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
      set('sumUpload', up);
      set('sumDownload', down);
      set('sumClients', clients);
      set('sumNodes', nodes);
      set('tunnelTrafficSummary', '今日 ↑' + up + ' · ↓' + down + ' · 连接 ' + clients);
    } catch (e) { /* 统计失败不影响页面 */ }
  },

  async loadTunnels() {
    const tbody = document.getElementById('tunnelTableBody');
    try {
      const data = await this.api('GET', '/api/tunnels');
      const tunnels = data.tunnels ?? data ?? [];
      if (!tunnels.length) {
        tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">还没有隧道</div><div class="empty-sub">创建第一条隧道，把内网服务发布到公网</div><button class="btn btn-primary btn-sm" onclick="appState.showCreateTunnel()">创建隧道</button></div></td></tr>';
        return;
      }
      tbody.innerHTML = tunnels.map(t => {
        const online = t.status === 'online' || t.status === 'running';
        const status = online
          ? '<span class="badge badge-success"><span class="dot dot-success"></span>在线</span>'
          : '<span class="badge badge-muted"><span class="dot dot-muted"></span>离线</span>';
        return '<tr>' +
          '<td><div class="cell-main">' + this.escapeHtml(t.name || '-') + '</div>' +
            '<div class="cell-sub">#' + this.escapeHtml(t.tunnel_id ?? t.id ?? '-') +
              (t.custom_domain ? ' · ' + this.escapeHtml(t.custom_domain) : '') + '</div></td>' +
          '<td><span class="type-tag">' + this.escapeHtml((t.type || '-').toUpperCase()) + '</span></td>' +
          '<td><span class="mono">' + this.escapeHtml((t.local_ip || '127.0.0.1') + ':' + (t.local_port ?? '')) + '</span></td>' +
          '<td class="mono">' + (t.remote_port ?? '-') + '</td>' +
          '<td>' + this.escapeHtml(t.node_host ? (t.node_host + (t.node_port ? ':' + t.node_port : '')) : (t.node_name || t.node || '自动')) + '</td>' +
          '<td>' + status + '</td>' +
          '<td><div class="btn-group">' +
            '<button class="btn btn-ghost btn-xs" onclick="appState.showConfig(\'' + this.escapeHtml(t.tunnel_id ?? t.id) + '\')">配置</button>' +
            '<button class="btn btn-ghost btn-xs" onclick="appState.editTunnel(\'' + this.escapeHtml(t.tunnel_id ?? t.id) + '\')">编辑</button>' +
            '<button class="btn btn-danger btn-xs" onclick="appState.confirmDeleteTunnel(\'' + this.escapeHtml(t.tunnel_id ?? t.id) + '\')">删除</button>' +
          '</div></td>' +
        '</tr>';
      }).join('');
    } catch (e) {
      tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">加载失败，请稍后重试</div></div></td></tr>';
    }
  },

  async nodeOptions() {
    let opts = [];
    try {
      const data = await this.api('GET', '/api/nodes');
      opts = (data.nodes || [])
        .filter(n => Number(n.approved) === 1)
        .map(n => {
          const online = n.status === 'online' || n.status === 'active';
          const addr = n.host ? (n.host + (n.port ? ':' + n.port : '')) : '未配置地址';
          return { value: n.node_id, label: (n.name || n.node_id) + ' · ' + addr + (online ? '' : '（离线）') };
        });
    } catch (e) { opts = []; }
    // 不再提供「自动」：有节点时让用户自己选，没有节点时留空
    if (opts.length) {
      opts.unshift({ value: '', label: '请选择节点', disabled: true, selected: true });
    } else {
      opts.push({ value: '', label: '暂无可用节点', disabled: true, selected: true });
    }
    return opts;
  },

  async showCreateTunnel() {
    const nodes = await this.nodeOptions();
    this.showForm('创建隧道', [
      { name: 'name', label: '隧道名称', placeholder: '例如 minecraft-server', required: true },
      { name: 'type', label: '类型', type: 'select', options: [
        { value: 'tcp', label: 'TCP' }, { value: 'udp', label: 'UDP' },
        { value: 'http', label: 'HTTP' }, { value: 'https', label: 'HTTPS' }] },
      { name: 'local_ip', label: '本地地址', placeholder: '127.0.0.1', value: '127.0.0.1' },
      { name: 'local_port', label: '本地端口', placeholder: '例如 80', type: 'number', required: true },
      { name: 'remote_port', label: '远程端口（留空自动分配）', placeholder: '留空自动分配', type: 'number' },
      { name: 'node_id', label: '节点', type: 'select', options: nodes, required: nodes.some(o => o.value) },
      { name: 'custom_domain', label: '自定义域名（仅 HTTP/HTTPS，可选）', placeholder: '例如 app.example.com' },
    ], async (data) => {
      try {
        const body = {
          name: data.name,
          type: data.type,
          local_ip: data.local_ip || '127.0.0.1',
          local_port: parseInt(data.local_port, 10),
          node_id: data.node_id || undefined
        };
        if (data.custom_domain) body.custom_domain = data.custom_domain.trim();
        if (data.remote_port) body.remote_port = parseInt(data.remote_port, 10);
        if (!body.remote_port) {
          try {
            const nodeQ = body.node_id && body.node_id !== 'auto'
              ? '?node_id=' + encodeURIComponent(body.node_id) : '';
            const rp = await this.api('GET', '/api/random-port' + nodeQ);
            body.remote_port = rp.port ?? rp.remote_port;
          } catch (e) { /* 服务端兜底 */ }
        }
        await this.api('POST', '/api/tunnels', body);
        this.showToast('隧道创建成功', 'success');
        this.loadTunnels();
        this.loadDashboard();
      } catch (e) { /* 提示已由 api() 弹出 */ }
    });
  },

  async editTunnel(id) {
    try {
      const data = await this.api('GET', '/api/tunnels');
      const tunnels = data.tunnels ?? data ?? [];
      const tn = tunnels.find(x => String(x.tunnel_id ?? x.id) === String(id));
      if (!tn) { this.showToast('未找到隧道', 'error'); return; }
      const nodes = await this.nodeOptions();
      nodes.forEach(o => { if (o.value === tn.node_id) o.selected = true; });
      this.showForm('编辑隧道', [
        { name: 'name', label: '隧道名称', value: tn.name || '', required: true },
        { name: 'local_ip', label: '本地地址', value: tn.local_ip || '127.0.0.1' },
        { name: 'local_port', label: '本地端口', type: 'number', value: tn.local_port || '' },
        { name: 'remote_port', label: '远程端口', type: 'number', value: tn.remote_port || '' },
        { name: 'node_id', label: '节点', type: 'select', options: nodes },
        { name: 'custom_domain', label: '自定义域名（仅 HTTP/HTTPS，可选）', value: tn.custom_domain || '' },
      ], async (d) => {
        try {
          await this.api('PUT', '/api/tunnels/' + encodeURIComponent(id), {
            name: d.name,
            local_ip: d.local_ip || '127.0.0.1',
            local_port: parseInt(d.local_port, 10),
            remote_port: d.remote_port ? parseInt(d.remote_port, 10) : undefined,
            node_id: d.node_id || undefined,
            custom_domain: (d.custom_domain || '').trim()
          });
          this.showToast('隧道更新成功', 'success');
          this.loadTunnels();
        } catch (e) { /* 已提示 */ }
      });
    } catch (e) { /* 已提示 */ }
  },

  confirmDeleteTunnel(id) {
    this.tunnelToDelete = id;
    this.showConfirm('确定要删除这条隧道吗？删除后公网地址立即失效，此操作不可恢复。', () => {
      this.api('DELETE', '/api/tunnels/' + encodeURIComponent(this.tunnelToDelete)).then(() => {
        this.showToast('隧道已删除', 'success');
        this.loadTunnels();
        this.loadDashboard();
      }).catch(() => {});
    }, '删除隧道', true);
  },

  showConfig(id) {
    document.getElementById('configContent').textContent = '加载中...';
    document.getElementById('configModal').classList.add('open');
    this.tunnelToConfig = id;
    const btn = document.getElementById('installScriptBtn');
    if (btn) btn.href = '/api/tunnels/' + encodeURIComponent(id) + '/install.sh';
    const linuxEl = document.getElementById('deployLinux');
    const winEl = document.getElementById('deployWindows');
    if (linuxEl) linuxEl.textContent = '加载中...';
    if (winEl) winEl.textContent = '加载中...';
    this.loadDeploy(id);
    this.api('GET', '/api/tunnels/' + encodeURIComponent(id) + '/config').then(data => {
      document.getElementById('configContent').textContent =
        data.toml ?? data.config ?? data.content ?? JSON.stringify(data, null, 2);
    }).catch(() => {
      document.getElementById('configContent').textContent = '获取配置失败';
    });
  },

  async loadDeploy(id) {
    try {
      const data = await this.api('GET', '/api/tunnels/' + encodeURIComponent(id) + '/deploy');
      this._deployCmds = { linux: data.linux || '', windows: data.windows || '' };
      const linuxEl = document.getElementById('deployLinux');
      const winEl = document.getElementById('deployWindows');
      if (linuxEl) linuxEl.textContent = data.linux || '生成失败';
      if (winEl) winEl.textContent = data.windows || '生成失败';
    } catch (e) {
      const linuxEl = document.getElementById('deployLinux');
      const winEl = document.getElementById('deployWindows');
      if (linuxEl) linuxEl.textContent = '生成失败，请刷新后重试';
      if (winEl) winEl.textContent = '生成失败，请刷新后重试';
    }
  },

  copyDeploy(kind) {
    const cmd = (this._deployCmds || {})[kind] || '';
    if (!cmd) return;
    this.copyText(cmd);
  },

  closeConfig() {
    document.getElementById('configModal').classList.remove('open');
    this.tunnelToConfig = null;
  },

  copyConfig() {
    this.copyText(document.getElementById('configContent').textContent);
  },

  // ================================================================
  //  节点
  // ================================================================
  async loadNodes() {
    const grid = document.getElementById('nodeGrid');
    try {
      const data = await this.api('GET', '/api/nodes');
      const nodes = data.nodes ?? data ?? [];
      const isAdmin = !!data.is_admin;
      try {
        const st = await this.api('GET', '/api/nodes/stats');
        document.getElementById('nodeStatOnline').textContent = st.online_nodes ?? 0;
        document.getElementById('nodeStatOffline').textContent = st.offline_nodes ?? 0;
        document.getElementById('nodeStatTotal').textContent = st.total_nodes ?? nodes.length;
      } catch (e) {
        const online = nodes.filter(n => n.status === 'online').length;
        document.getElementById('nodeStatOnline').textContent = online;
        document.getElementById('nodeStatOffline').textContent = nodes.length - online;
        document.getElementById('nodeStatTotal').textContent = nodes.length;
      }
      if (!nodes.length) {
        grid.innerHTML = '<div class="empty-state empty-card">' +
          '<div class="empty-text">暂无节点</div>' +
          '<div class="empty-sub">节点未出现？在节点服务器上执行 <span class="mono">curl -m 5 ' + this.escapeHtml(location.origin) + '/api/nodes</span>：' +
          '返回 <span class="mono">{"error":"未登录"}</span> 说明网络已通；超时或拒绝 → 面板需以 0.0.0.0 监听并放行 3592 端口。</div>' +
          '<a class="btn btn-secondary btn-sm" href="#" data-goto="donate" data-goto-nav>去捐赠节点</a></div>';
        return;
      }
      grid.innerHTML = nodes.map(n => {
        const approved = Number(n.approved) === 1;
        const isOnline = n.status === 'online' || n.status === 'active';
        const badge = !approved
          ? '<span class="badge badge-warning">待审核</span>'
          : (isOnline
              ? '<span class="badge badge-success"><span class="dot dot-success"></span>在线</span>'
              : '<span class="badge badge-muted"><span class="dot dot-muted"></span>离线</span>');
        const s = n.stats || {};
        const meta = [
          ['CPU', (Number(s.cpu_usage) || 0).toFixed(0) + '%'],
          ['内存', (Number(s.memory_usage) || 0).toFixed(0) + '%'],
          ['上行', this.fmtSpeed(s.upload_speed)],
          ['客户端', s.client_count ?? 0],
          ['允许端口', n.allowed_ports || '不限'],
          ['心跳', n.heartbeat_age != null ? n.heartbeat_age + ' 秒前' : '-'],
        ];
        return '<div class="node-card">' +
          '<div class="node-card__top"><div>' +
            '<div class="node-name">' + this.escapeHtml(n.name || 'Node #' + n.id) + '</div>' +
            '<div class="node-addr mono">' + this.escapeHtml(n.host ? (n.host + (n.port ? ':' + n.port : '')) : (n.address || '-')) + '</div>' +
            (n.description ? '<div class="cell-sub" style="margin-top:4px;">' + this.escapeHtml(n.description) + '</div>' : '') +
          '</div>' + badge + '</div>' +
          '<dl class="node-meta">' + meta.map(m =>
            '<div><dt>' + m[0] + '</dt><dd>' + this.escapeHtml(m[1]) + '</dd></div>').join('') + '</dl>' +
          '<div class="node-actions">' +
            '<button class="btn btn-ghost btn-sm" data-node-detail="' + this.escapeHtml(n.node_id) + '">详情</button>' +
            (isAdmin
              ? '<button class="btn btn-ghost btn-sm" data-node-rename="' + this.escapeHtml(n.node_id) + '">改名</button>' +
                '<button class="btn btn-danger btn-sm" data-node-delete="' + this.escapeHtml(n.node_id) + '">删除</button>'
              : '') +
          '</div>' +
        '</div>';
      }).join('');
      this._bindNodeActions(grid, (attr, val) => {
        if (attr === 'data-node-detail') this.nodeDetail(val);
        if (attr === 'data-node-rename') this.editNodeName(val);
        if (attr === 'data-node-delete') this.confirmDeleteNode(val);
      });
    } catch (e) {
      grid.innerHTML = '<div class="empty-state"><div class="empty-text">加载节点失败</div></div>';
    }
  },

  _bindNodeActions(root, handler) {
    root.querySelectorAll('[data-node-detail],[data-node-rename],[data-node-delete]').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.getAttribute('data-node-detail') || btn.getAttribute('data-node-rename') || btn.getAttribute('data-node-delete');
        const attr = btn.hasAttribute('data-node-detail') ? 'data-node-detail'
          : btn.hasAttribute('data-node-rename') ? 'data-node-rename' : 'data-node-delete';
        handler(attr, val);
      });
    });
    root.querySelectorAll('[data-goto]').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        this.switchSection(a.getAttribute('data-goto'));
      });
    });
  },

  nodeDetail(nodeId) {
    this.api('GET', '/api/nodes').then(data => {
      const nodes = data.nodes ?? data ?? [];
      const n = nodes.find(x => x.node_id === nodeId || String(x.id) === String(nodeId));
      if (!n) { this.showToast('未找到节点', 'error'); return; }
      const s = n.stats || {};
      this.showForm('节点详情', [
        { name: 'node_id', label: '节点 ID', value: n.node_id ?? '-', readonly: true },
        { name: 'name', label: '名称', value: n.name || '-', readonly: true },
        { name: 'address', label: '地址', value: (n.host ? (n.host + (n.port ? ':' + n.port : '')) : (n.address || '-')), readonly: true },
        { name: 'status', label: '状态', value: (Number(n.approved) === 1 ? (n.status === 'online' ? '在线' : '离线') : '待审核'), readonly: true },
        { name: 'cpu', label: 'CPU 占用', value: (Number(s.cpu_usage) || 0).toFixed(1) + '%', readonly: true },
        { name: 'memory', label: '内存占用', value: (Number(s.memory_usage) || 0).toFixed(1) + '%', readonly: true },
        { name: 'clients', label: '在线客户端', value: s.client_count ?? 0, readonly: true },
        { name: 'created', label: '创建时间', value: n.created_at || '-', readonly: true },
      ], () => {}, { submit: false });
    }).catch(() => {});
  },

  editNodeName(nodeId) {
    this.showForm('修改节点名称', [
      { name: 'name', label: '节点名称', placeholder: '新名称', required: true },
    ], async (data) => {
      try {
        await this.api('PUT', '/api/nodes/' + encodeURIComponent(nodeId) + '/name', { name: data.name });
        this.showToast('节点名称已更新', 'success');
        this.loadNodes();
        if (this.currentSection === 'admin') this.loadAdminNodes();
      } catch (e) { /* 已提示 */ }
    });
  },

  adminEditNodeMeta(id) {
    const node = (this.adminNodesData || []).find(n => n.node_id === id) || {};
    this.showForm('编辑节点 · ' + (node.name || id), [
      { name: 'description', label: '节点描述', type: 'textarea', value: node.description || '',
        placeholder: '展示给用户的说明，例如线路、带宽、用途' },
      { name: 'allowed_ports', label: '允许的远程端口（留空不限）', value: node.allowed_ports || '',
        placeholder: '例如 10000-20000,30000' },
    ], async (data) => {
      const res = await this.api('PUT', '/api/nodes/' + encodeURIComponent(id) + '/meta', {
        description: (data.description || '').trim(),
        allowed_ports: (data.allowed_ports || '').trim(),
      });
      this.showToast(res.message || '节点信息已更新', 'success');
      this.loadAdminNodes();
    });
  },

  async approveNode(nodeId, approved) {
    try {
      const res = await this.api('PUT', '/api/nodes/' + encodeURIComponent(nodeId) + '/approve', { approved: approved });
      this.showToast(res.message || (approved ? '节点已通过审核' : '已取消该节点的审核'), 'success');
      this.loadAdminNodes();
      this.loadNodes();
    } catch (e) { /* 已提示 */ }
  },

  confirmDeleteNode(nodeId) {
    this.showConfirm('确定要删除这个节点吗？正在使用它的隧道将失去出口。', () => {
      this.api('DELETE', '/api/nodes/' + encodeURIComponent(nodeId)).then(() => {
        this.showToast('节点已删除', 'success');
        this.loadNodes();
        this.loadAdminNodes();
      }).catch(() => {});
    }, '删除节点', true);
  },

  // ================================================================
  //  捐赠节点
  // ================================================================
  donateCmd() {
    const host = ((document.getElementById('donateHost') || {}).value || '').trim();
    const name = ((document.getElementById('donateName') || {}).value || '').trim();
    const port = ((document.getElementById('donatePort') || {}).value || '7000').trim() || '7000';
    const el = document.getElementById('donateCmd');
    if (!host) { if (el) el.textContent = '填写公网 IP 后这里生成命令'; return ''; }
    let cmd = 'python3 node_client.py --host ' + host + ' --panel ' + location.origin + ' --port ' + port;
    if (name) cmd += ' --name "' + name.replace(/"/g, '') + '"';
    if (el) el.textContent = cmd;
    return cmd;
  },

  downloadDonateScript() {
    const panelEl = document.getElementById('donatePanel');
    if (panelEl && !panelEl.value) panelEl.value = location.origin;
    const panel = ((panelEl && panelEl.value) || location.origin).trim().replace(/\/+$/, '');
    const name = ((document.getElementById('donateName2') || {}).value || '').trim();
    const host = ((document.getElementById('donateHost2') || {}).value || '').trim();
    const port = ((document.getElementById('donatePort') || {}).value || '7000').trim() || '7000';
    const q = new URLSearchParams({ panel: panel, name: name, host: host, port: port });
    window.location.href = '/api/nodes/donate-install.sh?' + q.toString();
  },

  copyDonateCmd() {
    const cmd = this.donateCmd();
    if (!cmd) { this.showToast('请先填写公网 IP', 'warning'); return; }
    this.copyText(cmd);
    this.showToast('命令已复制', 'success');
  },

  async loadDonateNodes() {
    const el = document.getElementById('donateNodeList');
    if (!el) return;
    try {
      const data = await this.api('GET', '/api/nodes');
      const nodes = (data.nodes || []).filter(n => n && n.donated_by);
      if (!nodes.length) {
        el.innerHTML = '<div class="empty-state"><div class="empty-text">还没有捐赠节点</div><div class="empty-sub">按上面的步骤接入后，节点会出现在这里</div></div>';
        return;
      }
      el.innerHTML = nodes.map(n => {
        const online = n.status === 'online' || n.status === 'active';
        const addr = n.host ? (n.host + (n.port ? ':' + n.port : '')) : '-';
        return '<div class="donate-node">' +
          '<div><div class="donate-node__name">' + this.escapeHtml(n.name || n.node_id || '-') + '</div>' +
          '<div class="donate-node__meta"><span class="mono">' + this.escapeHtml(addr) + '</span> · 捐赠者 ' + this.escapeHtml(n.donated_by) + '</div></div>' +
          (online ? '<span class="badge badge-success"><span class="dot dot-success"></span>在线</span>'
                  : '<span class="badge badge-muted"><span class="dot dot-muted"></span>离线</span>') +
        '</div>';
      }).join('');
    } catch (e) { /* 已提示 */ }
  },

  // ================================================================
  //  积分商城
  // ================================================================
  async loadPointsShop() {
    try {
      const pts = await this.api('GET', '/api/user/points');
      document.getElementById('pointsMyPoints').textContent = this.fmtNum(pts.points);
      this._myLevelRaw = pts.membership_level;
      this._myExpiryRaw = pts.membership_expiry;
      const member = this.memberLabel(pts.membership_level);
      document.getElementById('pointsMyMember').textContent = member;
      document.getElementById('pointsExpire').textContent =
        member === '免费' ? '长期' : (pts.membership_expiry ? String(pts.membership_expiry).slice(0, 10) : '永久');
    } catch (e) { /* 忽略 */ }

    try {
      const levels = await this.api('GET', '/api/membership/levels');
      const list = levels.levels ?? levels ?? [];
      this.setMembershipLevels(list);
      const grid = document.getElementById('membershipGrid');
      if (!list.length) {
        grid.innerHTML = '<div class="empty-state"><div class="empty-text">暂无会员等级</div></div>';
        return;
      }
      let myLevel = '';
      try {
        const pts = await this.api('GET', '/api/user/points');
        myLevel = this.memberLabel(pts.membership_level);
      } catch (e) { /* 忽略 */ }
      const isCustomLevel = (l) => /定制/.test(l.level_name || l.name || l.level || '');
      const normalLevels = list.filter(l => !isCustomLevel(l));
      const customLevels = list.filter(isCustomLevel);
      const buildCard = (l) => {
        const name = l.level_name || l.name || l.level || '';
        const need = l.points_required ?? l.required_points ?? 0;
        const label = this.memberLabel(name);
        const isCurrent = label === myLevel;
        const rights = [
          ['积分加成', l.points_bonus != null ? (l.points_bonus || 0) + '%' : null],
          ['隧道上限', l.tunnel_limit != null ? l.tunnel_limit + ' 条' : null],
          ['节点上限', l.node_limit != null ? l.node_limit + ' 个' : null],
          ['自定义域名', l.domain_limit != null ? l.domain_limit + ' 个' : null],
          ['SSL 证书', l.ssl_limit != null ? l.ssl_limit + ' 个' : null],
          ['带宽上限', l.speed_limit != null ? l.speed_limit + ' Mbps' : null],
          ['有效期', !l.duration_days ? '长期' : (l.duration_days >= 36500 ? '永久' : l.duration_days + ' 天')],
        ].filter(r => r[1] !== null);
        const perks = '<ul class="level-perks">' +
          rights.map(r => '<li><span>' + r[0] + '</span><b>' + this.escapeHtml(r[1]) + '</b></li>').join('') + '</ul>';
        const isCustom = /定制/.test(label);
        let action;
        if (isCurrent) action = '<div class="level-note">当前等级</div>';
        else if (isCustom) action = '<a class="btn btn-secondary btn-sm" href="https://qm.qq.com/q/54LdZUL3sQ" target="_blank" rel="noopener">联系客服</a>';
        else if (need > 0) action = '<button class="btn btn-primary btn-sm" data-level-id="' + this.escapeHtml(l.id ?? 0) + '" data-level-name="' + this.escapeHtml(label) + '" data-level-need="' + this.escapeHtml(need) + '">兑换</button>';
        else action = '<div class="level-note">免费档</div>';
        const priceText = isCustom
          ? '联系客服定制'
          : (need > 0 ? this.fmtNum(need) + ' 积分 · ' + (l.duration_days >= 36500 ? '永久' : (l.duration_days ? l.duration_days + ' 天' : '长期')) : '无需积分');
        return '<div class="membership-card' + (isCurrent ? ' current' : '') + '">' +
          '<div class="level-name">' + this.escapeHtml(label) + '</div>' +
          '<div class="level-points">' + priceText + '</div>' +
          perks + action +
        '</div>';
      };
      grid.innerHTML = normalLevels.map(buildCard).join('');
      const group = document.getElementById('customMembershipGroup');
      if (group) {
        group.innerHTML = customLevels.length
          ? '<div class="card"><h3>定制会员组</h3>' +
            '<p class="card-sub">按需定制隧道数量、带宽、节点与专属域名，联系客服获取方案。</p>' +
            '<div class="membership-grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr));">' +
            customLevels.map(buildCard).join('') + '</div></div>'
          : '';
      }
      document.querySelectorAll('[data-level-id]').forEach(btn => {
        btn.addEventListener('click', () => {
          this.exchangeMembership(btn.getAttribute('data-level-id'), btn.getAttribute('data-level-name'), Number(btn.getAttribute('data-level-need')));
        });
      });
    } catch (e) {
      document.getElementById('membershipGrid').innerHTML =
        '<div class="empty-state"><div class="empty-text">加载会员等级失败</div></div>';
    }
  },

  async redeemCode() {
    const input = document.getElementById('redeemCodeInput');
    const code = input.value.trim();
    if (!code) { this.showToast('请输入兑换码', 'warning'); return; }
    try {
      const res = await this.api('POST', '/api/redeem-code', { code: code });
      this.showToast(res.message || '兑换成功', 'success');
      input.value = '';
      this.loadPointsShop();
      this.loadDashboard();
    } catch (e) { /* 已提示 */ }
  },

  exchangeMembership(levelId, level, points) {
    this.showConfirm('确定要使用 ' + this.fmtNum(points) + ' 积分兑换「' + level + '」会员吗？积分扣除后不退回。', async () => {
      try {
        await this.api('POST', '/api/membership/exchange', { level_id: levelId });
        this.showToast('兑换成功！您现在已是「' + level + '」会员', 'success');
        this.loadPointsShop();
        this.loadDashboard();
      } catch (e) { /* 已提示 */ }
    }, '兑换会员');
  },

  // ================================================================
  //  个人中心
  // ================================================================
  async loadProfile() {
    const card = document.getElementById('profileInfoCard');
    try {
      const data = await this.api('GET', '/api/user-info');
      this.userEmail = data.email || '';
      const avatar = data.avatar_url
        ? '<img class="profile-avatar" src="' + this.escapeHtml(data.avatar_url) + '" alt="" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'">' +
          '<span class="profile-avatar profile-avatar--initial" style="display:none">' + this.escapeHtml((data.username || 'U').slice(0, 1).toUpperCase()) + '</span>'
        : '<span class="profile-avatar profile-avatar--initial">' + this.escapeHtml((data.username || 'U').slice(0, 1).toUpperCase()) + '</span>';
      card.innerHTML =
        '<div class="profile-head">' + avatar +
          '<div class="profile-id">' +
            '<div class="profile-name">' + this.escapeHtml(data.username || '-') +
              (data.role === 'admin' ? '<span class="badge badge-info">管理员</span>' : '') + '</div>' +
            '<div class="profile-mail mono">' + this.escapeHtml(data.email || '未绑定邮箱') + '</div>' +
            '<div class="profile-qq">QQ：' + this.escapeHtml(data.qq || '未填写') + '</div>' +
          '</div>' +
        '</div>' +
        '<dl class="profile-stats">' +
          '<div><dt>积分</dt><dd>' + this.fmtNum(data.points) + '</dd></div>' +
          '<div><dt>会员</dt><dd id="profileMembership">' + this.escapeHtml(this.memberLabel(data.membership_level)) + '</dd></div>' +
          '<div><dt>注册时间</dt><dd>' + this.escapeHtml(String(data.created_at || '-').slice(0, 10)) + '</dd></div>' +
          '<div><dt>隧道数</dt><dd>' + this.fmtNum(data.tunnel_count ?? 0) + '</dd></div>' +
        '</dl>';
      this.applyAvatar(data.avatar_url || '');
      this.applyBackground(data.background_url || '');
      document.getElementById('profileToken').textContent = data.token || '未生成';
      const cur = document.getElementById('profileEmailCurrent');
      const badge = document.getElementById('profileEmailBadge');
      if (cur) cur.textContent = data.email || '未绑定';
      if (badge) {
        badge.textContent = data.email ? '已绑定' : '未绑定';
        badge.className = 'badge ' + (data.email ? 'badge-success' : 'badge-warning');
      }
      if (document.getElementById('profileUsername')) document.getElementById('profileUsername').placeholder = data.username || '新用户名';
      if (document.getElementById('profileEmail')) document.getElementById('profileEmail').placeholder = data.email || '输入新邮箱地址';
      if (document.getElementById('profileQQ')) document.getElementById('profileQQ').placeholder = data.qq || 'QQ 号';
    } catch (e) {
      card.innerHTML = '<div class="empty-state"><div class="empty-text">加载个人信息失败</div></div>';
    }
  },

  async updateUsername() {
    const val = document.getElementById('profileUsername').value.trim();
    if (!val) { this.showToast('请输入用户名', 'warning'); return; }
    try {
      const res = await this.api('POST', '/api/update-username', { username: val });
      this.showToast(res.message || '用户名已更新，请重新登录', 'success');
      document.getElementById('profileUsername').value = '';
      // 会话里仍保存旧用户名，重新登录后各项接口才能按新用户名工作
      setTimeout(() => { window.location.href = '/logout'; }, 1200);
    } catch (e) { /* 已提示 */ }
  },

  async updateEmail() {
    const val = document.getElementById('profileEmail').value.trim();
    const pwd = document.getElementById('profileEmailPassword').value;
    if (!val) { this.showToast('请输入邮箱', 'warning'); return; }
    if (!pwd) { this.showToast('请输入当前密码验证身份', 'warning'); return; }
    try {
      await this.api('POST', '/api/update-email', { email: val, current_password: pwd });
      this.showToast('邮箱已更新', 'success');
      document.getElementById('profileEmail').value = '';
      document.getElementById('profileEmailPassword').value = '';
      this.loadProfile();
    } catch (e) { /* 已提示 */ }
  },

  async updatePassword() {
    const cur = document.getElementById('profileCurrentPassword').value;
    const next = document.getElementById('profilePassword').value;
    if (!cur) { this.showToast('请输入当前密码', 'warning'); return; }
    if (!next) { this.showToast('请输入新密码', 'warning'); return; }
    if (next.length < 6) { this.showToast('新密码至少 6 位', 'warning'); return; }
    try {
      const res = await this.api('POST', '/api/update-password', { current_password: cur, new_password: next });
      this.showToast(res.message || '密码已更新', 'success');
      document.getElementById('profileCurrentPassword').value = '';
      document.getElementById('profilePassword').value = '';
    } catch (e) { /* 已提示 */ }
  },

  async updateQQ() {
    const val = document.getElementById('profileQQ').value.trim();
    if (!val) { this.showToast('请输入QQ号', 'warning'); return; }
    try {
      await this.api('POST', '/api/update-qq', { qq: val });
      this.showToast('QQ 已更新', 'success');
      document.getElementById('profileQQ').value = '';
      this.loadProfile();
    } catch (e) { /* 已提示 */ }
  },

  applyBackground(url) {
    const body = document.body;
    if (url) {
      body.style.setProperty('--user-bg', 'url("' + String(url).replace(/"/g, '%22') + '")');
      body.classList.add('has-bg');
    } else {
      body.classList.remove('has-bg');
      body.style.removeProperty('--user-bg');
    }
  },

  async uploadBackground() {
    const input = document.getElementById('backgroundFile');
    const status = document.getElementById('backgroundUploadStatus');
    const file = input && input.files && input.files[0];
    if (!file) { this.showToast('请选择图片文件', 'warning'); return; }
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) {
      this.showToast('仅支持 PNG / JPG / WebP', 'warning'); return;
    }
    if (file.size > 8 * 1024 * 1024) {
      this.showToast('图片不能超过 8MB', 'warning'); return;
    }
    if (status) status.textContent = '上传中…';
    const fd = new FormData();
    fd.append('background', file);
    try {
      const res = await fetch('/api/background/upload', {
        method: 'POST', body: fd, credentials: 'same-origin',
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) throw new Error(data.message || '上传失败');
      if (status) status.textContent = '已应用';
      input.value = '';
      const name = document.getElementById('backgroundFileName');
      if (name) name.textContent = '未选择文件';
      this.applyBackground(data.background_url);
      this.showToast('背景图已更新', 'success');
    } catch (e) {
      if (status) status.textContent = (e && e.message) || '上传失败';
      this.showToast((e && e.message) || '上传失败', 'error');
    }
  },

  async removeBackground() {
    try {
      await this.api('POST', '/api/background/remove', {});
      this.applyBackground('');
      const status = document.getElementById('backgroundUploadStatus');
      if (status) status.textContent = '背景已移除';
      this.showToast('背景已移除', 'success');
    } catch (e) { /* 已提示 */ }
  },

  applyAvatar(url) {
    document.querySelectorAll('.user-avatar').forEach(el => {
      if (url) {
        el.innerHTML = '<img src="' + this.escapeHtml(url) + '" alt="">';
      }
    });
  },

  async uploadAvatar() {
    const input = document.getElementById('avatarFile');
    const status = document.getElementById('avatarUploadStatus');
    const file = input && input.files && input.files[0];
    if (!file) { this.showToast('请选择图片文件', 'warning'); return; }
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) {
      this.showToast('仅支持 PNG / JPG / WebP', 'warning');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      this.showToast('图片不能超过 3MB', 'warning');
      return;
    }
    if (status) status.textContent = '上传中…';
    const fd = new FormData();
    fd.append('avatar', file);
    try {
      const res = await fetch('/api/avatar/upload', {
        method: 'POST', body: fd, credentials: 'same-origin',
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) throw new Error(data.message || '上传失败');
      if (status) status.textContent = '上传成功';
      this.showToast('头像已更新', 'success');
      input.value = '';
      this.applyAvatar(data.avatar_url);
      this.loadProfile();
    } catch (e) {
      if (status) status.textContent = (e && e.message) || '上传失败';
      this.showToast((e && e.message) || '上传失败', 'error');
    }
  },

  copyToken() {
    const token = document.getElementById('profileToken').textContent;
    if (token && token !== '-' && token !== '未生成') this.copyText(token);
  },

  // ===== 邮箱验证码（6 格 OTP） =====
  maskEmail(e) {
    if (!e || e.indexOf('@') < 0) return e || '你的邮箱';
    const parts = e.split('@');
    return parts[0].slice(0, Math.min(3, parts[0].length)) + '****@' + parts[1];
  },

  buildOtpBoxes() {
    const wrap = document.getElementById('otpBoxes');
    wrap.innerHTML = '';
    for (let i = 0; i < 6; i++) {
      const inp = document.createElement('input');
      inp.className = 'otp-box';
      inp.type = 'text';
      inp.inputMode = 'numeric';
      inp.autocomplete = 'one-time-code';
      inp.maxLength = 1;
      inp.setAttribute('aria-label', '验证码第 ' + (i + 1) + ' 位');
      inp.addEventListener('input', () => {
        inp.value = inp.value.replace(/\D/g, '').slice(0, 1);
        this.clearOtpError();
        if (inp.value && i < 5) wrap.children[i + 1].focus();
      });
      inp.addEventListener('keydown', (ev) => {
        if (ev.key === 'Backspace' && !inp.value && i > 0) wrap.children[i - 1].focus();
        if (ev.key === 'ArrowLeft' && i > 0) wrap.children[i - 1].focus();
        if (ev.key === 'ArrowRight' && i < 5) wrap.children[i + 1].focus();
        if (ev.key === 'Enter') this.otpSubmit();
      });
      inp.addEventListener('paste', (ev) => {
        ev.preventDefault();
        const digits = (ev.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
        const list = digits.split('');
        list.forEach((d, k) => { if (wrap.children[i + k]) wrap.children[i + k].value = d; });
        const next = Math.min(i + list.length, 5);
        wrap.children[next].focus();
        this.clearOtpError();
      });
      wrap.appendChild(inp);
    }
  },

  otpValue() {
    return [...document.querySelectorAll('#otpBoxes .otp-box')].map(x => x.value).join('');
  },

  clearOtpError() {
    const err = document.getElementById('otpError');
    if (err) err.textContent = '';
    document.querySelectorAll('#otpBoxes .otp-box').forEach(b => b.classList.remove('is-error'));
  },

  showOtpError(msg) {
    const err = document.getElementById('otpError');
    if (err) err.textContent = msg || '';
    document.querySelectorAll('#otpBoxes .otp-box').forEach(b => b.classList.add('is-error'));
    const first = document.querySelector('#otpBoxes .otp-box');
    if (first) first.focus();
  },

  openOtpModal(purpose, title, email, run) {
    this._otpPurpose = purpose;
    this._otpRun = run;
    this.buildOtpBoxes();
    this.clearOtpError();
    document.getElementById('otpTitle').textContent = (title || '高风险操作') + ' · 邮箱验证';
    document.getElementById('otpSub').innerHTML =
      '验证码已发送至 <b>' + this.escapeHtml(this.maskEmail(email)) + '</b>，10 分钟内有效';
    const btn = document.getElementById('otpSubmitBtn');
    btn.disabled = false;
    btn.textContent = '验证';
    document.getElementById('otpModal').classList.add('open');
    setTimeout(() => {
      const f = document.querySelector('#otpBoxes .otp-box');
      if (f) f.focus();
    }, 60);
    this.otpCountdown(60);
  },

  closeOtp() {
    document.getElementById('otpModal').classList.remove('open');
    if (this._otpTimer) { clearInterval(this._otpTimer); this._otpTimer = null; }
    this._otpRun = null;
  },

  otpCountdown(sec) {
    const b = document.getElementById('otpResendBtn');
    if (!b) return;
    if (this._otpTimer) clearInterval(this._otpTimer);
    let left = sec;
    b.disabled = true;
    b.textContent = left + ' 秒后可重发';
    this._otpTimer = setInterval(() => {
      left -= 1;
      if (left <= 0) {
        clearInterval(this._otpTimer);
        this._otpTimer = null;
        b.disabled = false;
        b.textContent = '重新发送';
      } else {
        b.textContent = left + ' 秒后可重发';
      }
    }, 1000);
  },

  async otpResend() {
    const b = document.getElementById('otpResendBtn');
    if (b && b.disabled) return;
    const captchaId = await this.withCaptcha();
    if (!captchaId) return;
    try {
      const sent = await this.api('POST', '/api/email/send-code', { purpose: this._otpPurpose, captcha_id: captchaId });
      this.showToast(sent.message || '验证码已重新发送', 'success');
      this.otpCountdown(60);
    } catch (e) { /* 已提示 */ }
  },

  async otpSubmit() {
    const code = this.otpValue();
    if (code.length !== 6) { this.showOtpError('请输入完整的 6 位验证码'); return; }
    const btn = document.getElementById('otpSubmitBtn');
    btn.disabled = true;
    btn.textContent = '验证中…';
    try {
      await this._otpRun(code);
      this.closeOtp();
    } catch (e) {
      this.showOtpError((e && e.message) || '验证失败，请重试');
      btn.disabled = false;
      btn.textContent = '验证';
    }
  },

  guardHighRisk(purpose, confirmText, run, title) {
    this.showConfirm(confirmText, async () => {
      const captchaId = await this.withCaptcha();
      if (!captchaId) return;
      let sent;
      try {
        sent = await this.api('POST', '/api/email/send-code', { purpose: purpose, captcha_id: captchaId });
      } catch (e) { return; }
      if (sent && sent.configured === false) {
        this.showToast('邮箱服务未配置，请联系管理员', 'warning');
        return;
      }
      this.openOtpModal(purpose, title, this.userEmail || '', run);
    }, '继续');
  },

  async regenerateToken() {
    this.guardHighRisk('regenerate_token', '确定要重新生成 Token 吗？旧 Token 将立即失效，使用旧 Token 的 frpc 会被断开。', async (code) => {
      const res = await this.api('POST', '/api/regenerate-token', { email_code: code });
      document.getElementById('profileToken').textContent = res.token || '已重新生成';
      this.showToast('Token 已重新生成', 'success');
    }, '重新生成 Token');
  },

  async deleteAccount() {
    this.guardHighRisk('delete_account', '确定要注销账户吗？所有隧道与积分将被永久删除，此操作不可恢复！', async (code) => {
      await this.api('POST', '/api/delete-account', { email_code: code });
      this.showToast('账户已注销', 'success');
      setTimeout(() => { window.location.href = '/logout'; }, 1200);
    }, '注销账户');
  },

  async stopAllTunnels() {
    this.guardHighRisk('stop_all_tunnels', '确定要停止所有隧道吗？所有使用这些隧道的 frpc 都会断开。', async (code) => {
      await this.api('POST', '/api/stop-all-tunnels', { email_code: code });
      this.showToast('已停止所有隧道', 'success');
      this.loadDashboard();
      this.loadTunnels();
    }, '停止所有隧道');
  },

  // ================================================================
  //  管理员后台
  // ================================================================
  switchAdminTab(tabId) {
    this.currentAdminTab = tabId;
    document.querySelectorAll('#adminTabs .tab-item').forEach(t => {
      const on = t.dataset.tab === tabId;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    document.querySelectorAll('.tab-content[id^="tab-admin"]').forEach(t =>
      t.classList.toggle('active', t.id === 'tab-' + tabId));
    switch (tabId) {
      case 'admin-users': this.loadAdminUsers(); break;
      case 'admin-tunnels': break;
      case 'admin-nodes': this.loadAdminNodes(); break;
      case 'admin-codes': this.loadAdminCodes(); break;
      case 'admin-frps': this.loadTraffic(); this.loadAdminFRPS(); break;
      case 'admin-backup': this.loadAdminBackups(); break;
    }
  },

  async loadAdminBackups() {
    const el = document.getElementById('backupList');
    if (!el) return;
    try {
      const d = await this.api('GET', '/api/admin/backup/list');
      const items = d.backups || [];
      if (!items.length) {
        el.innerHTML = '<p class="note">还没有快照，点上方「下载当前备份」会立即生成一份。</p>';
        return;
      }
      el.innerHTML = items.map(b => {
        const size = b.size >= 1048576 ? (b.size / 1048576).toFixed(1) + ' MB'
          : (b.size / 1024).toFixed(0) + ' KB';
        const when = new Date(b.mtime * 1000).toLocaleString();
        return '<div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-top:1px solid var(--line-soft);">' +
          '<span class="mono" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + this.escapeHtml(b.name) + '</span>' +
          '<span class="cell-sub">' + this.escapeHtml(size) + '</span>' +
          '<span class="cell-sub">' + this.escapeHtml(when) + '</span>' +
          '<a class="btn btn-ghost btn-sm" href="/api/admin/backup/file/' + encodeURIComponent(b.name) + '">下载</a>' +
        '</div>';
      }).join('');
    } catch (e) {
      el.innerHTML = '<p class="note">快照列表加载失败</p>';
    }
  },

  restoreBackup() {
    const input = document.getElementById('restoreBackupFile');
    const status = document.getElementById('backupStatus');
    const file = input && input.files && input.files[0];
    if (!file) { this.showToast('请先选择 .db 备份文件', 'warning'); return; }
    this.showConfirm('恢复会覆盖当前所有用户、隧道、节点和积分数据。面板会自动先保存一份当前库，确定继续吗？', async () => {
      if (status) status.textContent = '恢复中…';
      const fd = new FormData();
      fd.append('backup', file);
      try {
        const res = await fetch('/api/admin/backup/restore', {
          method: 'POST', body: fd, credentials: 'same-origin',
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) throw new Error(data.message || '恢复失败');
        if (status) status.textContent = data.message || '恢复完成';
        this.showToast('恢复完成，页面即将刷新', 'success');
        setTimeout(() => location.reload(), 1500);
      } catch (e) {
        if (status) status.textContent = (e && e.message) || '恢复失败';
        this.showToast((e && e.message) || '恢复失败', 'error');
      }
    }, '确认恢复');
  },

  // —— 用户管理 ——
  async loadAdminUsers() {
    const tbody = document.getElementById('adminUserTableBody');
    try {
      const search = ((document.getElementById('adminUserSearch') || {}).value || '').trim().toLowerCase();
      // 后端 /api/admin/users 暂不支持 search 参数，这里在前端过滤（用户名/邮箱/ID）
      const data = await this.api('GET', '/api/admin/users');
      const all = data.users ?? data ?? [];
      const users = search
        ? all.filter(u => String(u.username || '').toLowerCase().indexOf(search) !== -1
            || String(u.email || '').toLowerCase().indexOf(search) !== -1
            || String(u.id) === search)
        : all;
      this.adminUsersData = users;
      if (!users.length) {
        tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">' +
          (search ? '没有匹配的用户' : '暂无用户') + '</div></div></td></tr>';
        return;
      }
      tbody.innerHTML = users.map(u => {
        return '<tr>' +
          '<td class="mono">' + (u.id ?? '-') + '</td>' +
          '<td><div class="cell-main">' + this.escapeHtml(u.username || '-') + '</div></td>' +
          '<td class="mono cell-sub">' + this.escapeHtml(u.email || '未绑定') + '</td>' +
          '<td>' + this.fmtNum(u.points) + '</td>' +
          '<td>' + this.escapeHtml(this.memberLabel(u.membership_level ?? u.membership ?? u.level)) +
            '<div class="cell-sub">限速 ' + (u.effective_speed > 0 ? u.effective_speed + ' MB/s' : '跟随会员') +
            (u.bandwidth_limit > 0 ? ' · 管理员设定' : '') +
            (u.effective_limits ? ' · 隧道 ' + (u.effective_limits.tunnel || 0) + ' 条' : '') + '</div></td>' +
          '<td class="mono cell-sub">' + this.escapeHtml(String(u.created_at ?? '-').slice(0, 10)) + '</td>' +
          '<td><div class="btn-group">' +
            '<button class="btn btn-ghost btn-xs" data-uid-tunnels="' + u.id + '">隧道</button>' +
            '<button class="btn btn-ghost btn-xs" data-uid-custom="' + u.id + '">定制</button>' +
            '<button class="btn btn-ghost btn-xs" data-uid-bandwidth="' + u.id + '">限速</button>' +
            '<button class="btn btn-ghost btn-xs" data-uid-password="' + u.id + '">重置密码</button>' +
            '<button class="btn btn-danger btn-xs" data-uid-delete="' + u.id + '">删除</button>' +
          '</div></td>' +
        '</tr>';
      }).join('');
      tbody.querySelectorAll('[data-uid-tunnels]').forEach(b =>
        b.addEventListener('click', () => this.adminUserTunnels(b.getAttribute('data-uid-tunnels'))));
      tbody.querySelectorAll('[data-uid-custom]').forEach(b =>
        b.addEventListener('click', () => this.adminCustomizeUser(b.getAttribute('data-uid-custom'))));
      tbody.querySelectorAll('[data-uid-bandwidth]').forEach(b =>
        b.addEventListener('click', () => this.adminSetBandwidth(b.getAttribute('data-uid-bandwidth'))));
      tbody.querySelectorAll('[data-uid-password]').forEach(b =>
        b.addEventListener('click', () => this.adminResetPassword(b.getAttribute('data-uid-password'))));
      tbody.querySelectorAll('[data-uid-delete]').forEach(b =>
        b.addEventListener('click', () => this.adminDeleteUser(b.getAttribute('data-uid-delete'))));
    } catch (e) {
      tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">加载失败</div></div></td></tr>';
    }
  },

  adminDeleteUser(id) {
    this.showConfirm('确定要删除用户 #' + id + ' 吗？该用户的所有隧道与积分都会被删除。', () => {
      this.api('DELETE', '/api/admin/users/' + id).then(() => {
        this.showToast('用户已删除', 'success');
        this.loadAdminUsers();
      }).catch(() => {});
    }, '删除用户', true);
  },

  async adminCustomizeUser(id) {
    const user = (this.adminUsersData || []).find(u => String(u.id) === String(id)) || {};
    let levels = [];
    try {
      const data = await this.api('GET', '/api/membership/levels');
      levels = (data.levels ?? data ?? []).map(l => ({
        value: String(l.id),
        label: this.memberLabel(l.level_name || l.name || ''),
      }));
    } catch (e) { /* 等级加载失败时仍可改额度 */ }
    const levelOptions = [{ value: '', label: '不修改会员等级' }].concat(levels);
    this.showForm('定制会员 · 用户 #' + id, [
      { name: 'level_id', label: '会员等级', type: 'select', options: levelOptions },
      { name: 'days', label: '有效期', type: 'select', value: '365', options: [
        { value: '30', label: '30 天' }, { value: '90', label: '90 天' },
        { value: '365', label: '365 天' }, { value: '99999', label: '永久' },
      ] },
      { name: 'tunnel', label: '隧道上限（0 = 跟随等级）', type: 'number', value: user.custom_tunnel_limit || 0 },
      { name: 'node', label: '节点上限（0 = 跟随等级）', type: 'number', value: user.custom_node_limit || 0 },
      { name: 'domain', label: '域名上限（0 = 跟随等级）', type: 'number', value: user.custom_domain_limit || 0 },
      { name: 'ssl', label: 'SSL 上限（0 = 跟随等级）', type: 'number', value: user.custom_ssl_limit || 0 },
      { name: 'bandwidth', label: '带宽限速 MB/s（0 = 跟随等级）', type: 'number', value: user.bandwidth_limit || 0 },
    ], async (data) => {
      const tasks = [];
      if (data.level_id) {
        tasks.push(this.api('PUT', '/api/admin/users/' + id + '/membership', {
          level_id: parseInt(data.level_id, 10),
          days: parseInt(data.days, 10) || 365,
        }));
      }
      tasks.push(this.api('PUT', '/api/admin/users/' + id + '/limits', {
        tunnel: parseInt(data.tunnel, 10) || 0,
        node: parseInt(data.node, 10) || 0,
        domain: parseInt(data.domain, 10) || 0,
        ssl: parseInt(data.ssl, 10) || 0,
      }));
      tasks.push(this.api('PUT', '/api/admin/users/' + id + '/bandwidth', {
        limit: parseInt(data.bandwidth, 10) || 0,
      }));
      await Promise.all(tasks);
      this.showToast('定制会员已更新', 'success');
      this.loadAdminUsers();
    });
  },

  adminSetBandwidth(id) {
    const user = (this.adminUsersData || []).find(u => String(u.id) === String(id)) || {};
    this.showForm('设置限速 · 用户 #' + id, [
      { name: 'limit', label: '限速 MB/s（0 = 跟随会员等级）', type: 'number', value: user.bandwidth_limit || 0 },
    ], async (data) => {
      await this.api('PUT', '/api/admin/users/' + id + '/bandwidth', {
        limit: parseInt(data.limit, 10) || 0,
      });
      this.showToast('限速已更新', 'success');
      this.loadAdminUsers();
    });
  },

  adminResetPassword(id) {
    this.showForm('重置密码 · 用户 #' + id, [
      { name: 'password', label: '新密码', type: 'password', placeholder: '输入新密码', required: true },
    ], async (data) => {
      try {
        await this.api('PUT', '/api/admin/users/' + id + '/password', { password: data.password });
        this.showToast('密码已重置', 'success');
      } catch (e) { /* 已提示 */ }
    });
  },

  adminUserTunnels(id) {
    this.switchAdminTab('admin-tunnels');
    document.getElementById('adminTunnelSearch').value = id;
    this.loadAdminTunnels(id);
  },

  // —— 隧道管理 ——
  async loadAdminTunnels(userId) {
    let uid = userId ?? ((document.getElementById('adminTunnelSearch') || {}).value);
    const tbody = document.getElementById('adminTunnelTableBody');
    uid = String(uid || '').trim();
    if (!uid) { this.showToast('请输入用户 ID', 'warning'); return; }
    try {
      const data = await this.api('GET', '/api/admin/users/' + encodeURIComponent(uid) + '/tunnels');
      const tunnels = data.tunnels ?? data ?? [];
      if (!tunnels.length) {
        tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">该用户暂无隧道</div></div></td></tr>';
        return;
      }
      tbody.innerHTML = tunnels.map(t => {
        const online = t.status === 'online' || t.status === 'running';
        return '<tr>' +
          '<td class="mono">' + (t.id ?? '-') + '</td>' +
          '<td><div class="cell-main">' + this.escapeHtml(t.name || '-') + '</div>' +
            (t.custom_domain ? '<div class="cell-sub">' + this.escapeHtml(t.custom_domain) + '</div>' : '') + '</td>' +
          '<td class="mono">' + (t.user_id ?? uid) + '</td>' +
          '<td><span class="type-tag">' + this.escapeHtml((t.type || '-').toUpperCase()) + '</span></td>' +
          '<td><span class="mono">' + this.escapeHtml((t.local_ip || '127.0.0.1') + ':' + (t.local_port ?? '')) + '</span></td>' +
          '<td class="mono">' + (t.remote_port ?? '-') + '</td>' +
          '<td>' + (online
            ? '<span class="badge badge-success"><span class="dot dot-success"></span>在线</span>'
            : '<span class="badge badge-muted"><span class="dot dot-muted"></span>离线</span>') + '</td>' +
        '</tr>';
      }).join('');
    } catch (e) {
      tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><div class="empty-text">加载失败</div></div></td></tr>';
    }
  },

  // —— 节点管理 ——
  async loadAdminNodes() {
    const grid = document.getElementById('adminNodeGrid');
    try {
      const data = await this.api('GET', '/api/nodes');
      const nodes = data.nodes ?? data ?? [];
      this.adminNodesData = nodes;
      if (!nodes.length) {
        grid.innerHTML = '<div class="empty-state empty-card"><div class="empty-text">暂无节点</div><div class="empty-sub">捐赠节点接入后会出现在这里，等待审核</div></div>';
        return;
      }
      grid.innerHTML = nodes.map(n => {
        const approved = Number(n.approved) === 1;
        const isOnline = n.status === 'online' || n.status === 'active';
        const badge = !approved
          ? '<span class="badge badge-warning">待审核</span>'
          : (isOnline
              ? '<span class="badge badge-success"><span class="dot dot-success"></span>在线</span>'
              : '<span class="badge badge-muted"><span class="dot dot-muted"></span>离线</span>');
        const s = n.stats || {};
        const meta = [
          ['CPU', (Number(s.cpu_usage) || 0).toFixed(0) + '%'],
          ['内存', (Number(s.memory_usage) || 0).toFixed(0) + '%'],
          ['客户端', s.client_count ?? 0],
          ['允许端口', n.allowed_ports || '不限'],
          ['心跳', n.heartbeat_age != null ? n.heartbeat_age + ' 秒前' : '-'],
        ];
        const actions = !approved
          ? '<button class="btn btn-ghost btn-sm" data-an-meta="' + this.escapeHtml(n.node_id) + '">编辑</button>' +
            '<button class="btn btn-success btn-sm" data-an-approve="' + this.escapeHtml(n.node_id) + '">通过</button>' +
            '<button class="btn btn-warning btn-sm" data-an-reject="' + this.escapeHtml(n.node_id) + '">拒绝</button>' +
            '<button class="btn btn-danger btn-sm" data-an-delete="' + this.escapeHtml(n.node_id) + '">删除</button>'
          : '<button class="btn btn-ghost btn-sm" data-an-meta="' + this.escapeHtml(n.node_id) + '">编辑</button>' +
            '<button class="btn btn-ghost btn-sm" data-an-rename="' + this.escapeHtml(n.node_id) + '">改名</button>' +
            '<button class="btn btn-warning btn-sm" data-an-revoke="' + this.escapeHtml(n.node_id) + '">取消审核</button>' +
            '<button class="btn btn-danger btn-sm" data-an-delete="' + this.escapeHtml(n.node_id) + '">删除</button>';
        return '<div class="node-card">' +
          '<div class="node-card__top"><div>' +
            '<div class="node-name">' + this.escapeHtml(n.name || 'Node #' + n.id) + '</div>' +
            '<div class="node-addr mono">' + this.escapeHtml(n.host ? (n.host + (n.port ? ':' + n.port : '')) : '-') +
              ' · 捐赠者 ' + this.escapeHtml(n.donated_by || '匿名') + '</div>' +
            (n.description ? '<div class="cell-sub" style="margin-top:4px;">' + this.escapeHtml(n.description) + '</div>' : '') +
          '</div>' + badge + '</div>' +
          '<dl class="node-meta">' + meta.map(m =>
            '<div><dt>' + m[0] + '</dt><dd>' + this.escapeHtml(m[1]) + '</dd></div>').join('') + '</dl>' +
          '<div class="node-actions">' + actions + '</div>' +
        '</div>';
      }).join('');
      grid.querySelectorAll('[data-an-approve]').forEach(b =>
        b.addEventListener('click', () => this.approveNode(b.getAttribute('data-an-approve'), true)));
      grid.querySelectorAll('[data-an-reject]').forEach(b =>
        b.addEventListener('click', () => this.approveNode(b.getAttribute('data-an-reject'), false)));
      grid.querySelectorAll('[data-an-meta]').forEach(b =>
        b.addEventListener('click', () => this.adminEditNodeMeta(b.getAttribute('data-an-meta'))));
      grid.querySelectorAll('[data-an-rename]').forEach(b =>
        b.addEventListener('click', () => this.editNodeName(b.getAttribute('data-an-rename'))));
      grid.querySelectorAll('[data-an-revoke]').forEach(b =>
        b.addEventListener('click', () => this.approveNode(b.getAttribute('data-an-revoke'), false)));
      grid.querySelectorAll('[data-an-delete]').forEach(b =>
        b.addEventListener('click', () => this.confirmDeleteNode(b.getAttribute('data-an-delete'))));
    } catch (e) {
      grid.innerHTML = '<div class="empty-state"><div class="empty-text">加载失败</div></div>';
    }
  },

  // —— 兑换码管理 ——
  async loadAdminCodes() {
    const tbody = document.getElementById('adminCodeTableBody');
    try {
      const data = await this.api('GET', '/api/admin/redeem-codes');
      const codes = data.codes ?? data ?? [];
      if (!codes.length) {
        tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state"><div class="empty-text">还没有兑换码</div><div class="empty-sub">生成一张发给用户，即可兑换对应积分</div></div></td></tr>';
        return;
      }
      tbody.innerHTML = codes.map(c => {
        const used = Number(c.is_used ?? c.used) === 1;
        return '<tr>' +
          '<td class="mono">' + (c.id ?? '-') + '</td>' +
          '<td><code class="code-chip">' + this.escapeHtml(c.code || '-') + '</code></td>' +
          '<td>' + this.fmtNum(c.points) + '</td>' +
          '<td>' + (used
            ? '<span class="badge badge-muted">已使用' + (c.used_by_name ? ' · ' + this.escapeHtml(c.used_by_name) : '') + '</span>'
            : '<span class="badge badge-success">未使用</span>') + '</td>' +
          '<td class="mono cell-sub">' + this.escapeHtml(String(c.created_at || '-').slice(0, 10)) + '</td>' +
          '<td><button class="btn btn-danger btn-xs" data-code-delete="' + c.id + '">删除</button></td>' +
        '</tr>';
      }).join('');
      tbody.querySelectorAll('[data-code-delete]').forEach(b =>
        b.addEventListener('click', () => this.adminDeleteCode(b.getAttribute('data-code-delete'))));
    } catch (e) {
      tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state"><div class="empty-text">加载失败</div></div></td></tr>';
    }
  },

  async createRedeemCode() {
    const code = document.getElementById('adminCodeInput').value.trim();
    const points = parseInt(document.getElementById('adminCodePoints').value, 10);
    if (!points || points <= 0) { this.showToast('请输入有效的积分值', 'warning'); return; }
    const body = { points: points };
    if (code) body.code = code;
    try {
      const res = await this.api('POST', '/api/admin/redeem-codes', body);
      this.showToast('兑换码已生成' + (res.code ? '：' + res.code : ''), 'success');
      document.getElementById('adminCodeInput').value = '';
      document.getElementById('adminCodePoints').value = '';
      this.loadAdminCodes();
    } catch (e) { /* 已提示 */ }
  },

  adminDeleteCode(id) {
    this.showConfirm('确定要删除兑换码 #' + id + ' 吗？', () => {
      this.api('DELETE', '/api/admin/redeem-codes/' + id).then(() => {
        this.showToast('兑换码已删除', 'success');
        this.loadAdminCodes();
      }).catch(() => {});
    }, '删除兑换码', true);
  },

  // —— 积分调整 ——
  async loadAdminMembershipLevels() {
    const sel = document.getElementById('adminMemberLevel');
    if (!sel) return;
    try {
      const data = await this.api('GET', '/api/membership/levels');
      const list = data.levels ?? data ?? [];
      if (!list.length) return;
      sel.innerHTML = list.map(l =>
        '<option value="' + this.escapeHtml(l.id) + '">' +
          this.escapeHtml(this.memberLabel(l.level_name || l.name || ('等级 ' + l.id))) +
          (l.points_required ? '（' + this.fmtNum(l.points_required) + ' 积分档）' : '') + '</option>'
      ).join('');
      // 选中后按等级默认有效期自动填天数（1–3650 内）
      const applyDays = () => {
        const lit = sel.options[sel.selectedIndex];
        const lv = list.find(x => String(x.id) === sel.value);
        const daysEl = document.getElementById('adminMemberDays');
        if (!lv || !daysEl) return;
        const d = Number(lv.duration_days) || 30;
        daysEl.value = d > 0 ? Math.min(d, 3650) : (lit ? 30 : 30);
      };
      sel.addEventListener('change', applyDays);
      applyDays();
    } catch (e) { /* 保留静态兜底项 */ }
  },

  async adminAdjustPoints() {
    const userId = document.getElementById('adminPointsUserId').value.trim();
    const points = parseInt(document.getElementById('adminPointsValue').value, 10);
    if (!userId) { this.showToast('请输入用户 ID', 'warning'); return; }
    if (isNaN(points) || points < 0) { this.showToast('积分必须为非负整数', 'warning'); return; }
    try {
      const res = await this.api('PUT', '/api/admin/users/' + encodeURIComponent(userId) + '/points', { points: points });
      this.showToast(res.message || '积分已更新', 'success');
      document.getElementById('adminPointsUserId').value = '';
      document.getElementById('adminPointsValue').value = '';
      this.loadAdminUsers();
    } catch (e) { /* 已提示 */ }
  },

  async adminAdjustMembership() {
    const userId = document.getElementById('adminMemberUserId').value.trim();
    const levelId = parseInt(document.getElementById('adminMemberLevel').value, 10);
    const days = parseInt(document.getElementById('adminMemberDays').value, 10);
    if (!userId) { this.showToast('请输入用户 ID', 'warning'); return; }
    if (isNaN(levelId)) { this.showToast('请选择会员等级', 'warning'); return; }
    if (isNaN(days) || (days !== 99999 && (days < 1 || days > 3650))) { this.showToast('有效期需在 1–3650 天，或选择永久', 'warning'); return; }
    try {
      const res = await this.api('PUT', '/api/admin/users/' + encodeURIComponent(userId) + '/membership', { level_id: levelId, days: days });
      this.showToast(res.message || '会员已更新', 'success');
      document.getElementById('adminMemberUserId').value = '';
      this.loadAdminUsers();
    } catch (e) { /* 已提示 */ }
  },

  // —— 流量监控 ——
  setTrafficRange(h) {
    this.trafficRange = h;
    document.querySelectorAll('.tr-btn').forEach(b =>
      b.classList.toggle('active', Number(b.dataset.hours) === h));
    this.loadTraffic();
  },

  fmtAxis(v) {
    if (v >= 1048576) return (v / 1048576).toFixed(1) + 'M';
    if (v >= 1024) return Math.round(v / 1024) + 'K';
    return Math.round(v) + 'B';
  },

  fmtSpeed(bps) {
    const v = Number(bps);
    if (!Number.isFinite(v)) return '-';
    if (v >= 1048576) return (v / 1048576).toFixed(2) + ' MB/s';
    if (v >= 1024) return (v / 1024).toFixed(1) + ' KB/s';
    return Math.round(v) + ' B/s';
  },

  smoothPath(pts) {
    if (pts.length < 2) return '';
    let d = 'M' + pts[0][0] + ',' + pts[0][1];
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1],
            p3 = pts[Math.min(pts.length - 1, i + 2)];
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += 'C' + c1x.toFixed(1) + ',' + c1y.toFixed(1) + ' ' + c2x.toFixed(1) + ',' + c2y.toFixed(1) + ' ' + p2[0].toFixed(1) + ',' + p2[1].toFixed(1);
    }
    return d;
  },

  userTrafficRange: 24,

  setUserTrafficRange(h) {
    this.userTrafficRange = h;
    document.querySelectorAll('[data-uthours]').forEach(b =>
      b.classList.toggle('active', Number(b.dataset.uthours) === h));
    this.loadUserTraffic(h);
  },

  async loadUserTraffic(hours) {
    const wrap = document.getElementById('userTrafficChart');
    if (!wrap) return;
    const h = hours || this.userTrafficRange || 24;
    try {
      const data = await this.api('GET', '/api/stats/user-traffic?hours=' + h);
      const pts = data.points || [];
      if (pts.length < 2) {
        wrap.innerHTML = '<div class="empty-state"><div class="empty-text">暂无流量数据 — 节点心跳到达后这里会出现曲线</div></div>';
        return;
      }
      const W = 900, H = 240, PADL = 52, PADR = 14, PADT = 14, PADB = 26;
      const iw = W - PADL - PADR, ih = H - PADT - PADB;
      const maxV = Math.max(1, ...pts.map(p => Math.max(p.up, p.down))) * 1.12;
      const X = i => PADL + (iw * i) / Math.max(1, pts.length - 1);
      const Y = v => PADT + ih - (ih * v) / maxV;
      const upPath = this.smoothPath(pts.map((p, i) => [X(i), Y(p.up)]));
      const dnPath = this.smoothPath(pts.map((p, i) => [X(i), Y(p.down)]));
      const area = upPath + 'L' + X(pts.length - 1) + ',' + (PADT + ih) + 'L' + PADL + ',' + (PADT + ih) + 'Z';
      const gridY = [0.25, 0.5, 0.75].map(k => PADT + ih * k);
      const grid = gridY.map(y => '<line class="grid-line" x1="' + PADL + '" y1="' + y + '" x2="' + (W - PADR) + '" y2="' + y + '"/>').join('');
      const gridLbl = gridY.map((y, i) => '<text class="axis-label" x="' + (PADL - 8) + '" y="' + (y + 3) + '" text-anchor="end">' + this.fmtBytes(maxV * (1 - [0.25, 0.5, 0.75][i])) + '</text>').join('');
      let xLbl = '';
      const n = Math.min(5, pts.length);
      const step = Math.max(1, Math.floor((pts.length - 1) / Math.max(1, n - 1)));
      pts.forEach((p, i) => {
        if (i % step === 0 || i === pts.length - 1) {
          const d = new Date(p.t);
          const lab = h >= 168 ? (d.getMonth() + 1) + '/' + d.getDate()
            : String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
          xLbl += '<text class="axis-label" x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle">' + lab + '</text>';
        }
      });
      wrap.innerHTML =
        '<div class="traffic-legend" style="margin-bottom:6px;">' +
          '<span class="lg"><i class="lg-line lg-up"></i>今日上传</span>' +
          '<span class="lg"><i class="lg-line lg-down"></i>今日下载</span>' +
        '</div>' +
        '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="我的流量折线图">' +
          grid + gridLbl + xLbl +
          '<path class="t-fill fadein" d="' + area + '"/>' +
          '<path class="tline t-down draw" style="--len:' + Math.ceil(W * 2) + '" d="' + dnPath + '"/>' +
          '<path class="tline t-up draw" style="--len:' + Math.ceil(W * 2) + '" d="' + upPath + '"/>' +
        '</svg>';
    } catch (e) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-text">加载流量失败</div></div>';
    }
  },

  async loadTraffic() {
    const wrap = document.getElementById('trafficChart');
    if (!wrap) return;
    try {
      const data = await this.api('GET', '/api/stats/traffic?hours=' + this.trafficRange);
      const pts = data.points || [];
      this._trafficPts = pts;
      const setSummary = (last) => {
        document.getElementById('trafficUpNow').textContent = last ? this.fmtSpeed(last.up) : '-';
        document.getElementById('trafficDownNow').textContent = last ? this.fmtSpeed(last.down) : '-';
        document.getElementById('trafficPeak').innerHTML =
          this.fmtSpeed(data.peak_up) + ' <span class="peak-sep">/</span> ' + this.fmtSpeed(data.peak_down);
        document.getElementById('trafficAvg').textContent = this.fmtSpeed(data.avg_down);
        document.getElementById('trafficTip').textContent =
          '采样 ' + pts.length + ' 点 · ' + this.trafficRange + ' 小时窗口';
      };
      if (pts.length < 2) {
        wrap.innerHTML = '<div class="empty-state"><div class="empty-text">暂无流量数据</div><div class="empty-sub">节点心跳到达后，这里会出现上下行曲线</div></div>';
        setSummary(null);
        return;
      }
      const W = 800, H = 260, PADL = 56, PADR = 16, PADT = 14, PADB = 26;
      const iw = W - PADL - PADR, ih = H - PADT - PADB;
      const maxV = Math.max(1, ...pts.map(p => Math.max(p.up, p.down))) * 1.12;
      const X = i => PADL + (iw * i) / Math.max(1, pts.length - 1);
      const Y = v => PADT + ih - (ih * v) / maxV;

      const upPts = pts.map((p, i) => [X(i), Y(p.up)]);
      const dnPts = pts.map((p, i) => [X(i), Y(p.down)]);
      const upPath = this.smoothPath(upPts);
      const dnPath = this.smoothPath(dnPts);
      const areaPath = upPath + 'L' + X(pts.length - 1).toFixed(1) + ',' + (PADT + ih) +
                       'L' + PADL + ',' + (PADT + ih) + 'Z';

      const gridY = [0.25, 0.5, 0.75].map(k => PADT + ih * k);
      const gridLines = gridY.map(y =>
        '<line class="grid-line" x1="' + PADL + '" y1="' + y + '" x2="' + (W - PADR) + '" y2="' + y + '"/>').join('');
      const gridLbl = gridY.map((y, i) => {
        const v = maxV * (1 - [0.25, 0.5, 0.75][i]);
        return '<text class="axis-label" x="' + (PADL - 8) + '" y="' + (y + 3) + '" text-anchor="end">' + this.fmtAxis(v) + '</text>';
      }).join('');
      let xLbl = '';
      {
        const n = Math.min(5, pts.length);
        const step = Math.max(1, Math.floor((pts.length - 1) / Math.max(1, n - 1)));
        let lastLab = -999;
        pts.forEach((p, i) => {
          const isLast = i === pts.length - 1;
          if ((i % step === 0 && (!isLast || i - lastLab >= Math.ceil(step / 2))) || (isLast && i - lastLab >= Math.ceil(step / 2))) {
            lastLab = i;
            const d = new Date(p.t);
            const lab = this.trafficRange >= 168
              ? (d.getMonth() + 1) + '/' + d.getDate()
              : String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
            xLbl += '<text class="axis-label" x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle">' + lab + '</text>';
          }
        });
      }

      const last = pts[pts.length - 1];
      const lastDot = '<circle class="chdot chdot-down" cx="' + X(pts.length - 1) + '" cy="' + Y(last.down).toFixed(1) + '"/>' +
                      '<circle class="chdot chdot-up" cx="' + X(pts.length - 1) + '" cy="' + Y(last.up).toFixed(1) + '"/>';

      wrap.innerHTML =
        '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="节点流量折线图">' +
          gridLines + gridLbl + xLbl +
          '<path class="t-fill" d="' + areaPath + '"/>' +
          '<path class="tline t-down draw" style="--len:' + Math.ceil(W * 2.2) + '" d="' + dnPath + '"/>' +
          '<path class="tline t-up draw" style="--len:' + Math.ceil(W * 2.2) + '" d="' + upPath + '"/>' +
          lastDot +
          '<rect class="hover-catch" x="' + PADL + '" y="0" width="' + iw + '" height="' + H + '" fill="transparent"/>' +
        '</svg>' +
        '<div class="traffic-hover" id="trafficHover" hidden>' +
          '<div class="traffic-hover__t mono"></div>' +
          '<div class="traffic-hover__r"><i class="lg-line lg-up"></i><span class="hv-up mono"></span></div>' +
          '<div class="traffic-hover__r"><i class="lg-line lg-down"></i><span class="hv-down mono"></span></div>' +
        '</div>';

      // 悬停提示：找最近采样点
      const svg = wrap.querySelector('svg');
      const hover = document.getElementById('trafficHover');
      const catchArea = wrap.querySelector('.hover-catch');
      if (svg && hover && catchArea) {
        catchArea.addEventListener('mousemove', (ev) => {
          const rect = svg.getBoundingClientRect();
          const scale = rect.width / W;
          const mx = (ev.clientX - rect.left) / scale;
          let best = 0, bestD = Infinity;
          pts.forEach((p, i) => {
            const d = Math.abs(X(i) - mx);
            if (d < bestD) { bestD = d; best = i; }
          });
          const p = pts[best];
          const d = new Date(p.t);
          hover.querySelector('.traffic-hover__t').textContent =
            String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
          hover.querySelector('.hv-up').textContent = this.fmtSpeed(p.up);
          hover.querySelector('.hv-down').textContent = this.fmtSpeed(p.down);
          hover.hidden = false;
          const px = X(best) * scale;
          const flip = px > rect.width - 140;
          hover.style.left = (px + (flip ? -12 : 12)) + 'px';
          hover.style.top = '10px';
          hover.style.transform = 'translateX(' + (flip ? '-100%' : '0') + ')';
          svg.querySelectorAll('.chdot.hover').forEach(c => c.remove());
          svg.insertAdjacentHTML('beforeend',
            '<circle class="chdot hover chdot-down" cx="' + X(best).toFixed(1) + '" cy="' + Y(p.down).toFixed(1) + '"/>' +
            '<circle class="chdot hover chdot-up" cx="' + X(best).toFixed(1) + '" cy="' + Y(p.up).toFixed(1) + '"/>');
        });
        catchArea.addEventListener('mouseleave', () => {
          hover.hidden = true;
          svg.querySelectorAll('.chdot.hover').forEach(c => c.remove());
        });
      }

      setSummary(last);
    } catch (e) {
      wrap.innerHTML = '<div class="empty-state"><div class="empty-text">加载流量数据失败</div></div>';
    }
  },

  // —— FRPS 控制 ——
  async loadAdminCertificate() {
    const el = document.getElementById('adminCertCard');
    if (!el) return;
    try {
      const c = await this.api('GET', '/api/admin/certificate');
      if (!c.found) {
        el.innerHTML = '<h3>HTTPS 证书</h3><p class="card-sub">' +
          this.escapeHtml(c.message || '未找到证书文件，可设置 CLOUDFRP_CERT_PATH') + '</p>';
        return;
      }
      if (c.error) {
        el.innerHTML = '<h3>HTTPS 证书</h3><p class="card-sub">证书读取失败：' +
          this.escapeHtml(c.error) + '</p>';
        return;
      }
      const rows = [
        ['域名', c.domain || '-'],
        ['提供商', c.issuer || '-'],
        ['签发时间', String(c.not_before || '-')],
        ['到期时间', String(c.not_after || '-')],
        ['剩余天数', c.days_left != null ? (c.days_left + ' 天' + (c.expired ? '（已过期）' : '')) : '-'],
        ['私钥', c.has_private_key ? '已检测到' : '未找到（启用 HTTPS 需要私钥）'],
        ['文件', c.path || '-'],
      ];
      el.innerHTML = '<h3>HTTPS 证书</h3>' +
        '<div class="table-wrap"><table><tbody>' +
        rows.map(r => '<tr><td class="cell-sub" style="width:120px;">' + r[0] +
          '</td><td class="mono">' + this.escapeHtml(r[1]) + '</td></tr>').join('') +
        '</tbody></table></div>';
    } catch (e) {
      el.innerHTML = '<h3>HTTPS 证书</h3><p class="card-sub">加载证书信息失败</p>';
    }
  },

  async loadAdminFRPS() {
    const card = document.getElementById('adminFRPSCard');
    let srv;
    try {
      srv = await this.api('GET', '/api/server/status');
    } catch (e) {
      card.innerHTML = '<div class="empty-state"><div class="empty-text">加载 FRPS 状态失败</div></div>';
      return;
    }
    const running = srv.running === true;
    card.innerHTML =
      '<div class="frps-row">' +
        '<div class="frps-state">' +
          '<span class="dot ' + (running ? 'dot-success' : 'dot-error') + '"></span>' +
          '<div><div class="frps-state__t">' + (running ? 'frps 运行中' : 'frps 已停止') + '</div>' +
          '<div class="frps-state__s mono">监听端口 ' + this.escapeHtml(String(srv.port ?? 7000)) + ' · frpc 连接本机该端口</div></div>' +
        '</div>' +
        '<div class="btn-group">' +
          '<button class="btn btn-secondary btn-sm" id="frpsStopBtn"' + (running ? '' : ' disabled') + '>停止</button>' +
          '<button class="btn btn-primary btn-sm" id="frpsStartBtn"' + (running ? ' disabled' : '') + '>启动</button>' +
        '</div>' +
      '</div>';
    document.getElementById('frpsStartBtn').addEventListener('click', () => this.frpsToggle('start'));
    document.getElementById('frpsStopBtn').addEventListener('click', () => this.frpsToggle('stop'));
  },

  async frpsToggle(action) {
    try {
      const res = await this.api('POST', '/api/frps/' + action);
      this.showToast(res.message || (action === 'start' ? 'frps 已启动' : 'frps 已停止'), res.success === false ? 'warning' : 'success');
      this.loadAdminFRPS();
      this.loadDashboard();
    } catch (e) { /* 已提示 */ }
  },
};

// ===== 初始化 =====
document.addEventListener('DOMContentLoaded', () => {
  // 签到弹窗初始模板（供 closeCheckin 复原）
  const body = document.getElementById('checkinModalBody');
  if (body) appState._checkinTpl = body.innerHTML;
  appState.init();
});
