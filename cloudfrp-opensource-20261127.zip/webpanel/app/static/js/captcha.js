/* CloudFRP 自研图片验证码（点击 3 个字符） */
(function () {
  'use strict';

  var STYLE_ID = 'cf-captcha-style';
  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = `
      .cf-cap-overlay{position:fixed;inset:0;z-index:9999;background:rgba(4,20,24,.58);
        display:grid;place-items:center;padding:20px;}
      .cf-cap-box{width:min(360px,100%);background:#fff;border:1px solid #d8e2df;border-radius:14px;
        padding:20px;box-shadow:0 24px 60px -28px rgba(4,30,34,.45);
        font-family:"Reddit Sans",system-ui,-apple-system,"Microsoft YaHei UI",sans-serif;color:#0b3a40;}
      .cf-cap-title{font-size:17px;font-weight:600;letter-spacing:-.01em;line-height:1.35;margin:0 0 6px;}
      .cf-cap-hint{font-size:13px;color:#4c7078;margin:0 0 12px;line-height:1.7;}
      .cf-cap-svg{display:block;width:100%;height:auto;border-radius:9px;background:#eef3f1;
        user-select:none;touch-action:manipulation;}
      .cf-cap-char text{transition:fill .12s ease, opacity .12s ease;}
      .cf-cap-char.is-picked text{fill:#2f8f88;}
      .cf-cap-char.is-picked{opacity:1;}
      .cf-cap-msg{min-height:18px;font-size:12.5px;color:#c0483f;margin-top:8px;}
      .cf-cap-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:12px;}
      .cf-cap-btn{height:34px;padding:0 16px;border-radius:8px;border:1px solid #cfdcda;background:#fff;
        color:#0b3a40;font-size:13.5px;font-weight:500;cursor:pointer;}
      .cf-cap-btn:hover{border-color:#8fb4b2;}
      .cf-cap-btn.primary{background:#2f8f88;border-color:#2f8f88;color:#fff;}
      .cf-cap-btn.primary:disabled{opacity:.45;cursor:not-allowed;}
      .cf-cap-btn.ghost{border-color:transparent;color:#4c7078;}
    `;
    document.head.appendChild(st);
  }

  function open(opts) {
    opts = opts || {};
    ensureStyle();
    var overlay = document.createElement('div');
    overlay.className = 'cf-cap-overlay';
    overlay.innerHTML =
      '<div class="cf-cap-box" role="dialog" aria-modal="true" aria-label="CloudFRP 安全验证">' +
        '<h3 class="cf-cap-title">CloudFRP 安全验证</h3>' +
        '<p class="cf-cap-hint">加载中...</p>' +
        '<div class="cf-cap-svg-wrap"></div>' +
        '<div class="cf-cap-msg"></div>' +
        '<div class="cf-cap-actions">' +
          '<button type="button" class="cf-cap-btn ghost" data-act="cancel">取消</button>' +
          '<button type="button" class="cf-cap-btn" data-act="refresh">换一张</button>' +
          '<button type="button" class="cf-cap-btn primary" data-act="ok" disabled>确定</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    var hintEl = overlay.querySelector('.cf-cap-hint');
    var wrap = overlay.querySelector('.cf-cap-svg-wrap');
    var msgEl = overlay.querySelector('.cf-cap-msg');
    var okBtn = overlay.querySelector('[data-act="ok"]');
    var picks = [];
    var captchaId = '';

    function close() {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
    }
    function cancel() { close(); if (opts.onCancel) opts.onCancel(); }
    function onKey(e) { if (e.key === 'Escape') cancel(); }
    document.addEventListener('keydown', onKey);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) cancel(); });
    overlay.querySelector('[data-act="cancel"]').addEventListener('click', cancel);

    function renderPicked() {
      wrap.querySelectorAll('.cf-cap-char').forEach(function (g) {
        var i = Number(g.getAttribute('data-i'));
        g.classList.toggle('is-picked', picks.indexOf(i) !== -1);
      });
      okBtn.disabled = picks.length !== 3;
      msgEl.textContent = picks.length ? '已选 ' + picks.length + ' / 3' : '';
    }

    function bindChars() {
      wrap.querySelectorAll('.cf-cap-char').forEach(function (g) {
        g.addEventListener('click', function () {
          var i = Number(g.getAttribute('data-i'));
          var pos = picks.indexOf(i);
          if (pos === -1) {
            if (picks.length >= 3) return;
            picks.push(i);
          } else {
            picks.splice(pos, 1);
          }
          renderPicked();
        });
      });
    }

    function load() {
      picks = [];
      okBtn.disabled = true;
      msgEl.textContent = '';
      hintEl.textContent = '加载中...';
      wrap.innerHTML = '';
      fetch('/api/captcha/new', { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          captchaId = d.id;
          hintEl.textContent = d.hint || '请依次点击图中的 3 个字符';
          wrap.innerHTML = d.svg;
          bindChars();
        })
        .catch(function () { hintEl.textContent = '验证码加载失败，请点「换一张」'; });
    }

    overlay.querySelector('[data-act="refresh"]').addEventListener('click', load);
    okBtn.addEventListener('click', function () {
      if (picks.length !== 3) return;
      okBtn.disabled = true;
      okBtn.textContent = '验证中...';
      fetch('/api/captcha/verify', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: captchaId, picks: picks }),
      })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          if (res.ok && res.d.success) {
            var id = captchaId;
            close();
            if (opts.onSuccess) opts.onSuccess(id);
          } else {
            msgEl.textContent = (res.d && res.d.message) || '验证失败，请重试';
            okBtn.textContent = '确定';
            load();
          }
        })
        .catch(function () {
          msgEl.textContent = '网络错误，请重试';
          okBtn.textContent = '确定';
        });
    });

    load();
  }

  window.CFCaptcha = { open: open };
})();
