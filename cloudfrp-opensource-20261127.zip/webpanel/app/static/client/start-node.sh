#!/usr/bin/env bash
# =============================================================================
#  CloudFRP 捐赠节点启动脚本（Linux / Debian / Ubuntu）
#
#  用法：
#    ./start-node.sh --host 203.0.113.10 --panel http://面板地址:3592 [--port 7000] [--name hz01]
#    ./start-node.sh --background --host ... --panel ...     # 后台运行（node.log）
#
#  首次运行会自动安装 python3-requests / python3-psutil。
#  需要这台服务器上已启动 frps，并放行 --port（默认 7000）。
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")"

PY="python3"
command -v "$PY" >/dev/null 2>&1 || PY="python"

log() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }

if ! $PY -c "import requests, psutil" >/dev/null 2>&1; then
  log "安装依赖 python3-requests python3-psutil ..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update -qq && sudo apt-get install -y python3-requests python3-psutil
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y python3-requests python3-psutil
  elif command -v yum >/dev/null 2>&1; then
    sudo yum install -y python3-requests python3-psutil
  else
    $PY -m pip install --user requests psutil
  fi
fi

if [[ "${1:-}" == "--background" ]]; then
  shift
  log "后台运行（日志：node.log）"
  nohup $PY node_client.py "$@" > node.log 2>&1 &
  echo $! > node.pid
  log "pid $(cat node.pid)；停止：kill \$(cat node.pid)"
  exit 0
fi

exec $PY node_client.py "$@"
