#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CloudFRP 捐赠节点客户端（面板生成的一键安装脚本会内嵌本文件）

职责：在捐赠服务器上运行/复用 frps，向 CloudFRP 面板注册并每 10 秒上报心跳。

设计要点：
  - 仅依赖 Python 标准库（urllib）发送 HTTP，psutil 为可选依赖；
  - 从环境变量读取配置（systemd EnvironmentFile），FRP Token 不出现在命令行；
  - 自动持久化 node_id / node_token，重复运行/重启不会重复注册；
  - 注册与心跳均带指数退避重试；401/403/404/409/429 给出可操作提示；
  - 托管模式启动 frps 时写入 TOML 配置；--no-frps 时只监控已运行的 frps。
  - 默认转入后台静默运行（--foreground 可前台调试；systemd 下自动前台交给 journald）；
    --stop / --status 管理后台实例。

环境变量（均有对应命令行参数）：
  CLOUDFRP_PANEL / CLOUDFRP_HOST / CLOUDFRP_PORT / CLOUDFRP_NAME
  CLOUDFRP_TOKEN / CLOUDFRP_INTERVAL / CLOUDFRP_MANAGE_FRPS
  CLOUDFRP_STATE_DIR / CLOUDFRP_CONFIG / CLOUDFRP_DONATED_BY / CLOUDFRP_LOG
"""

import argparse
import base64
import json
import os
import platform
import re
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

try:  # psutil 可选：缺失时回退到 /proc 与 os.getloadavg
    import psutil  # type: ignore
except Exception:  # noqa: BLE001 - 任何导入错误都不应导致客户端崩溃
    psutil = None

# ── 常量 ──────────────────────────────────────────────
DEFAULT_INTERVAL = 10            # 心跳间隔(秒)
DEFAULT_PORT = 7001              # FRP 服务端口
MAX_RETRIES = 5                  # 网络请求最大尝试次数
RETRY_BASE_DELAY = 2             # 重试基础延迟(秒)
RETRY_MAX_DELAY = 60             # 重试最大延迟(秒)
REQUEST_TIMEOUT = 15             # HTTP 请求超时(秒)
CLIENT_VERSION = "1.1.0"
_USER_AGENT = "cloudfrp-node/" + CLIENT_VERSION
_ENV_PREFIX = "CLOUDFRP_"


def _env(name, default=None):
    return os.environ.get(_ENV_PREFIX + name, default)


def _env_int(name, default):
    try:
        return int(_env(name, default))
    except (TypeError, ValueError):
        return default


def _env_bool(name, default=False):
    raw = _env(name)
    if raw is None:
        return default
    return str(raw).strip().lower() not in ("0", "false", "no", "off", "")


def _mask(secret):
    """日志里只显示 token 的首尾，避免泄露。"""
    secret = str(secret or "")
    if len(secret) <= 6:
        return "***"
    return secret[:3] + "***" + secret[-2:]


def _default_state_dir():
    configured = _env("STATE_DIR")
    if configured:
        return configured
    if os.name == "posix":
        return "/var/lib/cloudfrp"
    return os.path.join(os.path.expanduser("~"), ".cloudfrp")


def _read_file(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def _write_secure(path, value):
    directory = os.path.dirname(path) or "."
    try:
        os.makedirs(directory, mode=0o700, exist_ok=True)
    except OSError:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(str(value) + "\n")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)


def _toml_escape(value):
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


class FRPNodeClient:
    """FRP 节点客户端 — 管理 FRPS 生命周期并向面板汇报"""

    def __init__(self, name, host, port, token, panel_url,
                 interval=DEFAULT_INTERVAL, node_id=None, node_token=None,
                 state_dir=None, config_path=None, donated_by=None,
                 insecure=False):
        self.name = name or ""
        self.host = host
        self.port = int(port)
        self.auth_token = token or ""
        self.panel_url = (panel_url or "").rstrip("/")
        self.interval = max(5, min(int(interval or DEFAULT_INTERVAL), 300))
        self.manage_frps = True          # --no-frps / CLOUDFRP_MANAGE_FRPS=0 时为 False
        self.state_dir = state_dir or _default_state_dir()
        self.config_path = config_path
        self.donated_by = donated_by
        self.insecure = bool(insecure)
        self.frps_process = None
        self._last_net_io = None
        self._last_stats = self._empty_stats()
        self._running = False
        self._auth_error_printed = False
        self._register_blocked_until = 0.0

        # 持久化身份：优先命令行，其次状态目录
        self.node_id = node_id or _read_file(os.path.join(self.state_dir, "node.id")) or None
        self.node_token = node_token or _read_file(os.path.join(self.state_dir, "node.token")) or None
        if not self.node_id or not self.node_token:
            # 只有 id 没有 token 无法完成更新认证，按新节点处理
            self.node_id = None
            self.node_token = None

        if psutil is not None:
            try:
                psutil.cpu_percent(interval=None)  # 预热，后续调用返回区间使用率
            except Exception:  # noqa: BLE001
                pass

    # ── 系统指标 ──────────────────────────────────────

    @staticmethod
    def _empty_stats():
        return {
            'cpu_usage': 0.0,
            'memory_usage': 0.0,
            'upload_speed': 0.0,
            'download_speed': 0.0,
            'total_upload': 0,
            'total_download': 0,
            'client_count': 0,
            'frps_healthy': False,
        }

    @staticmethod
    def _proc_mem_percent():
        try:
            values = {}
            with open("/proc/meminfo", "r", encoding="utf-8") as fh:
                for line in fh:
                    key, _, rest = line.partition(":")
                    values[key.strip()] = rest.strip()
            total = int(values["MemTotal"].split()[0])
            avail = int(values.get("MemAvailable", values["MemFree"]).split()[0])
            if total <= 0:
                return 0.0
            return max(0.0, min(100.0, (total - avail) * 100.0 / total))
        except Exception:  # noqa: BLE001
            return 0.0

    @staticmethod
    def _proc_net_bytes():
        try:
            sent = recv = 0
            with open("/proc/net/dev", "r", encoding="utf-8") as fh:
                for line in fh.readlines()[2:]:
                    iface, _, data = line.partition(":")
                    if iface.strip() == "lo":
                        continue
                    parts = data.split()
                    recv += int(parts[0])
                    sent += int(parts[8])
            return sent, recv
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _load_cpu_percent():
        try:
            load = os.getloadavg()[0]
            cores = os.cpu_count() or 1
            return max(0.0, min(100.0, load * 100.0 / cores))
        except (OSError, AttributeError):
            return 0.0

    def _frps_running(self):
        """判断系统里是否有 frps 进程（不依赖 psutil）。"""
        if psutil is not None:
            try:
                for proc in psutil.process_iter(['name']):
                    if (proc.info.get('name') or '').lower() in ('frps', 'frps.exe'):
                        return True
                return False
            except Exception:  # noqa: BLE001
                pass
        # /proc 回退（Linux）
        try:
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    with open("/proc/%s/comm" % pid, "r", encoding="utf-8") as fh:
                        if fh.read().strip() == "frps":
                            return True
                except OSError:
                    continue
        except OSError:
            pass
        return False

    def check_frps_health(self):
        """托管模式看子进程；复用模式（或 --once）扫描系统进程。"""
        if self.frps_process is not None:
            return self.frps_process.poll() is None
        return self._frps_running()

    def _collect_stats(self):
        try:
            if psutil is not None:
                cpu = psutil.cpu_percent(interval=None)
                mem = psutil.virtual_memory().percent
                net = psutil.net_io_counters()
                net_pair = (net.bytes_sent, net.bytes_recv)
            else:
                cpu = self._load_cpu_percent()
                mem = self._proc_mem_percent()
                net_pair = self._proc_net_bytes()

            stats = self._empty_stats()
            stats['cpu_usage'] = round(float(cpu or 0), 2)
            stats['memory_usage'] = round(float(mem or 0), 2)
            stats['frps_healthy'] = self.check_frps_health()

            if net_pair is not None:
                sent, recv = net_pair
                stats['total_upload'] = int(sent)
                stats['total_download'] = int(recv)
                if self._last_net_io is not None:
                    elapsed = self.interval if self.interval > 0 else 1
                    stats['upload_speed'] = max(0.0, (sent - self._last_net_io[0]) / elapsed)
                    stats['download_speed'] = max(0.0, (recv - self._last_net_io[1]) / elapsed)
                self._last_net_io = net_pair

            self._last_stats = stats
            return stats
        except Exception as exc:  # noqa: BLE001 - 采集失败不应中断心跳
            print("[!] 采集系统指标失败，沿用上一次数据: %s" % exc)
            return dict(self._last_stats)

    # ── HTTP（标准库，带重试） ────────────────────────

    def _http_json(self, method, url, payload=None, timeout=REQUEST_TIMEOUT):
        data = None
        headers = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        kwargs = {"timeout": timeout}
        if self.insecure and url.lower().startswith("https://"):
            kwargs["context"] = ssl._create_unverified_context()  # noqa: SLF001
        try:
            with urllib.request.urlopen(req, **kwargs) as resp:
                raw = resp.read()
                status = getattr(resp, "status", 200)
                headers_out = resp.headers
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            status = exc.code
            headers_out = exc.headers
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            text = raw[:200].decode("utf-8", "replace")
            body = {"error": text} if text else {}
        return status, body, headers_out

    @staticmethod
    def _retry_delay(attempt):
        return min(RETRY_BASE_DELAY * (2 ** attempt), RETRY_MAX_DELAY)

    def _request_with_retry(self, method, url, payload=None):
        """对连接错误、超时、5xx、429 做指数退避；4xx（除 429）立即返回。"""
        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                status, body, headers = self._http_json(method, url, payload)
            except (urllib.error.URLError, socket.timeout, OSError, ValueError) as exc:
                last_error = exc
                if attempt < MAX_RETRIES - 1:
                    delay = self._retry_delay(attempt)
                    print("[!] 无法连接面板 (%d/%d)，%ss 后重试: %s"
                          % (attempt + 1, MAX_RETRIES, delay, exc))
                    time.sleep(delay)
                continue

            if status == 429 or status >= 500:
                last_error = "HTTP %s" % status
                if attempt < MAX_RETRIES - 1:
                    retry_after = 0
                    try:
                        retry_after = int((headers or {}).get("Retry-After") or
                                          (body or {}).get("retry_after") or 0)
                    except (TypeError, ValueError):
                        retry_after = 0
                    delay = max(self._retry_delay(attempt), min(retry_after, RETRY_MAX_DELAY))
                    print("[!] 面板暂时不可用 (HTTP %s, %d/%d)，%ss 后重试"
                          % (status, attempt + 1, MAX_RETRIES, delay))
                    time.sleep(delay)
                continue
            return status, body or {}
        print("[✗] 请求失败，已重试 %d 次: %s" % (MAX_RETRIES, last_error))
        return 0, {"error": str(last_error or "network error")}

    # ── 状态持久化 ────────────────────────────────────

    def _state_path(self, filename):
        return os.path.join(self.state_dir, filename)

    def _save_state(self):
        try:
            if self.node_id:
                _write_secure(self._state_path("node.id"), self.node_id)
            if self.node_token:
                _write_secure(self._state_path("node.token"), self.node_token)
        except OSError as exc:
            print("[!] 无法保存节点身份到 %s: %s" % (self.state_dir, exc))

    def _clear_state(self):
        for filename in ("node.id", "node.token"):
            try:
                os.remove(self._state_path(filename))
            except OSError:
                pass

    # ── 面板通信 ──────────────────────────────────────

    def check_panel(self):
        """轻量健康检查，便于在日志里给出明确结论。"""
        status, body = self._request_with_retry("GET", self.panel_url + "/api/health")
        if status == 200 and body.get("ok") is True:
            print("[✓] 面板可达（version=%s）" % body.get("version", "unknown"))
            return True
        if status == 404:
            print("[!] 面板没有 /api/health（版本较旧），继续尝试注册")
            return True
        print("[!] 面板健康检查异常（HTTP %s），仍将尝试注册" % status)
        return False

    def _register_payload(self):
        payload = {
            'name': self.name,
            'host': self.host,
            'port': self.port,
            'auth_token': self.auth_token,
            'donated_by': self.donated_by or self.name,
        }
        if self.node_id:
            payload['node_id'] = self.node_id
        if self.node_token:
            payload['node_token'] = self.node_token
        return payload

    def register_node(self):
        """向面板注册/更新节点（携带已保存的 node_id + node_token 实现幂等）。"""
        status, data = self._request_with_retry(
            'POST', self.panel_url + "/api/nodes/register", self._register_payload())
        if status == 200 and data.get('success'):
            self.node_id = data.get('node_id') or self.node_id
            self.node_token = data.get('node_token') or self.node_token
            self._save_state()
            self._auth_error_printed = False
            msg = data.get('message') or ''
            print("[✓] 节点注册成功，Node ID: %s%s"
                  % (self.node_id, ("（%s）" % msg) if msg else ""))
            if data.get('approved') is False:
                print("    该节点尚待管理员在面板「节点管理」中审核，通过后才会被用户选用。")
            return True

        self._explain_register_failure(status, data)
        return False

    def _explain_register_failure(self, status, data):
        error = (data or {}).get('error') or (data or {}).get('message') or ''
        code = (data or {}).get('code') or ''
        if status == 429 or code == 'RATE_LIMITED':
            retry = (data or {}).get('retry_after')
            print("[!] 面板注册频率限制（HTTP 429）。%s"
                  % (("请 %s 秒后重试。" % retry) if retry else "请稍后重试。"))
            print("    这是面板的防滥用限制，不是节点故障；服务会自动重试。")
        elif status in (401, 403):
            print("[✗] 面板拒绝注册（HTTP %s）：%s" % (status, error or "unauthorized"))
            print("    请确认面板地址正确、未被防火墙/WAF 拦截，并使用最新安装脚本。")
        elif status == 409:
            print("[✗] 节点冲突（HTTP 409）：%s" % (error or "conflict"))
            print("    该 node_id 可能已被其他机器占用；请删除 %s 后重试。"
                  % self._state_path("node.id"))
        elif status == 400:
            print("[✗] 注册参数被拒绝：%s" % (error or "bad request"))
            if '已存在' in error:
                print("    面板上已有同 node_id 的节点，但本地 node_token 不匹配。")
                print("    请管理员在面板删除该节点，或清空 %s 后重启 cloudfrp-node。"
                      % self.state_dir)
        else:
            print("[✗] 节点注册失败（HTTP %s）：%s" % (status, error or "未知错误"))

    def _collect_proxies(self):
        """查询本机 frps 管理 API，返回 (proxy 名列表, 今日流量字典)。

        未配置管理 API / 查询失败 → (None, None)（面板不改状态、不记流量）；
        成功查询但没有 proxy → ([], {})。
        """
        port = _env_int("FRPS_ADMIN_PORT", 0)
        if port <= 0:
            return None, None
        user = _env("FRPS_ADMIN_USER") or ""
        pwd = _env("FRPS_ADMIN_PASS") or ""
        auth = base64.b64encode(("%s:%s" % (user, pwd)).encode("utf-8")).decode("ascii")
        headers = {"Authorization": "Basic " + auth, "User-Agent": _USER_AGENT}
        names = set()
        traffic = {}
        got_any = False
        for kind in ("tcp", "udp", "http", "https"):
            url = "http://127.0.0.1:%d/api/proxy/%s" % (port, kind)
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=3) as resp:
                    body = json.loads(resp.read().decode("utf-8", "replace") or "{}")
                got_any = True
            except Exception:  # noqa: BLE001 - 任一类型失败不影响其他类型
                continue
            for item in (body.get("proxies") or []):
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or "").strip()
                state = str(item.get("status") or "").strip().lower()
                if name and (not state or state in ("running", "online", "started")):
                    names.add(name)
                    try:
                        up = int(item.get("todayTrafficIn") or 0)
                    except (TypeError, ValueError):
                        up = 0
                    try:
                        down = int(item.get("todayTrafficOut") or 0)
                    except (TypeError, ValueError):
                        down = 0
                    traffic[name] = {"up": max(0, up), "down": max(0, down)}
        if not got_any:
            return None, None
        clean = []
        for name in sorted(names)[:500]:
            name = name[:100]
            if name and all(ord(ch) >= 32 and ord(ch) != 127 for ch in name):
                clean.append(name)
        return clean, traffic

    def send_heartbeat(self):
        """发送心跳；401 时给出一次性可操作提示并退避，避免刷屏。"""
        if not self.node_id or not self.node_token:
            if time.time() < self._register_blocked_until:
                return False
            return self.register_node()

        payload = {
            'node_token': self.node_token,
            'stats': self._collect_stats(),
        }
        proxies, traffic = self._collect_proxies()
        if proxies is not None:
            payload['running_proxies'] = proxies
        if traffic:
            payload['proxy_traffic'] = traffic
        status, data = self._request_with_retry(
            'POST', "%s/api/nodes/%s/heartbeat" % (self.panel_url, self.node_id), payload)

        if status == 200 and data.get('success'):
            self._auth_error_printed = False
            return True

        code = (data or {}).get('code') or ''
        error = (data or {}).get('error') or ''
        if status == 401 or code == 'INVALID_TOKEN':
            if not self._auth_error_printed:
                print("[✗] 节点认证令牌无效（HTTP 401）：%s" % (error or "invalid token"))
                print("    面板可能已删除该节点或重置了令牌。请管理员在面板「节点管理」")
                print("    删除该节点，然后清空 %s 下的 node.id / node.token 并重启服务。"
                      % self.state_dir)
                self._auth_error_printed = True
            self._register_blocked_until = time.time() + 300
            return False
        if status == 403:
            print("[✗] 心跳被面板拒绝（HTTP 403）：%s" % (error or "forbidden"))
            print("    请检查面板地址/反代规则，以及服务器时间是否准确。")
            return False
        if status == 404 or code == 'NODE_NOT_FOUND':
            print("[!] 面板上已不存在该节点，正在重新注册为新节点（需管理员重新审核）...")
            self.node_id = None
            self.node_token = None
            self._clear_state()
            return self.register_node()
        if status == 429:
            print("[!] 心跳触发面板频率限制（HTTP 429），稍后重试。")
            return False
        print("[!] 心跳失败（HTTP %s）：%s" % (status, error or "未知错误"))
        return False

    # ── FRPS 生命周期（托管模式） ────────────────────

    def _find_frps_binary(self):
        candidates = []
        found = shutil.which("frps")
        if found:
            candidates.append(found)
        candidates.extend([
            '/usr/local/bin/frps',
            os.path.join(os.getcwd(), 'frps'),
            os.path.join(os.getcwd(), 'frps.exe'),
            os.path.join(os.path.dirname(os.getcwd()), 'frps'),
            os.path.join(os.getcwd(), 'chmlfrp', 'frps'),
        ])
        for path in candidates:
            if path and os.path.isfile(path):
                return path
        return None

    def _resolve_config_path(self):
        if self.config_path:
            return self.config_path
        configured = _env("CONFIG")
        if configured:
            return configured
        if os.name == "posix" and os.path.isdir("/etc/cloudfrp"):
            return "/etc/cloudfrp/frps.toml"
        return os.path.join(os.getcwd(), "frps_node.toml")

    def create_frps_config(self):
        dashboard_port = 9000 + (self.port % 1000)
        content = (
            "# FRP Server Config - %s (generated by cloudfrp-node %s)\n"
            'bindAddr = "0.0.0.0"\n'
            "bindPort = %d\n"
            'auth.token = "%s"\n'
            "transport.maxPoolCount = 1000\n"
            "transport.tcpMux = true\n"
            'log.level = "info"\n'
            "log.maxDays = 3\n\n"
            'webServer.addr = "127.0.0.1"\n'
            "webServer.port = %d\n"
            'webServer.user = "admin"\n'
            'webServer.password = "%s"\n'
        ) % (self.name, CLIENT_VERSION, self.port,
             _toml_escape(self.auth_token), dashboard_port,
             _toml_escape(uuid.uuid4().hex[:16]))
        path = self._resolve_config_path()
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, mode=0o755, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    def start_frps(self):
        frps_path = self._find_frps_binary()
        if not frps_path:
            print("[✗] 找不到 frps 可执行文件。请安装到 /usr/local/bin/frps，"
                  "或使用一键脚本自动下载。")
            return False
        config_path = self.create_frps_config()
        try:
            # 继承 stdout/stderr（systemd 下进入 journal）；不要用 PIPE，
            # 否则长期运行且无人读取时管道写满会阻塞 frps。
            self.frps_process = subprocess.Popen(
                [frps_path, '-c', config_path],
            )
            time.sleep(2)
            if self.frps_process.poll() is None:
                print("[✓] FRPS 已启动，端口: %d，配置: %s" % (self.port, config_path))
                return True
            print("[✗] FRPS 启动失败（退出码 %s），请查看上方日志或 journal"
                  % self.frps_process.returncode)
            return False
        except Exception as exc:  # noqa: BLE001
            print("[✗] 启动 FRPS 异常: %s" % exc)
            return False

    def stop_frps(self):
        if self.frps_process and self.frps_process.poll() is None:
            try:
                self.frps_process.terminate()
                self.frps_process.wait(timeout=5)
                print("[✓] FRPS 已停止")
            except subprocess.TimeoutExpired:
                self.frps_process.kill()
                print("[!] FRPS 被强制终止")
            except Exception as exc:  # noqa: BLE001
                print("[✗] 停止 FRPS 异常: %s" % exc)

    # ── 主循环 ──────────────────────────────────────

    def _print_banner(self):
        print("=" * 60)
        print("  CloudFRP 节点客户端 v%s" % CLIENT_VERSION)
        print("  节点名称: %s" % (self.name or "(自动)"))
        print("  节点地址: %s:%d" % (self.host, self.port))
        print("  面板地址: %s" % self.panel_url)
        print("  心跳间隔: %ss" % self.interval)
        print("  FRP Token: %s" % _mask(self.auth_token))
        print("  运行模式: %s" % ("托管 frps" if self.manage_frps else "复用已有 frps"))
        print("=" * 60)

    def run(self):
        self._print_banner()
        self.check_panel()

        if self.manage_frps:
            if not self.start_frps():
                return 1
        elif self.check_frps_health():
            print("[✓] 检测到已运行的 frps（--no-frps）")
        else:
            print("[!] 警告：未检测到已运行的 frps，隧道将无法转发流量")

        if not self.register_node():
            print("[✗] 节点注册失败，停止 FRPS...")
            self.stop_frps()
            return 1

        self._running = True
        failures = 0

        def _on_term(*_):
            self._running = False

        try:
            signal.signal(signal.SIGTERM, _on_term)
            signal.signal(signal.SIGINT, _on_term)
        except (ValueError, OSError):
            pass
        try:
            while self._running:
                ok = self.send_heartbeat()
                failures = 0 if ok else failures + 1
                stats = self._last_stats
                print("[%s] %s CPU:%.0f%% MEM:%.0f%% ↑%.0fKB/s ↓%.0fKB/s FRPS:%s%s"
                      % (time.strftime('%H:%M:%S'), "✓" if ok else "✗",
                         stats.get('cpu_usage', 0), stats.get('memory_usage', 0),
                         stats.get('upload_speed', 0) / 1024,
                         stats.get('download_speed', 0) / 1024,
                         "OK" if stats.get('frps_healthy') else "DOWN",
                         (" (连续失败:%d)" % failures) if failures else ""))
                if failures and failures % 5 == 0 and time.time() >= self._register_blocked_until:
                    print("[!] 连续心跳失败过多，尝试重新注册节点...")
                    if self.register_node():
                        failures = 0
                time.sleep(self.interval)
        except KeyboardInterrupt:
            print("\n[!] 收到中断信号，正在退出...")
        finally:
            self._running = False
            self.stop_frps()
            _cleanup_pid_file()
        return 0

    def run_once(self):
        """注册 + 发送一次心跳后退出（安装脚本用于验证面板连通性）。"""
        self._print_banner()
        self.check_panel()
        if not self.register_node():
            return 1
        ok = self.send_heartbeat()
        print("[%s] 单次心跳%s" % ("✓" if ok else "✗", "成功" if ok else "失败"))
        return 0 if ok else 1


# ── 后台运行（--daemon / --stop / --status） ────────
_ORIG_STREAMS = []


def _pid_path():
    return os.path.join(_default_state_dir(), "cloudfrp-node.pid")


def _default_log_path():
    return _env("LOG") or os.path.join(_default_state_dir(), "cloudfrp-node.log")


def _read_pid():
    path = _pid_path()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            pid = int((fh.read() or "0").strip())
    except (OSError, ValueError):
        pid = 0
    if pid <= 0:
        return None
    try:
        os.kill(pid, 0)
    except OSError:
        try:
            os.remove(path)
        except OSError:
            pass
        return None
    return pid


def _scan_pid():
    """pid 文件丢失时，从 /proc 里找正在运行的 node_client。"""
    if os.name != "posix" or not os.path.isdir("/proc"):
        return None
    me = os.getpid()
    for entry in os.listdir("/proc"):
        if not entry.isdigit() or int(entry) == me:
            continue
        try:
            with open("/proc/%s/cmdline" % entry, "rb") as fh:
                cmd = fh.read().replace(b"\x00", b" ").decode("utf-8", "ignore")
        except OSError:
            continue
        if "node_client.py" in cmd:
            return int(entry)
    return None


def _daemonize(log_path, pid_path):
    """双 fork + setsid，脱离终端；stdout/stderr 写入日志文件。"""
    if os.name != "posix":
        print("[!] 当前系统不支持后台模式，继续前台运行")
        return False
    if os.fork() > 0:
        os._exit(0)
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    os.chdir("/")
    os.umask(0o077)

    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
    except OSError:
        pass

    sys.stdout.flush()
    sys.stderr.flush()
    _ORIG_STREAMS.extend((sys.stdout, sys.stderr))
    devnull = os.open(os.devnull, os.O_RDONLY)
    os.dup2(devnull, 0)
    try:
        log_fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    except OSError:
        log_fd = os.open(os.devnull, os.O_WRONLY)
    os.dup2(log_fd, 1)
    os.dup2(log_fd, 2)
    os.close(devnull)
    try:
        os.close(log_fd)
    except OSError:
        pass

    sys.stdout = os.fdopen(1, "w", buffering=1, encoding="utf-8", errors="replace")
    sys.stderr = os.fdopen(2, "w", buffering=1, encoding="utf-8", errors="replace")

    try:
        os.makedirs(os.path.dirname(pid_path), exist_ok=True)
        with open(pid_path, "w", encoding="utf-8") as fh:
            fh.write(str(os.getpid()))
    except OSError as exc:  # noqa: BLE001
        print("[!] 无法写入 pid 文件 %s: %s" % (pid_path, exc))
    return True


def _cleanup_pid_file():
    path = _pid_path()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            if (fh.read() or "").strip() != str(os.getpid()):
                return
        os.remove(path)
    except OSError:
        pass


def _stop_daemon():
    pid = _read_pid() or _scan_pid()
    if not pid:
        print("CloudFRP 节点客户端未在运行")
        return 1
    print("正在停止 CloudFRP 节点客户端 (PID %d) ..." % pid)
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError as exc:
        print("[✗] 无法停止 PID %d: %s" % (pid, exc))
        return 1
    for _ in range(30):
        time.sleep(0.2)
        try:
            os.kill(pid, 0)
        except OSError:
            break
    else:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    try:
        os.remove(_pid_path())
    except OSError:
        pass
    print("已停止")
    return 0


def _status_daemon():
    pid = _read_pid() or _scan_pid()
    if pid:
        print("运行中 (PID %d)" % pid)
        print("日志: %s" % _default_log_path())
        return 0
    print("未在运行")
    print("日志: %s" % _default_log_path())
    return 1


# ── CLI ─────────────────────────────────────────────
def _resolve_host(cli_host):
    host = (cli_host or _env("HOST") or "").strip()
    if host:
        return host
    print("[!] 未提供节点地址（--host / CLOUDFRP_HOST），尝试自动探测公网 IP...")
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
            with urllib.request.urlopen(req, timeout=8) as resp:
                value = resp.read().decode("utf-8", "replace").strip()
            if re.match(r"^[0-9A-Fa-f:.]+$", value):
                print("[✓] 自动探测到节点地址: %s" % value)
                return value
        except Exception:  # noqa: BLE001
            continue
    return ""


def main(argv=None):
    parser = argparse.ArgumentParser(description='CloudFRP 捐赠节点客户端')
    parser.add_argument('--name', default=_env("NAME"), help='节点名称（默认自动生成）')
    parser.add_argument('--host', default=_env("HOST"), help='节点公网 IP（也可用 CLOUDFRP_HOST）')
    parser.add_argument('--port', type=int, default=_env_int("PORT", DEFAULT_PORT),
                        help='FRP 服务端口（默认 7001）')
    parser.add_argument('--token', default=_env("TOKEN"), help='FRP 认证令牌')
    parser.add_argument('--panel', default=_env("PANEL"),
                        help='面板地址，例如 http://panel.example.com:3592')
    parser.add_argument('--interval', type=int, default=_env_int("INTERVAL", DEFAULT_INTERVAL),
                        help='心跳间隔秒数（默认 10）')
    parser.add_argument('--no-frps', action='store_true',
                        default=not _env_bool("MANAGE_FRPS", True),
                        help='不启动 frps，复用系统里已运行的 frps')
    parser.add_argument('--state-dir', default=_default_state_dir(),
                        help='保存 node.id / node.token 的目录')
    parser.add_argument('--config', default=_env("CONFIG"),
                        help='托管模式下 frps TOML 配置路径')
    parser.add_argument('--node-id', default=_env("NODE_ID"), help='已有节点 ID（一般自动读取）')
    parser.add_argument('--node-token', default=_env("NODE_TOKEN"),
                        help='已有节点令牌（一般自动读取）')
    parser.add_argument('--donated-by', default=_env("DONATED_BY"),
                        help='捐赠者展示名称（默认使用节点名称）')
    parser.add_argument('--insecure', action='store_true',
                        default=_env_bool("INSECURE", False),
                        help='HTTPS 面板使用自签名证书时跳过证书校验')
    parser.add_argument('--once', action='store_true',
                        help='注册并发送一次心跳后退出（用于安装验证）')
    parser.add_argument('--daemon', action='store_true',
                        help='转入后台静默运行（默认行为；systemd/--once 除外）')
    parser.add_argument('--foreground', action='store_true',
                        help='前台运行，日志直接输出到终端')
    parser.add_argument('--log-file', default=_env("LOG"),
                        help='后台日志路径（默认 /var/lib/cloudfrp/cloudfrp-node.log）')
    parser.add_argument('--stop', action='store_true', help='停止后台运行的实例')
    parser.add_argument('--status', action='store_true', help='查看后台实例状态')
    parser.add_argument('--version', action='version',
                        version='cloudfrp-node ' + CLIENT_VERSION)

    args = parser.parse_args(argv)

    if args.stop:
        return _stop_daemon()
    if args.status:
        return _status_daemon()

    panel = (args.panel or "").strip().rstrip("/")
    if not panel or not re.match(r"^https?://[^\s]+$", panel):
        print("[✗] 面板地址无效，请用 --panel http(s)://host[:port] 指定")
        return 2

    host = _resolve_host(args.host)
    if not host:
        print("[✗] 无法确定节点公网地址，请用 --host 指定")
        return 2

    name = (args.name or "").strip()
    if not name:
        print("未指定节点名称，正在自动生成...")
        name = "node-" + (host.replace(".", "-").replace(":", "-"))[:40]
        print("自动生成节点名称: %s" % name)

    token = args.token or ""
    if not token:
        # 兼容手动运行：旧版会自动生成 Token；一键脚本始终注入面板 Token
        token = uuid.uuid4().hex[:16]
        print("[!] 未提供 FRP Token，已自动生成：%s" % _mask(token))
        print("    若复用已有 frps，请确认它与面板使用的 auth.token 一致。")

    client = FRPNodeClient(
        name=name,
        host=host,
        port=args.port,
        token=token,
        panel_url=panel,
        interval=args.interval,
        node_id=args.node_id,
        node_token=args.node_token,
        state_dir=args.state_dir,
        config_path=args.config,
        donated_by=args.donated_by,
        insecure=args.insecure,
    )
    client.manage_frps = not args.no_frps
    if args.once:
        return client.run_once()

    # 默认后台静默：systemd（INVOCATION_ID）下保持前台交给 journald；
    # --foreground 前台调试；--daemon 强制后台。
    under_systemd = bool(os.environ.get("INVOCATION_ID"))
    want_daemon = args.daemon or not (args.foreground or under_systemd)
    if want_daemon:
        existing = _read_pid() or _scan_pid()
        if existing and existing != os.getpid():
            print("[!] 已有实例在运行 (PID %d)，请先执行 --stop" % existing)
            return 1
        log_path = args.log_file or _default_log_path()
        print("已转入后台运行。日志: %s" % log_path)
        print("查看状态: %s --status    前台调试: %s --foreground"
              % (sys.argv[0], sys.argv[0]))
        if not _daemonize(log_path, _pid_path()):
            print("[!] 后台模式不可用，改为前台运行")
    return client.run()


if __name__ == '__main__':
    sys.exit(main())
