#!/usr/bin/env bash
# CloudFRP 启动器（Linux / macOS）
set -euo pipefail
cd "$(dirname "$0")"

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [[ -z "$PY" ]]; then
  echo "未检测到 Python3，请先安装：apt install -y python3 python3-tk python3-venv" >&2
  exit 1
fi

# 图形界面依赖（缺了就自动装到用户目录）
if ! "$PY" -c "import customtkinter" >/dev/null 2>&1; then
  echo "正在安装图形界面依赖 customtkinter ..."
  "$PY" -m pip install --user --quiet customtkinter || \
    echo "依赖安装失败：可继续使用命令行模式（--panel --user --password --tunnel）" >&2
fi

exec "$PY" cloudfrp-client.py "$@"
