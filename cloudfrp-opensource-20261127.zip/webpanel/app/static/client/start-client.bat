@echo off
chcp 65001 >nul
cd /d "%~dp0"
where pythonw >nul 2>nul
if %errorlevel%==0 (
  start "" pythonw "cloudfrp-client.py"
  exit /b 0
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" python "cloudfrp-client.py"
  exit /b 0
)
echo.
echo 未检测到 Python。请先安装 Python 3.9+（安装时勾选 Add to PATH），
echo 或使用打包好的 CloudFRP-Client.exe。
echo.
pause
