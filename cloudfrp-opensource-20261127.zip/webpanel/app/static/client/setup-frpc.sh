#!/usr/bin/env bash
# =============================================================================
#  CloudFRP 面板本机 frpc 一键安装
#
#  在面板服务器上运行（读取 frp_panel.db 自动生成配置）：
#
#    sudo bash setup-frpc.sh                 # 安装所有隧道（同一 frps 时）
#    sudo bash setup-frpc.sh --tunnel 1      # 只安装指定隧道（ID 或名称）
#    sudo bash setup-frpc.sh --print-config  # 只打印配置，不安装
#    sudo bash setup-frpc.sh --list          # 列出隧道
#    sudo bash setup-frpc.sh --uninstall     # 卸载 frpc 服务
#
#  也可以在面板更新后直接：
#    curl -fsSL http://<面板地址>:3592/static/client/setup-frpc.sh | sudo bash
#
#  说明：frpc 只负责把「本机服务」连到 frps；每个隧道对应一个 [[proxies]]。
#        不同 frps 上的隧道需要用 --tunnel 分开安装（一个 frpc 只连一个 frps）。
# =============================================================================
set -euo pipefail

PANEL_DIR="${PANEL_DIR:-}"
TUNNEL_SEL=""
UNINSTALL=0
PRINT_ONLY=0
LIST_ONLY=0
FRPC_VERSION="${FRPC_VERSION:-0.61.0}"

log()  { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[✗]\033[0m %s\n' "$*" >&2; exit 1; }

usage() { sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel-dir) PANEL_DIR="$2"; shift 2 ;;
    --tunnel) TUNNEL_SEL="$2"; shift 2 ;;
    --uninstall) UNINSTALL=1; shift ;;
    --print-config) PRINT_ONLY=1; shift ;;
    --list) LIST_ONLY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数：$1（--help 查看用法）" ;;
  esac
done

# ---------- 定位面板目录 ----------
if [[ -z "$PANEL_DIR" ]]; then
  SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd || pwd)"
  for cand in \
      "$SELF_DIR/../../../.." \
      "$SELF_DIR/../.." \
      "/sas-ubuntu3/网站/cloudfrp" \
      "/opt/cloudfrp" \
      "$(pwd)"; do
    if [[ -f "$cand/webpanel/server.py" ]]; then PANEL_DIR="$cand/webpanel"; break; fi
    if [[ -f "$cand/server.py" ]]; then PANEL_DIR="$cand"; break; fi
  done
fi
[[ -n "$PANEL_DIR" && -f "$PANEL_DIR/server.py" ]] || die "找不到 webpanel 目录，请用 --panel-dir 指定"
PANEL_DIR="$(cd "$PANEL_DIR" && pwd)"
[[ -f "$PANEL_DIR/frp_panel.db" ]] || die "找不到数据库：$PANEL_DIR/frp_panel.db"

PY="$(command -v python3 || command -v python || true)"
VENV_PY="$(dirname "$PANEL_DIR")/.venv/bin/python"
if [[ -x "$VENV_PY" ]]; then PY="$VENV_PY"; fi
[[ -n "$PY" ]] || die "需要 python3"

# ---------- 卸载 ----------
if [[ "$UNINSTALL" -eq 1 ]]; then
  log "停止并移除 frpc 服务"
  if [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now frpc 2>/dev/null || true
  else
    pkill -f '/usr/local/bin/frpc' 2>/dev/null || true
  fi
  rm -f /etc/systemd/system/frpc.service /etc/systemd/system/multi-user.target.wants/frpc.service
  [[ -d /run/systemd/system ]] && systemctl daemon-reload 2>/dev/null || true
  log "已移除 frpc 服务（/etc/frp/frpc.toml 保留，需要彻底删除可手动 rm）"
  exit 0
fi

# ---------- 生成配置 ----------
TMP_CFG="$(mktemp)"
trap 'rm -f "$TMP_CFG"' EXIT

"$PY" - "$PANEL_DIR" "$TUNNEL_SEL" "$LIST_ONLY" >"$TMP_CFG" <<'PYEOF'
import os, re, sqlite3, sys

panel_dir, tunnel_sel, list_only = sys.argv[1], sys.argv[2], sys.argv[3] == "1"

# 数据库路径以面板自身配置为准，避免自定义路径读错库
db_path = os.path.join(panel_dir, "frp_panel.db")
sys.path.insert(0, panel_dir)
try:
    import config  # noqa: E402
    candidate = getattr(config, "SQLITE_DB_PATH", None)
    if candidate:
        db_path = candidate if os.path.isabs(candidate) else os.path.join(panel_dir, candidate)
except Exception:
    pass
if not os.path.exists(db_path):
    fallback = os.path.join(panel_dir, "frp_panel.db")
    if os.path.exists(fallback):
        db_path = fallback
print("database: %s" % db_path, file=sys.stderr)

def die(msg, code=3):
    print(msg, file=sys.stderr)
    sys.exit(code)

def safe_token(value, fallback="yunwang"):
    value = str(value or "").strip()
    return value if re.fullmatch(r"[A-Za-z0-9._-]{1,128}", value) else fallback

def env_token():
    path = os.path.join(panel_dir, ".env")
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("DEFAULT_AUTH_TOKEN="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return "yunwang"

conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
rows = [dict(r) for r in conn.execute(
    "SELECT t.*, n.host AS node_host, n.port AS node_port, n.auth_token AS node_auth "
    "FROM tunnels t LEFT JOIN nodes n ON t.node_id = n.node_id ORDER BY t.created_at")]
conn.close()

if tunnel_sel:
    rows = [r for r in rows if str(r["tunnel_id"]) == tunnel_sel or str(r["name"]) == tunnel_sel]

if not rows:
    die("没有匹配的隧道。先用面板创建隧道，或 --list 查看。", 4)

if list_only:
    print("可用隧道：", file=sys.stderr)
    for r in rows:
        print("  id=%s  name=%s  node=%s  local=%s:%s  remote=%s" % (
            r["tunnel_id"], r["name"], r["node_id"], r["local_ip"], r["local_port"], r["remote_port"]),
            file=sys.stderr)
    sys.exit(0)

groups = {}
for r in rows:
    addr = str(r.get("node_host") or "127.0.0.1").strip()
    try:
        port = int(r.get("node_port") or 7000)
    except (TypeError, ValueError):
        port = 7000
    token = safe_token(r.get("node_auth"), safe_token(env_token()))
    groups.setdefault((addr, port, token), []).append(r)

if len(groups) > 1:
    print("这些隧道分布在不同的 frps 上，请用 --tunnel <id|名称> 分开安装：", file=sys.stderr)
    for (addr, port, _token), items in groups.items():
        names = ", ".join(str(i["name"]) for i in items)
        print("  %s:%s  ->  %s" % (addr, port, names), file=sys.stderr)
    sys.exit(5)

(addr, port, token), items = next(iter(groups.items()))

lines = [
    "# 由 setup-frpc.sh 自动生成（面板数据库）",
    'serverAddr = "%s"' % addr,
    "serverPort = %d" % port,
    'auth.token = "%s"' % token,
    "",
]
seen = {}
for r in items:
    base = str(r["name"] or r["tunnel_id"]).strip() or str(r["tunnel_id"])
    if base in seen:
        seen[base] += 1
        name = "%s-%d" % (base, seen[base])
    else:
        seen[base] = 1
        name = base
    lines.append("[[proxies]]")
    lines.append('name = "%s"' % name)
    lines.append('type = "%s"' % (r["type"] or "tcp"))
    lines.append('localIP = "%s"' % (r["local_ip"] or "127.0.0.1"))
    lines.append("localPort = %d" % int(r["local_port"]))
    if r.get("remote_port"):
        lines.append("remotePort = %d" % int(r["remote_port"]))
    if r.get("use_encryption"):
        lines.append("transport.useEncryption = true")
    domain = str(r.get("custom_domain") or "").strip()
    if domain and r["type"] in ("http", "https"):
        lines.append('customDomains = ["%s"]' % domain)
    lines.append("")

print("\n".join(lines))
print("frps: %s:%d | 隧道: %s" % (addr, port, ", ".join(str(i["name"]) for i in items)), file=sys.stderr)
PYEOF

if [[ "$LIST_ONLY" -eq 1 ]]; then exit 0; fi
if [[ "$PRINT_ONLY" -eq 1 ]]; then cat "$TMP_CFG"; exit 0; fi

[[ "$(id -u)" -eq 0 ]] || die "请用 root 运行：sudo bash $0"

# ---------- 安装 frpc ----------
if ! command -v frpc >/dev/null 2>&1 && [[ ! -x /usr/local/bin/frpc ]]; then
  case "$(uname -m)" in
    x86_64|amd64) A=amd64 ;;
    aarch64|arm64) A=arm64 ;;
    armv7l|armv6l|armhf) A=arm ;;
    i386|i686) A=386 ;;
    *) die "不支持的架构：$(uname -m)" ;;
  esac
  URL="https://github.com/fatedier/frp/releases/download/v${FRPC_VERSION}/frp_${FRPC_VERSION}_linux_${A}.tar.gz"
  TMPD="$(mktemp -d)"
  trap 'rm -rf "$TMPD"; rm -f "$TMP_CFG"' EXIT INT TERM
  log "下载 frpc ${FRPC_VERSION} (${A}) ..."
  OK=0
  for M in "https://ghfast.top/$URL" "https://ghproxy.net/$URL" "https://gh-proxy.com/$URL" "$URL"; do
    if curl -fL --retry 2 --connect-timeout 10 --max-time 180 -o "$TMPD/frp.tgz" "$M" 2>/dev/null \
        && tar tzf "$TMPD/frp.tgz" >/dev/null 2>&1; then
      tar xzf "$TMPD/frp.tgz" -C "$TMPD"
      F="$(find "$TMPD" -type f -name frpc | head -n1)"
      if [[ -n "$F" ]]; then install -m 0755 "$F" /usr/local/bin/frpc; OK=1; break; fi
    fi
  done
  [[ "$OK" -eq 1 ]] || die "frpc 下载失败，请手动下载 frp_${FRPC_VERSION}_linux_${A}.tar.gz 后把 frpc 放到 /usr/local/bin/frpc"
  log "frpc 安装完成"
fi

FRPC_BIN="$(command -v frpc || echo /usr/local/bin/frpc)"

# ---------- 写配置 ----------
log "写入 /etc/frp/frpc.toml"
mkdir -p /etc/frp
install -m 0600 "$TMP_CFG" /etc/frp/frpc.toml

# ---------- systemd ----------
if [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1; then
  log "注册 systemd 服务 frpc.service"
  cat > /etc/systemd/system/frpc.service <<SVCEOF
[Unit]
Description=frpc (CloudFRP)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${FRPC_BIN} -c /etc/frp/frpc.toml
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
SVCEOF
  systemctl daemon-reload
  systemctl enable frpc >/dev/null 2>&1 || true
  systemctl restart frpc
  sleep 2
  systemctl --no-pager --lines=6 status frpc || true
  echo
  echo "完成。日志：journalctl -u frpc -f"
else
  log "未检测到 systemd，后台运行"
  pkill -f 'frpc -c /etc/frp/frpc.toml' 2>/dev/null || true
  nohup "$FRPC_BIN" -c /etc/frp/frpc.toml >/var/log/cloudfrp-frpc.log 2>&1 &
  echo $! > /run/cloudfrp-frpc.pid
  echo "完成。日志：tail -f /var/log/cloudfrp-frpc.log"
fi

echo
echo "刷新面板「隧道列表」即可看到在线状态。"
