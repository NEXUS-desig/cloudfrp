#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CloudFRP 跨平台启动器（Windows / Linux / macOS）

界面参考 ChmlFrp 启动器：左侧隧道卡片列表、右侧详情与启停、底部实时日志、
顶部账号/积分信息、节点延迟、深色主题。

功能：
  - 登录面板、自动刷新隧道在线状态
  - 选择隧道一键连接/断开（自动下载对应平台 frpc）
  - 节点延迟检测、本地/远程端口展示
  - 命令行模式：--list / --tunnel / --foreground

配置目录：~/.cloudfrp（只保存面板地址和用户名，不保存密码）
"""
import argparse
import json
import os
import platform
import queue
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from http.cookiejar import CookieJar

APP_NAME = "CloudFRP 启动器"
VERSION = "1.1.0"
FRP_VERSION = "0.61.0"
HOME_DIR = os.path.join(os.path.expanduser("~"), ".cloudfrp")
SETTINGS = os.path.join(HOME_DIR, "settings.json")
FRPC_LOCAL = os.path.join(HOME_DIR, "frpc.exe" if os.name == "nt" else "frpc")
CONFIG_PATH = os.path.join(HOME_DIR, "frpc.toml")

try:
    import customtkinter as ctk
    HAS_GUI = True
except Exception:  # noqa: BLE001
    HAS_GUI = False
    ctk = None

# 配色（与面板深色主题一致）
BG = "#0b161a"
CARD = "#102124"
SURFACE = "#182f35"
LINE = "#23424a"
INK = "#d3e2e4"
MUTED = "#8caab0"
FAINT = "#7a9aa0"
ACCENT = "#2f8f88"
ACCENT_HOVER = "#3aa39a"
OK = "#43c59e"
ERR = "#e07a74"


# ── 通用 ─────────────────────────────────────────────
def ensure_home():
    os.makedirs(HOME_DIR, exist_ok=True)
    try:
        os.chmod(HOME_DIR, 0o700)
    except OSError:
        pass


def load_settings():
    try:
        with open(SETTINGS, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_settings(data):
    ensure_home()
    try:
        with open(SETTINGS, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
    except OSError:
        pass


def os_arch():
    machine = platform.machine().lower()
    if os.name == "nt" or sys.platform == "darwin":
        return "arm64" if machine in ("arm64", "aarch64") else "amd64"
    return {
        "x86_64": "amd64", "amd64": "amd64",
        "aarch64": "arm64", "arm64": "arm64",
        "armv7l": "arm", "armv6l": "arm", "armhf": "arm",
        "i386": "386", "i686": "386",
    }.get(machine, "amd64")


def frp_asset():
    arch = os_arch()
    if os.name == "nt":
        return "frp_%s_windows_%s.zip" % (FRP_VERSION, arch), "zip"
    if sys.platform == "darwin":
        return "frp_%s_darwin_%s.tar.gz" % (FRP_VERSION, arch), "tar"
    return "frp_%s_linux_%s.tar.gz" % (FRP_VERSION, arch), "tar"


def download(url, dest, timeout=180):
    req = urllib.request.Request(url, headers={"User-Agent": "cloudfrp-launcher/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as fh:
        shutil.copyfileobj(resp, fh)


def ensure_frpc(log=print):
    if os.path.isfile(FRPC_LOCAL):
        return FRPC_LOCAL
    found = shutil.which("frpc")
    if found:
        return found
    ensure_home()
    asset, kind = frp_asset()
    base = "https://github.com/fatedier/frp/releases/download/v%s/%s" % (FRP_VERSION, asset)
    mirrors = ["https://ghfast.top/" + base, "https://ghproxy.net/" + base,
               "https://gh-proxy.com/" + base, base]
    log("正在下载 frpc（%s）..." % asset)
    tmpdir = tempfile.mkdtemp(prefix="cfrp-")
    archive = os.path.join(tmpdir, asset)
    last = None
    for url in mirrors:
        try:
            download(url, archive)
            if kind == "zip":
                with zipfile.ZipFile(archive) as zf:
                    zf.extractall(tmpdir)
            else:
                with tarfile.open(archive, "r:gz") as tf:
                    tf.extractall(tmpdir)
            for root, _dirs, files in os.walk(tmpdir):
                name = "frpc.exe" if os.name == "nt" else "frpc"
                if name in files:
                    shutil.copy2(os.path.join(root, name), FRPC_LOCAL)
                    if os.name != "nt":
                        os.chmod(FRPC_LOCAL, 0o755)
                    log("frpc 下载完成")
                    return FRPC_LOCAL
        except Exception as exc:  # noqa: BLE001
            last = exc
            continue
    raise RuntimeError("frpc 下载失败：%s\n请手动把 frpc 放到 %s" % (last, FRPC_LOCAL))


def tcp_latency(host, port, timeout=2.0):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        start = time.time()
        sock.connect((host, int(port)))
        ms = (time.time() - start) * 1000
        sock.close()
        return ms
    except Exception:  # noqa: BLE001
        return None


# ── 面板 API ─────────────────────────────────────────
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Panel:
    def __init__(self):
        self.base = ""
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar))
        self.login_opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar), _NoRedirect())
        self.user = {}

    def _get(self, path, timeout=15):
        return self.opener.open(self.base.rstrip("/") + path, timeout=timeout).read()

    def login(self, panel, username, password):
        self.base = panel.rstrip("/")
        data = urllib.parse.urlencode({
            "username": username, "password": password,
            "captcha": "verified", "remember": "on"}).encode()
        try:
            try:
                self.login_opener.open(urllib.request.Request(
                    self.base + "/login", data=data, method="POST",
                    headers={"X-CloudFRP-Client": "launcher"}), timeout=10).read()
            except urllib.error.HTTPError as exc:
                if exc.code not in (301, 302, 303, 307, 308):
                    return False, "登录失败（HTTP %s）" % exc.code
            info = json.loads(self._get("/api/user-info", 10) or b"{}")
        except urllib.error.HTTPError as exc:
            return False, "登录失败（HTTP %s）" % exc.code
        except Exception as exc:  # noqa: BLE001
            return False, "无法连接面板：%s" % exc
        if not info.get("username"):
            return False, "用户名或密码错误"
        self.user = info
        return True, "登录成功"

    def _json(self, path, timeout=10):
        return json.loads(self._get(path, timeout) or b"{}")

    def tunnels(self):
        data = self._json("/api/tunnels")
        return data.get("tunnels") or []

    def tunnel_config(self, tunnel_id):
        raw = self._get("/api/tunnels/%s/config" % urllib.parse.quote(str(tunnel_id)))
        data = json.loads(raw or b"{}")
        return data.get("toml") or ""

    def stats(self):
        out = {}
        for key, path in (("user", "/api/user/stats"), ("nodes", "/api/nodes/stats")):
            try:
                out[key] = json.loads(self._get(path, 10) or b"{}")
            except Exception:  # noqa: BLE001
                out[key] = {}
        return out


class FrpcRunner:
    def __init__(self, log=print):
        self.proc = None
        self.log = log

    @property
    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self, toml_text):
        if self.running:
            return False, "已有隧道在运行，请先断开"
        ensure_home()
        with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
            fh.write(toml_text)
        if os.name != "nt":
            os.chmod(CONFIG_PATH, 0o600)
        binary = ensure_frpc(self.log)
        self.log("启动 frpc：%s" % binary)
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.proc = subprocess.Popen(
            [binary, "-c", CONFIG_PATH], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1, **kwargs)
        threading.Thread(target=self._pump, daemon=True).start()
        return True, "已启动"

    def _pump(self):
        try:
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except Exception:  # noqa: BLE001
            pass
        self.log("frpc 已退出")

    def stop(self):
        if not self.running:
            return False, "未在运行"
        self.proc.terminate()
        try:
            self.proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.log("frpc 已停止")
        return True, "已停止"


# ── 图形界面 ─────────────────────────────────────────
class Launcher(ctk.CTk if HAS_GUI else object):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("%s v%s" % (APP_NAME, VERSION))
        self.geometry("980x660")
        self.minsize(880, 580)
        self.configure(fg_color=BG)
        self.panel = Panel()
        self.runner = FrpcRunner(self.log)
        self.tunnels = []
        self.selected_id = None
        self._logged = False
        self.cards = {}
        self._card_ids = []
        self.levels = []
        self._uiq = queue.Queue()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._show_login()
        self.after(30, self._drain)
        self.after(1000, self._tick)

    # ---------- 主线程 UI 队列（子线程不能直接碰 Tk） ----------
    def ui(self, fn):
        self._uiq.put(fn)

    def _drain(self):
        try:
            while True:
                fn = self._uiq.get_nowait()
                try:
                    fn()
                except Exception:  # noqa: BLE001
                    pass
        except queue.Empty:
            pass
        self.after(30, self._drain)

    # ---------- 登录页 ----------
    def _show_login(self):
        cfg = load_settings()
        self.login_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.login_frame.place(relx=0.5, rely=0.5, anchor="center")

        card = ctk.CTkFrame(self.login_frame, fg_color=CARD, corner_radius=16,
                            border_width=1, border_color=LINE)
        card.pack(padx=10, pady=10)

        ctk.CTkLabel(card, text="CloudFRP", font=("Microsoft YaHei UI", 26, "bold"),
                     text_color=INK).pack(padx=36, pady=(28, 2))
        ctk.CTkLabel(card, text="FRP 内网穿透启动器", font=("Microsoft YaHei UI", 12),
                     text_color=MUTED).pack(pady=(0, 22))

        self.ent_panel = ctk.CTkEntry(card, width=320, height=38, placeholder_text="面板地址",
                                      fg_color=SURFACE, border_color=LINE)
        self.ent_panel.pack(padx=36, pady=6)
        self.ent_panel.insert(0, cfg.get("panel", "http://localhost:3592"))

        self.ent_user = ctk.CTkEntry(card, width=320, height=38, placeholder_text="用户名",
                                     fg_color=SURFACE, border_color=LINE)
        self.ent_user.pack(padx=36, pady=6)
        self.ent_user.insert(0, cfg.get("username", ""))

        self.ent_pass = ctk.CTkEntry(card, width=320, height=38, placeholder_text="密码",
                                     show="*", fg_color=SURFACE, border_color=LINE)
        self.ent_pass.pack(padx=36, pady=6)
        self.ent_pass.bind("<Return>", lambda _e: self.do_login())

        self.btn_login = ctk.CTkButton(card, text="登 录", height=40, width=320,
                                       fg_color=ACCENT, hover_color=ACCENT_HOVER,
                                       font=("Microsoft YaHei UI", 14, "bold"),
                                       command=self.do_login)
        self.btn_login.pack(padx=36, pady=(14, 8))

        self.login_status = ctk.CTkLabel(card, text="", text_color=MUTED,
                                         font=("Microsoft YaHei UI", 12))
        self.login_status.pack(pady=(0, 24))

    def do_login(self):
        panel = self.ent_panel.get().strip()
        user = self.ent_user.get().strip()
        pwd = self.ent_pass.get()
        if not panel or not user or not pwd:
            self.login_status.configure(text="请填写完整", text_color=ERR)
            return
        self.btn_login.configure(state="disabled", text="登录中...")

        def work():
            ok, msg = self.panel.login(panel, user, pwd)
            if ok:
                save_settings({"panel": panel, "username": user})
                self.ui(lambda: self._enter_main(msg))
            else:
                self.ui(lambda: (
                    self.login_status.configure(text=msg, text_color=ERR),
                    self.btn_login.configure(state="normal", text="登 录")))
        threading.Thread(target=work, daemon=True).start()

    # ---------- 主界面 ----------
    def _enter_main(self, msg):
        self._logged = True
        self._pending_show = True
        self.withdraw()                 # 隐藏窗口构建，避免逐个控件同步重绘
        self.login_frame.destroy()
        self.build_main()
        self.log(msg)
        self.refresh()
        self.after(3000, self._show_window)

    def build_main(self):
        top = ctk.CTkFrame(self, height=56, fg_color=CARD, corner_radius=0)
        top.pack(fill="x")
        ctk.CTkLabel(top, text="CloudFRP", font=("Microsoft YaHei UI", 18, "bold"),
                     text_color=INK).pack(side="left", padx=18)
        self.lbl_account = ctk.CTkLabel(top, text="", font=("Microsoft YaHei UI", 12),
                                        text_color=MUTED)
        self.lbl_account.pack(side="left", padx=10)
        ctk.CTkButton(top, text="刷新", width=72, height=30, fg_color=SURFACE,
                      hover_color=LINE, command=self.refresh).pack(side="right", padx=16)
        self.lbl_stats = ctk.CTkLabel(top, text="", font=("Microsoft YaHei UI", 12),
                                      text_color=MUTED)
        self.lbl_stats.pack(side="right", padx=10)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=14, pady=(12, 0))

        left = ctk.CTkFrame(body, width=320, fg_color=CARD, corner_radius=12,
                            border_width=1, border_color=LINE)
        left.pack(side="left", fill="y", padx=(0, 12))
        left.pack_propagate(False)
        ctk.CTkLabel(left, text="我的隧道", font=("Microsoft YaHei UI", 14, "bold"),
                     text_color=INK).pack(anchor="w", padx=16, pady=(14, 8))
        self.tunnel_scroll = ctk.CTkScrollableFrame(left, fg_color="transparent")
        self.tunnel_scroll.pack(fill="both", expand=True, padx=8, pady=(0, 10))
        self.loading_label = ctk.CTkLabel(self.tunnel_scroll, text="加载中...",
                                          text_color=FAINT, font=("Microsoft YaHei UI", 12))
        self.loading_label.pack(pady=24)

        right = ctk.CTkFrame(body, fg_color=CARD, corner_radius=12,
                             border_width=1, border_color=LINE)
        right.pack(side="left", fill="both", expand=True)

        self.detail_title = ctk.CTkLabel(right, text="选择左侧隧道", text_color=INK,
                                         font=("Microsoft YaHei UI", 20, "bold"))
        self.detail_title.pack(anchor="w", padx=20, pady=(18, 4))
        self.detail_sub = ctk.CTkLabel(right, text="", text_color=MUTED,
                                       font=("Microsoft YaHei UI", 12))
        self.detail_sub.pack(anchor="w", padx=20)

        info = ctk.CTkFrame(right, fg_color=SURFACE, corner_radius=10)
        info.pack(fill="x", padx=20, pady=14)
        self.info_labels = {}
        for key, label in (("local", "本地服务"), ("remote", "公网端口"),
                           ("node", "节点"), ("latency", "节点延迟"), ("status", "状态")):
            row = ctk.CTkFrame(info, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=5)
            ctk.CTkLabel(row, text=label, width=80, anchor="w", text_color=FAINT,
                         font=("Microsoft YaHei UI", 12)).pack(side="left")
            value = ctk.CTkLabel(row, text="-", anchor="w", text_color=INK,
                                 font=("Microsoft YaHei UI", 12))
            value.pack(side="left", fill="x", expand=True)
            self.info_labels[key] = value

        actions = ctk.CTkFrame(right, fg_color="transparent")
        actions.pack(fill="x", padx=20, pady=(0, 12))
        self.btn_connect = ctk.CTkButton(actions, text="连接", height=40, width=140,
                                         fg_color=ACCENT, hover_color=ACCENT_HOVER,
                                         font=("Microsoft YaHei UI", 14, "bold"),
                                         command=self.connect)
        self.btn_connect.pack(side="left")
        self.btn_disconnect = ctk.CTkButton(actions, text="断开", height=40, width=100,
                                            fg_color=SURFACE, hover_color=LINE,
                                            command=self.disconnect)
        self.btn_disconnect.pack(side="left", padx=10)

        logframe = ctk.CTkFrame(self, fg_color=CARD, corner_radius=12,
                                border_width=1, border_color=LINE)
        logframe.pack(fill="both", expand=False, padx=14, pady=12)
        head = ctk.CTkFrame(logframe, fg_color="transparent")
        head.pack(fill="x", padx=12, pady=(8, 0))
        ctk.CTkLabel(head, text="运行日志", text_color=MUTED,
                     font=("Microsoft YaHei UI", 12)).pack(side="left")
        ctk.CTkButton(head, text="清空", width=56, height=24, fg_color=SURFACE,
                      hover_color=LINE, command=self._clear_log).pack(side="right")
        self.logbox = ctk.CTkTextbox(logframe, height=150, fg_color=SURFACE,
                                     text_color=INK, font=("Consolas", 11))
        self.logbox.pack(fill="both", expand=True, padx=12, pady=(6, 12))
        self.logbox.configure(state="disabled")

        self.lbl_account.configure(text="%s · 积分 %s" % (
            self.panel.user.get("username", ""), self.panel.user.get("points", "-")))

    def _clear_log(self):
        self.logbox.configure(state="normal")
        self.logbox.delete("1.0", "end")
        self.logbox.configure(state="disabled")

    def log(self, msg):
        text = "%s  %s\n" % (time.strftime("%H:%M:%S"), msg)

        def append():
            self.logbox.configure(state="normal")
            self.logbox.insert("end", text)
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        try:
            self.ui(append)
        except Exception:  # noqa: BLE001
            print(msg)

    def _show_window(self):
        if not getattr(self, "_pending_show", False):
            return
        self._pending_show = False
        try:
            self.deiconify()
            self.lift()
        except Exception:  # noqa: BLE001
            pass

    # ---------- 数据刷新 ----------
    def refresh(self):
        def work():
            try:
                with ThreadPoolExecutor(max_workers=5) as pool:
                    ft = pool.submit(self.panel.tunnels)
                    fu = pool.submit(self.panel._json, "/api/user-info")
                    fs = pool.submit(self.panel._json, "/api/user/stats")
                    fn = pool.submit(self.panel._json, "/api/nodes/stats")
                    fl = pool.submit(self.panel._json, "/api/membership/levels")
                    tunnels = ft.result()
                    user = fu.result()
                    stats = fs.result()
                    nodes = fn.result()
                    levels = fl.result().get("levels") or []
            except Exception as exc:  # noqa: BLE001
                self.log("刷新失败：%s" % exc)
                return
            self.ui(lambda: self._render(tunnels, user, stats, nodes, levels))
        threading.Thread(target=work, daemon=True).start()

    def _render(self, tunnels, user, stats, nodes, levels):
        self.tunnels = tunnels
        self.levels = levels or []
        if self.selected_id is None and tunnels:
            self.selected_id = _tid(tunnels[0])

        ids = [_tid(t) for t in tunnels]
        if ids != self._card_ids:
            self._card_ids = ids
            for w in self.tunnel_scroll.winfo_children():
                w.destroy()
            self.cards = {}
            if tunnels:
                for t in tunnels:
                    self._build_card(t)
            else:
                ctk.CTkLabel(self.tunnel_scroll, text="还没有隧道\n请先在面板创建",
                             text_color=FAINT, font=("Microsoft YaHei UI", 12)).pack(pady=30)
        else:
            for t in tunnels:
                self._update_card(t)

        if self.selected_id:
            for t in tunnels:
                if _tid(t) == self.selected_id:
                    self._show_detail(t)
                    break

        total = len(tunnels)
        online = sum(1 for t in tunnels if str(t.get("status")) in ("online", "running"))
        u = user or {}
        n = nodes or {}
        self.lbl_account.configure(text="%s · %s · 积分 %s" % (
            u.get("username") or self.panel.user.get("username", ""),
            self._level_name(u.get("membership_level")),
            u.get("points", self.panel.user.get("points", "-"))))
        self.lbl_stats.configure(text="隧道 %d · 在线 %d · 节点 %s/%s · %s" % (
            total, online, n.get("online_nodes", 0), n.get("total_nodes", 0),
            time.strftime("%H:%M:%S")))
        self._show_window()

    def _sub_text(self, t):
        return "%s · %s:%s" % (str(t.get("type") or "").upper(),
                               t.get("local_ip", "127.0.0.1"), t.get("local_port", ""))

    def _level_name(self, value):
        if value in (None, ""):
            return "免费"
        name = str(value)
        for lv in self.levels:
            if str(lv.get("id")) == str(value) or str(lv.get("level_name")) == str(value):
                name = str(lv.get("level_name") or value)
                break
        if name.lower() in ("free", "免费", "免费档"):
            return "免费"
        return name

    def _build_card(self, t):
        tid = _tid(t)
        card = ctk.CTkFrame(self.tunnel_scroll, fg_color="transparent",
                            corner_radius=8, border_width=0)
        card.pack(fill="x", padx=4, pady=3)
        dot = ctk.CTkLabel(card, text="●", width=18, text_color=FAINT)
        dot.pack(side="left", padx=(8, 2), pady=8)
        box = ctk.CTkFrame(card, fg_color="transparent")
        box.pack(side="left", fill="x", expand=True)
        name = ctk.CTkLabel(box, text=t.get("name") or tid, anchor="w", text_color=INK,
                            font=("Microsoft YaHei UI", 13, "bold"))
        name.pack(fill="x")
        sub = ctk.CTkLabel(box, text=self._sub_text(t), anchor="w", text_color=FAINT,
                           font=("Microsoft YaHei UI", 11))
        sub.pack(fill="x")
        for widget in (card, dot, box, name, sub):
            widget.bind("<Button-1>", lambda _e, tt=t: self._select(tt))
        self.cards[tid] = {"card": card, "dot": dot, "sub": sub, "name": name}
        self._update_card(t)

    def _update_card(self, t):
        tid = _tid(t)
        widgets = self.cards.get(tid)
        if not widgets:
            return
        online = str(t.get("status")) in ("online", "running")
        active = tid == self.selected_id
        widgets["dot"].configure(text_color=OK if online else FAINT)
        widgets["sub"].configure(text=self._sub_text(t))
        widgets["card"].configure(
            fg_color=SURFACE if active else "transparent",
            border_width=1 if active else 0,
            border_color=ACCENT if active else LINE)

    def _select(self, tunnel):
        self.selected_id = _tid(tunnel)
        for t in self.tunnels:
            self._update_card(t)
        self._show_detail(tunnel)

    def _show_detail(self, t):
        self.detail_title.configure(text=t.get("name") or _tid(t))
        self.detail_sub.configure(text="隧道 ID：%s" % _tid(t))
        self.info_labels["local"].configure(
            text="%s:%s" % (t.get("local_ip", "127.0.0.1"), t.get("local_port", "-")))
        self.info_labels["remote"].configure(text=str(t.get("remote_port") or "-"))
        node = t.get("node_host") or ""
        port = t.get("node_port") or 7000
        self.info_labels["node"].configure(
            text=(node + ":" + str(port)) if node else "自动（本机 frps :7000）")
        online = str(t.get("status")) in ("online", "running")
        self.info_labels["status"].configure(
            text="在线" if online else "离线", text_color=OK if online else ERR)
        self.info_labels["latency"].configure(text="检测中...")

        host = node or "127.0.0.1"

        def probe():
            ms = tcp_latency(host, port)
            text = ("%.0f ms" % ms) if ms is not None else "不可达"
            color = OK if ms is not None and ms < 200 else (MUTED if ms is not None else ERR)
            self.ui(lambda: self.info_labels["latency"].configure(
                text=text, text_color=color))
        threading.Thread(target=probe, daemon=True).start()

    # ---------- 连接 ----------
    def connect(self):
        t = self._current()
        if not t:
            self.log("请先选择隧道")
            return
        self.btn_connect.configure(state="disabled", text="连接中...")

        def work():
            try:
                if self.runner.running:
                    self.runner.stop()
                toml_text = self.panel.tunnel_config(_tid(t))
                ok, msg = self.runner.start(toml_text)
                self.log("%s：%s" % (t.get("name"), msg))
            except Exception as exc:  # noqa: BLE001
                self.log("连接失败：%s" % exc)
            finally:
                self.ui(lambda: self.btn_connect.configure(state="normal", text="连接"))
                self.ui(lambda: self.after(1500, self.refresh))
        threading.Thread(target=work, daemon=True).start()

    def disconnect(self):
        ok, msg = self.runner.stop()
        self.log(msg)
        self.after(1200, self.refresh)

    def _current(self):
        for t in self.tunnels:
            if _tid(t) == self.selected_id:
                return t
        return None

    def _tick(self):
        if self._logged:
            self.refresh()
        self.after(5000, self._tick)

    def _on_close(self):
        if self.runner.running:
            self.runner.stop()
        self.destroy()


def _tid(tunnel):
    return str(tunnel.get("tunnel_id", tunnel.get("id", "")))


# ── 命令行 ───────────────────────────────────────────
def cli(args):
    panel = Panel()
    ok, msg = panel.login(args.panel, args.user, args.password)
    print(msg)
    if not ok:
        return 1
    tunnels = panel.tunnels()
    if args.list:
        for t in tunnels:
            print("id=%s  name=%s  type=%s  local=%s:%s  status=%s" % (
                _tid(t), t.get("name"), t.get("type"), t.get("local_ip"),
                t.get("local_port"), t.get("status")))
        return 0
    if not args.tunnel:
        print("请用 --tunnel <id|名称> 指定隧道，或 --list 查看")
        return 2
    match = None
    for t in tunnels:
        if _tid(t) == args.tunnel or str(t.get("name")) == args.tunnel:
            match = t
            break
    if not match:
        print("找不到隧道：%s" % args.tunnel)
        return 3
    toml_text = panel.tunnel_config(_tid(match))
    runner = FrpcRunner(print)
    ok, msg = runner.start(toml_text)
    print(msg)
    if not ok:
        return 4
    try:
        while runner.running:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n正在停止...")
    runner.stop()
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description="CloudFRP 跨平台启动器")
    parser.add_argument("--panel", default=None)
    parser.add_argument("--user", default=None)
    parser.add_argument("--password", default=None)
    parser.add_argument("--tunnel", default=None)
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--foreground", action="store_true")
    parser.add_argument("--version", action="version", version=APP_NAME + " " + VERSION)
    args = parser.parse_args(argv)

    if args.panel and args.user and args.password and (args.list or args.tunnel):
        return cli(args)
    if not HAS_GUI:
        parser.error("当前环境没有图形界面，请使用 --panel --user --password --tunnel 命令行模式")
    Launcher().mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
