"""Web 安全加固：响应头 / CSP、限流、登录锁定、CSRF 同源校验、会话固定防护。"""
import re
import threading
import time
from collections import defaultdict, deque
from urllib.parse import urlparse

from flask import jsonify, render_template, request, session

_LOCK = threading.Lock()
_RATE = defaultdict(deque)
_FAIL = {}

LOGIN_MAX_FAIL = 5
LOGIN_WINDOW = 15 * 60
LOGIN_BLOCK = 15 * 60

_CSP = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
    "font-src 'self' data: https://fonts.gstatic.com; "
    "img-src 'self' data: blob:; "
    "connect-src 'self'; "
    "media-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'self'"
)

_HEARTBEAT = re.compile(r"^/api/nodes/[^/]+/heartbeat$")

# 常见采集器 / 扫描器 UA（正常浏览器和启动器不受影响）
_BAD_UA = (
    "ahrefs", "semrush", "mj12bot", "dotbot", "bytespider", "petalbot",
    "gptbot", "ccbot", "claudebot", "scrapy", "sqlmap", "nikto",
    "acunetix", "nuclei", "masscan", "zgrab", "dirbuster", "gobuster",
    "googlebot", "bingbot", "yandexbot", "baiduspider", "duckduckbot",
)
# 扫描器常打的路由；命中直接 404，不暴露面板存在
_BAD_PATH = re.compile(
    r"(^/\.|/\.git|/\.env|/\.ds_store|/wp-|/wordpress|/phpmyadmin|"
    r"/xmlrpc|/vendor/|/adminer|/actuator|/server-status|/cgi-bin|"
    r"/boaform|/hnap1|/login\.php|/config\.php|/backup\.zip)",
    re.IGNORECASE)
_BANNED = {}
_HONEYPOT = "/__trap"


def client_ip():
    return (request.remote_addr or "unknown").strip()


def _is_banned(ip):
    until = _BANNED.get(ip)
    if not until:
        return False
    if until > time.time():
        return True
    _BANNED.pop(ip, None)
    return False


def ban_ip(ip, seconds=24 * 3600):
    _BANNED[ip] = time.time() + seconds


def _rate_rule(method, path):
    if method == "POST" and path == "/login":
        return 30, 300
    if method == "POST" and path == "/register":
        return 10, 3600
    if method == "POST" and path == "/api/register/send-code":
        return 5, 300
    if method == "POST" and path == "/api/email/send-code":
        return 10, 300
    if path == "/api/captcha/new":
        return 60, 60
    if method == "POST" and path == "/api/checkin":
        return 10, 60
    if method == "POST" and _HEARTBEAT.match(path):
        return 300, 60
    return None


def _allow(key, limit, window):
    now = time.time()
    with _LOCK:
        if len(_RATE) > 20000:
            for k in [k for k, q in _RATE.items() if not q or now - q[-1] > 300]:
                _RATE.pop(k, None)
        q = _RATE[key]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            return False, int(window - (now - q[0])) + 1
        q.append(now)
        return True, 0


def _fail_entry(key):
    entry = _FAIL.get(key)
    if not entry:
        return None
    if entry.get("until", 0) > time.time():
        return entry
    if time.time() - entry.get("first", 0) > LOGIN_WINDOW:
        _FAIL.pop(key, None)
        return None
    return entry


def _login_key(username, ip):
    return "lu:%s:%s" % (str(username or "").strip().lower(), ip)


def login_precheck(username, ip):
    with _LOCK:
        entry = _fail_entry(_login_key(username, ip))
        if entry and entry.get("until", 0) > time.time():
            return False, "尝试次数过多，请 15 分钟后再试", int(entry["until"] - time.time())
    return True, "", 0


def record_login_failure(username, ip):
    now = time.time()
    key = _login_key(username, ip)
    with _LOCK:
        if len(_FAIL) > 5000:
            for k in [k for k, v in _FAIL.items() if v.get("until", 0) < now]:
                _FAIL.pop(k, None)
        entry = _fail_entry(key) or {"count": 0, "first": now, "until": 0}
        entry["count"] = entry.get("count", 0) + 1
        if entry["count"] >= LOGIN_MAX_FAIL:
            entry["until"] = now + LOGIN_BLOCK
            entry["count"] = 0
            entry["first"] = now
        _FAIL[key] = entry


def clear_login_failures(username, ip):
    with _LOCK:
        _FAIL.pop(_login_key(username, ip), None)


def _same_origin():
    origin = request.headers.get("Origin")
    if origin:
        if origin == "null":
            return False
        try:
            if urlparse(origin).netloc != request.host:
                return False
        except ValueError:
            return False
    referer = request.headers.get("Referer")
    if referer and not referer.startswith(request.host_url):
        return False
    return True


def init_security(app):
    @app.before_request
    def _security_before():
        path = request.path
        method = request.method
        ip = client_ip()

        if _is_banned(ip):
            if path.startswith("/api/"):
                return jsonify({"success": False, "message": "访问已被限制"}), 403
            return "Forbidden", 403

        if path == _HONEYPOT:
            ban_ip(ip)
            return "Not Found", 404

        if method.upper() in ("TRACE", "TRACK"):
            return "Method Not Allowed", 405

        if ".." in path or _BAD_PATH.search(path):
            return "Not Found", 404

        ua = (request.headers.get("User-Agent") or "").lower()
        if ua and any(token in ua for token in _BAD_UA):
            if path.startswith("/api/"):
                return jsonify({"success": False, "message": "Forbidden"}), 403
            return "Forbidden", 403

        # 页面级限流：同一 IP 每分钟最多 120 次页面请求（静态资源不计）
        if not path.startswith("/api/") and not path.startswith("/static/"):
            ok, retry = _allow("page:%s" % ip, 120, 60)
            if not ok:
                r = app.make_response("请求过于频繁，请稍后再试")
                r.status_code = 429
                r.headers["Retry-After"] = str(retry)
                return r

        # 除了管理员恢复备份，其他请求不允许超大体积（防止内存耗尽）
        limit = 64 * 1024 * 1024 if path == "/api/admin/backup/restore" else 12 * 1024 * 1024
        if request.content_length and request.content_length > limit:
            if path.startswith("/api/"):
                return jsonify({"success": False, "message": "请求体过大"}), 413
            return "请求体过大", 413
        if method in ("POST", "PUT", "PATCH", "DELETE") and not _same_origin():
            if path.startswith("/api/"):
                return jsonify({"success": False, "message": "请求来源不合法"}), 403
            return "请求来源不合法", 403

        rule = _rate_rule(method, path)
        if rule:
            ok, retry = _allow("%s:%s:%s" % (client_ip(), method, path), *rule)
            if not ok:
                resp = (jsonify({"success": False, "message": "请求过于频繁，请稍后再试"})
                        if path.startswith("/api/") else
                        "请求过于频繁，请稍后再试")
                r = app.make_response(resp)
                r.status_code = 429
                r.headers["Retry-After"] = str(retry)
                return r
        return None

    @app.after_request
    def _security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        resp.headers["X-Permitted-Cross-Domain-Policies"] = "none"
        resp.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive, nosnippet"
        resp.headers.setdefault("Content-Security-Policy", _CSP)
        if request.is_secure:
            resp.headers.setdefault("Strict-Transport-Security",
                                    "max-age=31536000; includeSubDomains")
        if request.path.startswith("/api/") or request.path in ("/login", "/register", "/dashboard"):
            resp.headers.setdefault("Cache-Control", "no-store")
        # 不暴露服务端软件版本
        resp.headers.pop("Server", None)
        return resp

    @app.errorhandler(413)
    def _too_large(_exc):
        if request.path.startswith("/api/"):
            return jsonify({"success": False, "message": "上传文件过大"}), 413
        return "上传文件过大", 413

    @app.errorhandler(500)
    def _server_error(_exc):
        if request.path.startswith("/api/"):
            return jsonify({"success": False, "message": "服务器内部错误"}), 500
        return render_template("error.html"), 500
