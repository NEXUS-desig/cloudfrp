"""
数据库抽象层 - 统一处理 SQLite 和 MySQL
"""
import sqlite3
import pymysql
from contextlib import contextmanager
from config import config


class Database:
    """数据库管理类 - 支持 SQLite 和 MySQL"""
    
    def __init__(self):
        self.use_mysql = config.USE_MYSQL
        self._init_sqlite()
    
    def _sqlite_connect(self):
        """SQLite 连接：统一开启 WAL + busy_timeout，避免并发写锁报错。"""
        conn = sqlite3.connect(config.SQLITE_DB_PATH, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _init_sqlite(self):
        """初始化 SQLite 数据库"""
        if not self.use_mysql:
            conn = self._sqlite_connect()
            try:
                # WAL 是持久化设置：写入数据库文件后后续连接自动生效
                conn.execute("PRAGMA journal_mode = WAL")
                conn.execute("PRAGMA synchronous = NORMAL")
                conn.commit()
            finally:
                conn.close()

    @contextmanager
    def get_connection(self):
        """获取数据库连接（上下文管理器）"""
        if self.use_mysql:
            conn = pymysql.connect(
                host=config.DB_HOST,
                port=config.DB_PORT,
                user=config.DB_USER,
                password=config.DB_PASSWORD,
                database=config.DB_NAME,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
        else:
            conn = self._sqlite_connect()

        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    @contextmanager
    def get_cursor(self):
        """获取数据库游标（上下文管理器）"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            try:
                yield cursor
            finally:
                cursor.close()
    
    def execute(self, sql, params=None):
        """执行 SQL 语句"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.lastrowid

    def execute_rowcount(self, sql, params=None):
        """执行写语句并返回受影响行数（用于原子的 compare-and-set）。"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.rowcount
    
    def fetchone(self, sql, params=None):
        """查询单条记录"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or ())
            row = cursor.fetchone()
            if row is None:
                return None
            # 统一转为字典，兼容 sqlite3.Row 和 pymysql.DictCursor
            if hasattr(row, 'keys'):
                return dict(row)
            return row
    
    def fetchall(self, sql, params=None):
        """查询多条记录"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or ())
            rows = cursor.fetchall()
            # 统一转为字典列表，兼容 sqlite3.Row 和 pymysql.DictCursor
            if rows and hasattr(rows[0], 'keys'):
                return [dict(r) for r in rows]
            return rows
    
    def init_tables(self):
        """初始化数据库表（所有迁移均可重复执行）"""
        if self.use_mysql:
            self._init_mysql_tables()
        else:
            self._init_sqlite_tables()
        self._migrate_roles()
        self._migrate_user_profile()
        self._migrate_limits_bonus()
        self._migrate_level_scaling()
        self._migrate_custom_limits()
        self._migrate_user_traffic()
        self._migrate_node_meta()
        self._migrate_background_and_heartbeat()
        self._migrate_email_codes()
        self._migrate_tunnels()
        self._migrate_traffic()
        self._migrate_node_approval()
        self._migrate_user_cascade()

    # ---- schema introspection (make migrations idempotent) -----------------
    def _has_column(self, table, column):
        try:
            if self.use_mysql:
                row = self.fetchone(
                    "SELECT 1 AS ok FROM information_schema.columns "
                    "WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s",
                    (table, column))
                return row is not None
            rows = self.fetchall(f"PRAGMA table_info({table})")
            return any((r.get("name") == column) for r in rows)
        except Exception:
            return False

    def _has_index(self, table, index):
        try:
            if self.use_mysql:
                row = self.fetchone(
                    "SELECT 1 AS ok FROM information_schema.statistics "
                    "WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s",
                    (table, index))
                return row is not None
            rows = self.fetchall(f"PRAGMA index_list({table})")
            return any((r.get("name") == index) for r in rows)
        except Exception:
            return False

    def _ensure_index(self, table, index, columns):
        """创建索引（SQLite/MySQL 均幂等）。"""
        if self._has_index(table, index):
            return
        try:
            self.execute(f"CREATE INDEX {index} ON {table} ({columns})")
        except Exception:
            pass

    def _add_column(self, table, column, ddl):
        """仅在列不存在时执行 ALTER TABLE ADD COLUMN。"""
        if self._has_column(table, column):
            return
        try:
            self.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
        except Exception:
            pass

    def _migrate_node_approval(self):
        """nodes.approved: 捐赠节点需管理员审核后才可用于建隧道（参考 frp-panel 的受控接入）"""
        col = "TINYINT DEFAULT 0" if self.use_mysql else "INTEGER DEFAULT 0"
        self._add_column("nodes", "approved", col)
        self._ensure_index("nodes", "idx_nodes_approved", "approved")

    def _migrate_user_cascade(self):
        """SQLite 外键未声明 ON DELETE CASCADE；用触发器补齐，与 MySQL 行为一致。

        MySQL 的 tunnels/checkins 已声明 ON DELETE CASCADE，redeem_codes 为 SET NULL。
        """
        if self.use_mysql:
            return
        try:
            self.execute("""
                CREATE TRIGGER IF NOT EXISTS trg_users_delete
                AFTER DELETE ON users
                BEGIN
                    DELETE FROM checkins WHERE user_id = OLD.id;
                    DELETE FROM tunnels WHERE user_id = OLD.id;
                    UPDATE redeem_codes SET used_by = NULL WHERE used_by = OLD.id;
                END
            """)
        except Exception:
            pass

    def _migrate_traffic(self):
        """traffic_samples: 心跳流量时序（折线图数据源），保留 7 天"""
        if self.use_mysql:
            ddl = """CREATE TABLE IF NOT EXISTS traffic_samples (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                node_id VARCHAR(64) NOT NULL,
                up_speed BIGINT DEFAULT 0,
                down_speed BIGINT DEFAULT 0,
                cpu_usage FLOAT DEFAULT 0,
                memory_usage FLOAT DEFAULT 0,
                client_count INT DEFAULT 0,
                sampled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_traffic_time (sampled_at)
            )"""
        else:
            ddl = """CREATE TABLE IF NOT EXISTS traffic_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                node_id TEXT NOT NULL,
                up_speed INTEGER DEFAULT 0,
                down_speed INTEGER DEFAULT 0,
                cpu_usage REAL DEFAULT 0,
                memory_usage REAL DEFAULT 0,
                client_count INTEGER DEFAULT 0,
                sampled_at TEXT DEFAULT CURRENT_TIMESTAMP
            )"""
        try:
            self.execute(ddl)
        except Exception:
            pass
        # 按节点 + 时间查询/清理；sampled_at 统一存 UTC（CURRENT_TIMESTAMP）
        self._ensure_index("traffic_samples", "idx_traffic_samples_node_time",
                           "node_id, sampled_at")
        self._ensure_index("traffic_samples", "idx_traffic_time", "sampled_at")

    def _migrate_tunnels(self):
        """tunnels.custom_domain: HTTP/HTTPS 隧道的自定义域名（ChmlFrp 同款能力）"""
        col = "VARCHAR(255)" if self.use_mysql else "TEXT"
        self._add_column("tunnels", "custom_domain", col)

    def _migrate_email_codes(self):
        """email_codes: 一次性邮箱验证码（高风险操作二次确认）"""
        if self.use_mysql:
            ddl = """CREATE TABLE IF NOT EXISTS email_codes (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                user_id INT NOT NULL,
                purpose VARCHAR(32) NOT NULL,
                code_hash VARCHAR(128) NOT NULL,
                attempts INT DEFAULT 0,
                expires_at DATETIME NOT NULL,
                used TINYINT DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_email_codes_user (user_id, purpose)
            )"""
        else:
            ddl = """CREATE TABLE IF NOT EXISTS email_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                purpose TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                attempts INTEGER DEFAULT 0,
                expires_at TEXT NOT NULL,
                used INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )"""
        try:
            self.execute(ddl)
        except Exception:
            pass
        self._ensure_index("email_codes", "idx_email_codes_user", "user_id, purpose")
        # v2: 注册验证码按邮箱绑定（user 尚不存在）
        col = "VARCHAR(255)" if self.use_mysql else "TEXT"
        self._add_column("email_codes", "target", col)
        self._ensure_index("email_codes", "idx_email_codes_target", "target, purpose")

    def _migrate_roles(self):
        """users.role: 'admin' or 'user' (idempotent, SQLite and MySQL)"""
        col = "VARCHAR(16) DEFAULT 'user'" if self.use_mysql else "TEXT DEFAULT 'user'"
        self._add_column("users", "role", col)
        try:
            self.execute("UPDATE users SET role = 'admin' WHERE username = 'admin'")
            self.execute("UPDATE users SET role = 'user' WHERE role IS NULL")
        except Exception:
            pass

    def _migrate_user_profile(self):
        """users.qq / users.avatar_url: 老库缺列会导致个人资料接口 500（幂等）。"""
        qq = "VARCHAR(20) DEFAULT ''" if self.use_mysql else "TEXT DEFAULT ''"
        avatar = "VARCHAR(255) DEFAULT ''" if self.use_mysql else "TEXT DEFAULT ''"
        self._add_column("users", "qq", qq)
        self._add_column("users", "avatar_url", avatar)

    def _migrate_limits_bonus(self):
        """users.bandwidth_limit（管理员限速覆盖）与 membership_levels.points_bonus（签到积分加成%）。"""
        had_limit = self._has_column("users", "bandwidth_limit")
        self._add_column("users", "bandwidth_limit", "INTEGER DEFAULT 0")
        had_bonus = self._has_column("membership_levels", "points_bonus")
        self._add_column("membership_levels", "points_bonus", "INTEGER DEFAULT 0")
        if had_bonus:
            return
        seeds = [
            ("free", 0), ("免费", 0), ("免费档", 0),
            ("普通会员", 10), ("高级会员", 20), ("超级会员", 30), ("VIP会员", 20),
            ("定制会员", 50),
        ]
        for name, bonus in seeds:
            try:
                if name in ("free", "免费", "免费档"):
                    self.execute("UPDATE membership_levels SET points_bonus = ? WHERE level_name = ?", (bonus, name))
                else:
                    self.execute("UPDATE membership_levels SET points_bonus = ? WHERE level_name LIKE ?",
                                 (bonus, name + "%"))
            except Exception:
                pass

    def _migrate_level_scaling(self):
        """会员权益阶梯：高级=普通×2，VIP=普通×3（以普通会员为基数，幂等）。"""
        base = self.fetchone("SELECT * FROM membership_levels WHERE level_name = ?", ("普通会员",))
        if not base:
            return

        def scale(name, mult):
            row = self.fetchone("SELECT * FROM membership_levels WHERE level_name = ?", (name,))
            if not row:
                return
            def num(key):
                try:
                    return int(row.get(key) or 0)
                except (TypeError, ValueError):
                    return 0
            try:
                base_node = int(base.get("node_limit") or 0)
                base_tunnel = int(base.get("tunnel_limit") or 0)
                base_domain = int(base.get("domain_limit") or 0)
                base_ssl = int(base.get("ssl_limit") or 0)
                base_speed = int(base.get("speed_limit") or 0)
            except (TypeError, ValueError):
                return
            self.execute(
                "UPDATE membership_levels SET node_limit = ?, tunnel_limit = ?, "
                "domain_limit = ?, ssl_limit = ?, speed_limit = ? WHERE id = ?",
                (base_node * mult, base_tunnel * mult, base_domain * mult,
                 base_ssl * mult, base_speed * mult, row.get("id")))

        scale("高级会员", 2)
        scale("高级会员永久", 2)
        try:
            self.execute("UPDATE membership_levels SET level_name = ? WHERE level_name = ?",
                         ("VIP会员", "超级会员"))
            self.execute("UPDATE membership_levels SET level_name = ? WHERE level_name = ?",
                         ("VIP会员永久", "超级会员永久"))
        except Exception:
            pass
        scale("VIP会员", 3)
        scale("VIP会员永久", 3)

    def _migrate_custom_limits(self):
        """定制会员：每用户可覆盖的隧道/节点/域名/SSL 上限（0=跟随会员等级）。"""
        self._add_column("users", "custom_tunnel_limit", "INTEGER DEFAULT 0")
        self._add_column("users", "custom_node_limit", "INTEGER DEFAULT 0")
        self._add_column("users", "custom_domain_limit", "INTEGER DEFAULT 0")
        self._add_column("users", "custom_ssl_limit", "INTEGER DEFAULT 0")

    def _migrate_user_traffic(self):
        """隧道的今日流量计数 + 用户流量采样表（用于控制台真实流量图表）。"""
        self._add_column("tunnels", "traffic_up", "INTEGER DEFAULT 0")
        self._add_column("tunnels", "traffic_down", "INTEGER DEFAULT 0")
        try:
            if self.use_mysql:
                self.execute(
                    "CREATE TABLE IF NOT EXISTS user_traffic_samples ("
                    "id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, up BIGINT DEFAULT 0, "
                    "down BIGINT DEFAULT 0, sampled_at DATETIME DEFAULT CURRENT_TIMESTAMP, "
                    "INDEX idx_uts_user_time (user_id, sampled_at))")
            else:
                self.execute(
                    "CREATE TABLE IF NOT EXISTS user_traffic_samples ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, "
                    "up INTEGER DEFAULT 0, down INTEGER DEFAULT 0, "
                    "sampled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
                self.execute(
                    "CREATE INDEX IF NOT EXISTS idx_uts_user_time ON user_traffic_samples (user_id, sampled_at)")
        except Exception:
            pass

    def _migrate_background_and_heartbeat(self):
        """用户背景图；节点心跳用 epoch 秒，彻底避开时区差异。"""
        self._add_column("users", "background_url", "TEXT DEFAULT ''")
        self._add_column("nodes", "last_heartbeat_ts", "REAL")

    def _migrate_node_meta(self):
        """节点描述与允许的远程端口范围（留空=不限制）。"""
        self._add_column("nodes", "description", "TEXT DEFAULT ''")
        self._add_column("nodes", "allowed_ports", "TEXT DEFAULT ''")

    def _init_sqlite_tables(self):
        """初始化 SQLite 表"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 用户表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT,
                    token TEXT,
                    points INTEGER DEFAULT 0,
                    membership_level INTEGER DEFAULT 0,
                    membership_expiry TIMESTAMP,
                    extra_speed INTEGER DEFAULT 0,
                    extra_tunnel INTEGER DEFAULT 0,
                    avatar_url TEXT DEFAULT '',
                    qq TEXT DEFAULT '',
                    last_checkin_date DATE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 隧道表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tunnels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    tunnel_id TEXT UNIQUE NOT NULL,
                    name TEXT,
                    node_id TEXT,
                    type TEXT DEFAULT 'tcp',
                    local_ip TEXT DEFAULT '127.0.0.1',
                    local_port INTEGER,
                    remote_port INTEGER,
                    use_encryption INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'stopped',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            
            # 节点表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    node_id TEXT UNIQUE NOT NULL,
                    name TEXT,
                    host TEXT,
                    port INTEGER DEFAULT 7001,
                    auth_token TEXT,
                    node_token TEXT,
                    donated_by TEXT DEFAULT '匿名',
                    status TEXT DEFAULT 'offline',
                    cpu_usage REAL DEFAULT 0,
                    memory_usage REAL DEFAULT 0,
                    upload_speed REAL DEFAULT 0,
                    download_speed REAL DEFAULT 0,
                    total_upload INTEGER DEFAULT 0,
                    total_download INTEGER DEFAULT 0,
                    client_count INTEGER DEFAULT 0,
                    daily_upload INTEGER DEFAULT 0,
                    daily_download INTEGER DEFAULT 0,
                    last_reset_date DATE,
                    last_heartbeat TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 配置表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS panel_config (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    config_key TEXT UNIQUE NOT NULL,
                    config_value TEXT
                )
            ''')
            
            # 签到表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS checkins (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    points INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            
            # 会员等级表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS membership_levels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    level_name TEXT NOT NULL,
                    points_required INTEGER DEFAULT 0,
                    duration_days INTEGER DEFAULT 30,
                    node_limit INTEGER DEFAULT 1,
                    tunnel_limit INTEGER DEFAULT 1,
                    domain_limit INTEGER DEFAULT 0,
                    ssl_limit INTEGER DEFAULT 0,
                    speed_limit INTEGER DEFAULT 10
                )
            ''')
            
            # 兑换码表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS redeem_codes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT UNIQUE NOT NULL,
                    points INTEGER DEFAULT 0,
                    membership_level INTEGER,
                    duration_days INTEGER,
                    usage_type TEXT DEFAULT 'points',
                    speed_upgrade INTEGER DEFAULT 0,
                    tunnel_upgrade INTEGER DEFAULT 0,
                    is_used INTEGER DEFAULT 0,
                    used_by INTEGER,
                    used_at TIMESTAMP,
                    created_by INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (used_by) REFERENCES users(id)
                )
            ''')
            
            # 插入默认管理员
            import hashlib
            admin_hash = hashlib.md5('yunwang'.encode()).hexdigest()
            cursor.execute('''
                INSERT OR IGNORE INTO users (id, username, password, email, token, points)
                VALUES (1, 'admin', ?, 'admin@example.com', 'admintoken123', 999999)
            ''', (admin_hash,))
            
            # 插入默认会员等级
            cursor.execute('''
                INSERT OR IGNORE INTO membership_levels (id, level_name, points_required, duration_days, node_limit, tunnel_limit)
                VALUES 
                (1, '普通会员', 0, 30, 1, 1),
                (2, '高级会员', 100, 30, 3, 5),
                (3, 'VIP会员', 500, 30, 5, 10)
            ''')
            
            conn.commit()
    
    def _init_mysql_tables(self):
        """初始化 MySQL 表"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 用户表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    email VARCHAR(100),
                    token VARCHAR(64),
                    points INT DEFAULT 0,
                    membership_level INT DEFAULT 0,
                    membership_expiry DATETIME,
                    extra_speed INT DEFAULT 0,
                    extra_tunnel INT DEFAULT 0,
                    avatar_url VARCHAR(255) DEFAULT '',
                    qq VARCHAR(20) DEFAULT '',
                    last_checkin_date DATE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 隧道表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tunnels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    tunnel_id VARCHAR(64) UNIQUE NOT NULL,
                    name VARCHAR(100),
                    node_id VARCHAR(64),
                    type VARCHAR(20) DEFAULT 'tcp',
                    local_ip VARCHAR(50) DEFAULT '127.0.0.1',
                    local_port INT,
                    remote_port INT,
                    use_encryption TINYINT DEFAULT 0,
                    status VARCHAR(20) DEFAULT 'stopped',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            ''')
            
            # 节点表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    node_id VARCHAR(64) UNIQUE NOT NULL,
                    name VARCHAR(100),
                    host VARCHAR(50),
                    port INT DEFAULT 7001,
                    auth_token VARCHAR(255),
                    node_token VARCHAR(64),
                    donated_by VARCHAR(50) DEFAULT '匿名',
                    status VARCHAR(20) DEFAULT 'offline',
                    cpu_usage DECIMAL(5,2) DEFAULT 0,
                    memory_usage DECIMAL(5,2) DEFAULT 0,
                    upload_speed DECIMAL(10,2) DEFAULT 0,
                    download_speed DECIMAL(10,2) DEFAULT 0,
                    total_upload BIGINT DEFAULT 0,
                    total_download BIGINT DEFAULT 0,
                    client_count INT DEFAULT 0,
                    daily_upload BIGINT DEFAULT 0,
                    daily_download BIGINT DEFAULT 0,
                    last_reset_date DATE,
                    last_heartbeat TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ''')
            
            # 配置表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS panel_config (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    config_key VARCHAR(50) UNIQUE NOT NULL,
                    config_value TEXT
                )
            ''')
            
            # 签到表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS checkins (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    points INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            ''')
            
            # 会员等级表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS membership_levels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    level_name VARCHAR(50) NOT NULL,
                    points_required INT DEFAULT 0,
                    duration_days INT DEFAULT 30,
                    node_limit INT DEFAULT 1,
                    tunnel_limit INT DEFAULT 1,
                    domain_limit INT DEFAULT 0,
                    ssl_limit INT DEFAULT 0,
                    speed_limit INT DEFAULT 10
                )
            ''')
            
            # 兑换码表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS redeem_codes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    code VARCHAR(64) UNIQUE NOT NULL,
                    points INT DEFAULT 0,
                    membership_level INT,
                    duration_days INT,
                    usage_type VARCHAR(20) DEFAULT 'points',
                    speed_upgrade INT DEFAULT 0,
                    tunnel_upgrade INT DEFAULT 0,
                    is_used TINYINT DEFAULT 0,
                    used_by INT,
                    used_at TIMESTAMP,
                    created_by INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (used_by) REFERENCES users(id) ON DELETE SET NULL
                )
            ''')
            
            # 插入默认管理员
            import hashlib
            admin_hash = hashlib.md5('yunwang'.encode()).hexdigest()
            cursor.execute('''
                INSERT IGNORE INTO users (id, username, password, email, token, points)
                VALUES (1, 'admin', %s, 'admin@example.com', 'admintoken123', 999999)
            ''', (admin_hash,))
            
            # 插入默认会员等级
            cursor.execute('''
                INSERT IGNORE INTO membership_levels (id, level_name, points_required, duration_days, node_limit, tunnel_limit)
                VALUES 
                (1, '普通会员', 0, 30, 1, 1),
                (2, '高级会员', 100, 30, 3, 5),
                (3, 'VIP会员', 500, 30, 5, 10)
            ''')
            
            conn.commit()


# 全局数据库实例
db = Database()
