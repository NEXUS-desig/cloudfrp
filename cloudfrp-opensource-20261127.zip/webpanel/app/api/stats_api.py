"""Traffic time-series API for the admin dashboard charts."""
from flask import Blueprint, request, jsonify, session

from .helpers import login_required

bp = Blueprint("api_stats", __name__)


@bp.route("/api/stats/traffic")
@login_required
def traffic():
    """按 5 分钟桶聚合最近 N 小时的上下行速率（字节/秒）。hours: 1|6|24|168

    时间桶以 UTC epoch 对齐（SQLite 的 CURRENT_TIMESTAMP / 心跳采样均为 UTC）。
    """
    from ..database import db
    from config import config
    hours = request_hours(default=24)
    if config.USE_MYSQL:
        # MySQL: sampled_at 为 DATETIME，按整 300 秒向下取整
        bucket_expr = "UNIX_TIMESTAMP(sampled_at) DIV 300 * 300"
        where_sql = "sampled_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %s HOUR)"
        params = (hours,)
    else:
        bucket_expr = "(CAST(strftime('%s', sampled_at) AS INTEGER) / 300) * 300"
        where_sql = "sampled_at >= datetime('now', ?)"
        params = (f"-{hours} hours",)
    rows = db.fetchall(
        f"""SELECT {bucket_expr} AS bucket,
                  AVG(up_speed)   AS up,
                  AVG(down_speed) AS down,
                  AVG(cpu_usage)  AS cpu,
                  AVG(memory_usage) AS mem,
                  MAX(client_count) AS clients
           FROM traffic_samples
           WHERE {where_sql}
           GROUP BY bucket ORDER BY bucket ASC""",
        params)
    points = [{
        "t": int(float(r["bucket"])) * 1000,
        "up": round(float(r["up"] or 0)),
        "down": round(float(r["down"] or 0)),
        "cpu": round(float(r["cpu"] or 0), 1),
        "mem": round(float(r["mem"] or 0), 1),
        "clients": int(r["clients"] or 0),
    } for r in rows]
    total_up = sum(p["up"] for p in points)
    total_down = sum(p["down"] for p in points)
    return jsonify({
        "hours": hours,
        "points": points,
        "peak_up": max((p["up"] for p in points), default=0),
        "peak_down": max((p["down"] for p in points), default=0),
        "avg_up": round(total_up / len(points)) if points else 0,
        "avg_down": round(total_down / len(points)) if points else 0,
    })


@bp.route("/api/stats/user-traffic")
@login_required
def user_traffic():
    """当前用户的流量采样（今日累计字节），用于控制台图表。"""
    from ..database import db
    from config import config
    hours = request_hours(default=24)
    if config.USE_MYSQL:
        rows = db.fetchall(
            "SELECT up, down, UNIX_TIMESTAMP(sampled_at) * 1000 AS t "
            "FROM user_traffic_samples WHERE user_id = %s "
            "AND sampled_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %s HOUR) "
            "ORDER BY sampled_at ASC", (session["user_id"], hours))
    else:
        rows = db.fetchall(
            "SELECT up, down, CAST(strftime('%s', sampled_at) AS INTEGER) * 1000 AS t "
            "FROM user_traffic_samples WHERE user_id = ? "
            "AND sampled_at >= datetime('now', ?) ORDER BY sampled_at ASC",
            (session["user_id"], f"-{hours} hours"))
    points = [{"t": int(r.get("t") or 0), "up": int(r.get("up") or 0),
               "down": int(r.get("down") or 0)} for r in rows]
    latest = points[-1] if points else {"up": 0, "down": 0}
    return jsonify({"hours": hours, "points": points,
                    "today_up": latest["up"], "today_down": latest["down"]})


def request_hours(default=24):
    try:
        h = int(request.args.get("hours", default))
    except (TypeError, ValueError):
        return default
    return h if h in (1, 6, 24, 168) else default
