"""Tunnel API blueprint."""
import urllib.parse

from flask import Blueprint, Response, current_app, request, jsonify, session
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from ..services.user_service import user_service
from ..services.tunnel_service import tunnel_service
from .helpers import login_required, row_to_dict

bp = Blueprint("api_tunnel", __name__)

# 一条命令安装的签名有效期（面板重新打开配置页即可拿到新链接）
DEPLOY_MAX_AGE = 7 * 24 * 3600


def _deploy_serializer():
    return URLSafeTimedSerializer(current_app.secret_key, salt="cloudfrp-tunnel-deploy")


def _deploy_key(tunnel_id, user_id):
    return _deploy_serializer().dumps({"t": str(tunnel_id), "u": int(user_id)})


def _deploy_payload(tunnel_id):
    key = (request.args.get("key") or "").strip()
    if not key:
        return None
    try:
        payload = _deploy_serializer().loads(key, max_age=DEPLOY_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
    if str(payload.get("t")) != str(tunnel_id):
        return None
    return payload


def _resolve_owner(tunnel_id):
    """会话优先；没有会话时用签名 key。返回 (user_id, user_row)。"""
    if session.get("user_id"):
        user = user_service.get_by_id(session["user_id"])
        return (user["id"], user) if user else (None, None)
    payload = _deploy_payload(tunnel_id)
    if payload:
        user = user_service.get_by_id(payload.get("u"))
        return (user["id"], user) if user else (None, None)
    return None, None


@bp.route("/api/tunnels")
@login_required
def get_tunnels():
    tunnels = tunnel_service.get_user_tunnels(session["user_id"])
    return jsonify({"tunnels": [row_to_dict(t) for t in tunnels]})


@bp.route("/api/tunnels", methods=["POST"])
@login_required
def create_tunnel():
    data = request.json or {}
    success, result = tunnel_service.create_tunnel(session["user_id"], data)
    if success:
        return jsonify({"success": True, "tunnel_id": result})
    return jsonify({"error": result}), 400


@bp.route("/api/tunnels/<tunnel_id>", methods=["DELETE"])
@login_required
def delete_tunnel(tunnel_id):
    success, message = tunnel_service.delete_tunnel(session["user_id"], tunnel_id)
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 404


@bp.route("/api/tunnels/<tunnel_id>", methods=["PUT"])
@login_required
def update_tunnel(tunnel_id):
    data = request.json or {}
    success, message = tunnel_service.update_tunnel(session["user_id"], tunnel_id, data)
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 400


@bp.route("/api/tunnels/<tunnel_id>/config")
@login_required
def get_tunnel_config(tunnel_id):
    user = user_service.get_by_username(session["username"])
    config = tunnel_service.generate_config(session["user_id"], tunnel_id, user["token"])
    if config:
        return jsonify(config)
    return jsonify({"error": "隧道不存在"}), 404


@bp.route("/api/random-port")
@login_required
def get_random_port():
    node_id = (request.args.get("node_id") or "").strip()
    return jsonify({"port": tunnel_service.get_random_port(node_id or None)})


_BASH_TEMPLATE = r"""#!/usr/bin/env bash
# CloudFRP 一条命令安装（由面板生成）
set -euo pipefail
log() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
die() { printf '\033[1;31mERR\033[0m %s\n' "$*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || die "请用 root 运行：在命令前加 sudo"

log "写入 /etc/frp/frpc.toml"
mkdir -p /etc/frp
cat > /etc/frp/frpc.toml <<'CFGEOF'
@@TOML@@
CFGEOF
chmod 600 /etc/frp/frpc.toml

if ! command -v frpc >/dev/null 2>&1 && [ ! -x /usr/local/bin/frpc ]; then
  case "$(uname -m)" in
    x86_64|amd64) A=amd64 ;;
    aarch64|arm64) A=arm64 ;;
    armv7l|armv6l|armhf) A=arm ;;
    i386|i686) A=386 ;;
    *) die "不支持的架构: $(uname -m)" ;;
  esac
  VER=0.61.0
  URL="https://github.com/fatedier/frp/releases/download/v${VER}/frp_${VER}_linux_${A}.tar.gz"
  TMPD=$(mktemp -d)
  trap 'rm -rf "$TMPD"' EXIT INT TERM
  log "下载 frpc (${A}) ..."
  OK=0
  for M in "https://ghfast.top/$URL" "https://ghproxy.net/$URL" "https://gh-proxy.com/$URL" "$URL"; do
    if curl -fL --retry 2 --connect-timeout 10 --max-time 180 -o "$TMPD/frp.tgz" "$M" 2>/dev/null \
        && tar tzf "$TMPD/frp.tgz" >/dev/null 2>&1; then
      tar xzf "$TMPD/frp.tgz" -C "$TMPD"
      F=$(find "$TMPD" -type f -name frpc | head -n1)
      if [ -n "$F" ]; then install -m 0755 "$F" /usr/local/bin/frpc; OK=1; break; fi
    fi
  done
  [ "$OK" -eq 1 ] || die "frpc 下载失败，请手动下载 frp_${VER}_linux_${A}.tar.gz，把 frpc 放到 /usr/local/bin/frpc 后重试"
  log "frpc 安装完成"
fi

if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
  log "注册 systemd 服务"
  cat > /etc/systemd/system/frpc.service <<'SVCEOF'
[Unit]
Description=frpc (CloudFRP)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/frpc -c /etc/frp/frpc.toml
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
  systemctl daemon-reload
  systemctl enable frpc >/dev/null 2>&1 || true
  systemctl restart frpc
  sleep 1
  systemctl --no-pager --lines=5 status frpc || true
  echo "完成。查看日志：journalctl -u frpc -f"
else
  log "未检测到 systemd，后台运行"
  pkill -f 'frpc -c /etc/frp/frpc.toml' >/dev/null 2>&1 || true
  nohup /usr/local/bin/frpc -c /etc/frp/frpc.toml >/var/log/cloudfrp-frpc.log 2>&1 &
  echo $! > /run/cloudfrp-frpc.pid
  echo "完成。日志：tail -f /var/log/cloudfrp-frpc.log"
fi
"""

_PS1_TEMPLATE = r"""# CloudFRP Windows 一条命令安装
$ErrorActionPreference = "Stop"
$Dir = Join-Path $env:ProgramData "CloudFRP"
New-Item -ItemType Directory -Force -Path $Dir | Out-Null
$Conf = @'
@@TOML@@
'@
Set-Content -Path (Join-Path $Dir "frpc.toml") -Value $Conf -Encoding UTF8

$Exe = Join-Path $Dir "frpc.exe"
if (-not (Test-Path $Exe)) {
  $Ver = "0.61.0"
  $Zip = "https://github.com/fatedier/frp/releases/download/v$Ver/frp_${Ver}_windows_amd64.zip"
  $Mirrors = @("https://ghfast.top/$Zip", "https://ghproxy.net/$Zip", "https://gh-proxy.com/$Zip", $Zip)
  $TmpZip = Join-Path $env:TEMP "frp-windows.zip"
  $Ok = $false
  foreach ($M in $Mirrors) {
    try {
      Invoke-WebRequest -Uri $M -OutFile $TmpZip -UseBasicParsing -TimeoutSec 180
      Expand-Archive -Path $TmpZip -DestinationPath $Dir -Force
      $Found = Get-ChildItem -Path $Dir -Recurse -Filter frpc.exe | Select-Object -First 1
      if ($Found) { Move-Item -Force $Found.FullName $Exe; $Ok = $true; break }
    } catch { }
  }
  if (-not $Ok) { throw "frpc.exe 下载失败，请手动下载 frp_${Ver}_windows_amd64.zip，把 frpc.exe 放到 $Dir" }
}

$Args = '-c "' + (Join-Path $Dir "frpc.toml") + '"'
Get-Process frpc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
try {
  $Action = New-ScheduledTaskAction -Execute $Exe -Argument $Args
  $Trigger = New-ScheduledTaskTrigger -AtLogOn
  Register-ScheduledTask -TaskName "CloudFRP-Tunnel" -Action $Action -Trigger $Trigger -RunLevel Highest -Force | Out-Null
  $Note = "已注册登录自启任务 CloudFRP-Tunnel"
} catch {
  $Note = "未能注册计划任务（请以管理员身份运行）"
}
Start-Process -FilePath $Exe -ArgumentList $Args -WindowStyle Hidden
Write-Host "完成：frpc 已启动。$Note" -ForegroundColor Green
Write-Host "配置文件：$(Join-Path $Dir 'frpc.toml')"
"""


@bp.route("/api/tunnels/<tunnel_id>/install.sh")
def install_script(tunnel_id):
    """一条命令安装（会话或 7 天有效的签名 key）。"""
    user_id, user = _resolve_owner(tunnel_id)
    if not user:
        return jsonify({"error": "链接已失效，请在面板重新打开隧道配置获取新命令"}), 403
    config = tunnel_service.generate_config(user_id, tunnel_id, user["token"])
    if not config:
        return jsonify({"error": "隧道不存在"}), 404
    script = _BASH_TEMPLATE.replace("@@TOML@@", config.get("toml", ""))
    return Response(script, mimetype="text/x-shellscript",
                    headers={"Content-Disposition": f'attachment; filename="cloudfrp-{tunnel_id}.sh"',
                             "Cache-Control": "no-store"})


@bp.route("/api/tunnels/<tunnel_id>/install.ps1")
def install_ps1(tunnel_id):
    user_id, user = _resolve_owner(tunnel_id)
    if not user:
        return jsonify({"error": "链接已失效，请在面板重新打开隧道配置获取新命令"}), 403
    config = tunnel_service.generate_config(user_id, tunnel_id, user["token"])
    if not config:
        return jsonify({"error": "隧道不存在"}), 404
    script = _PS1_TEMPLATE.replace("@@TOML@@", config.get("toml", ""))
    return Response(script, mimetype="text/plain",
                    headers={"Content-Disposition": f'attachment; filename="cloudfrp-{tunnel_id}.ps1"',
                             "Cache-Control": "no-store"})


@bp.route("/api/tunnels/<tunnel_id>/deploy")
@login_required
def deploy_commands(tunnel_id):
    if not tunnel_service.get_tunnel_by_id(tunnel_id, session["user_id"]):
        return jsonify({"error": "隧道不存在"}), 404
    base = request.host_url.rstrip("/")
    key = urllib.parse.quote(_deploy_key(tunnel_id, session["user_id"]), safe="")
    linux = f'curl -fsSL "{base}/api/tunnels/{tunnel_id}/install.sh?key={key}" | sudo bash'
    windows = ("powershell -NoProfile -ExecutionPolicy Bypass -Command "
               f"\"irm '{base}/api/tunnels/{tunnel_id}/install.ps1?key={key}' | iex\"")
    return jsonify({"linux": linux, "windows": windows, "expires_days": DEPLOY_MAX_AGE // 86400})

