"""Points, check-in, membership and redeem-code API blueprint."""
from flask import Blueprint, request, jsonify, session

from ..services.points_service import points_service, redeem_code_service
from .helpers import login_required, admin_required, row_to_dict
from .captcha_api import captcha_ok

bp = Blueprint("api_points", __name__)


@bp.route("/api/checkin", methods=["POST"])
@login_required
def checkin():
    data = request.get_json(silent=True) or {}
    if not captcha_ok(data.get("captcha_id")):
        return jsonify({"success": False, "message": "请完成图片验证码"}), 403
    success, result = points_service.checkin(session["user_id"])
    if success:
        return jsonify({"success": True, **result})
    return jsonify({"success": False, "message": result})


@bp.route("/api/checkin/stats")
@login_required
def checkin_stats():
    return jsonify(points_service.get_checkin_stats(session["user_id"]))


@bp.route("/api/user/points")
@login_required
def user_points():
    return jsonify(points_service.get_user_points(session["user_id"]) or {})


@bp.route("/api/user/stats")
@login_required
def user_stats():
    stats = points_service.get_user_points(session["user_id"]) or {}
    from ..services.user_service import user_service
    return jsonify({**user_service.get_user_stats(session["user_id"]), **stats})


@bp.route("/api/membership/levels")
def membership_levels():
    levels = points_service.get_membership_levels()
    return jsonify({"levels": [row_to_dict(l) for l in levels]})


@bp.route("/api/membership/exchange", methods=["POST"])
@login_required
def membership_exchange():
    data = request.json or {}
    success, message = points_service.exchange_membership(
        session["user_id"], data.get("level_id"))
    return jsonify({"success": success, "message": message})


# ---- redeem codes -----------------------------------------------------------
@bp.route("/api/redeem-code", methods=["POST"])
@login_required
def redeem_code():
    data = request.json or {}
    success, message = redeem_code_service.use_code(session["user_id"], data.get("code"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/admin/redeem-codes")
@admin_required
def get_redeem_codes():
    codes = redeem_code_service.get_all_codes()
    return jsonify({"codes": [row_to_dict(c) for c in codes]})


@bp.route("/api/admin/redeem-codes", methods=["POST"])
@admin_required
def create_redeem_code():
    data = request.json or {}
    success, result = redeem_code_service.create_code(data, session["user_id"])
    if success:
        return jsonify({"success": True, "code": result})
    return jsonify({"success": False, "message": result})


@bp.route("/api/admin/redeem-codes/<int:code_id>", methods=["DELETE"])
@admin_required
def delete_redeem_code(code_id):
    success, message = redeem_code_service.delete_code(code_id)
    return jsonify({"success": success, "message": message})
