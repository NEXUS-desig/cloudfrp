"""API blueprint package.

Registers every API blueprint onto the Flask app with a single call:
    from app.api import register_api_blueprints
    register_api_blueprints(app)
"""
from . import (user_api, tunnel_api, node_api, frps_api, points_api,
               admin_api, email_api, stats_api, health_api, captcha_api)

_BLUEPRINTS = (
    captcha_api.bp,
    health_api.bp,
    user_api.bp,
    tunnel_api.bp,
    node_api.bp,
    frps_api.bp,
    points_api.bp,
    admin_api.bp,
    email_api.bp,
    stats_api.bp,
)


def register_api_blueprints(app):
    for bp in _BLUEPRINTS:
        app.register_blueprint(bp)
    return app
