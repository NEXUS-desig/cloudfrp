"""Node API blueprint (registration, heartbeat, admin CRUD, installer)."""
import ipaddress
import os
import re
import secrets
import threading
import time
from urllib.parse import urlsplit, urlunsplit

from flask import Blueprint, Response, request, jsonify, session

from ..services.node_service import node_service, _valid_host
from .helpers import login_required, admin_required

bp = Blueprint("api_node", __name__)

# ── 未认证注册的限流（按 IP，默认 5 次/分钟） ───────────────────────────────
_REGISTER_WINDOW = 60
try:
    _REGISTER_LIMIT = max(1, int(os.environ.get("NODE_REGISTER_RATE", "5") or 5))
except (TypeError, ValueError):
    _REGISTER_LIMIT = 5
_register_buckets = {}
_register_lock = threading.Lock()

# 用户输入中绝对不允许出现的字符（shell / systemd EnvironmentFile / TOML 注入面）
_FORBIDDEN_CHARS = set("\"'`\\$;&|<>")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_HOST_ONLY_RE = re.compile(r"^[A-Za-z0-9._:\-]+$")
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9._\-]{1,128}$")


def _client_ip():
    """限流用客户端 IP。

    Waitress 默认会剥离 X-Forwarded-For，因此本机反代/测试场景下额外支持
    X-CloudFRP-Client-IP / X-Real-IP。仅在直连对端是回环地址时才采信这些头，
    外部客户端无法伪造。
    """
    remote = request.remote_addr or "unknown"
    if remote in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
        for header in ("X-CloudFRP-Client-IP", "X-Real-IP", "X-Forwarded-For"):
            forwarded = (request.headers.get(header) or "").split(",")[0].strip()
            if forwarded:
                try:
                    ipaddress.ip_address(forwarded)
                    return forwarded
                except ValueError:
                    continue
    return remote


def _check_registration_rate(ip):
    """返回 0 表示放行，否则返回建议重试秒数。"""
    now = time.time()
    with _register_lock:
        bucket = _register_buckets.setdefault(ip, [])
        bucket[:] = [ts for ts in bucket if now - ts < _REGISTER_WINDOW]
        if len(bucket) >= _REGISTER_LIMIT:
            return max(1, int(_REGISTER_WINDOW - (now - bucket[0])) + 1)
        bucket.append(now)
        if len(_register_buckets) > 1024:
            stale = [key for key, hits in _register_buckets.items()
                     if not hits or now - hits[-1] > _REGISTER_WINDOW]
            for key in stale:
                _register_buckets.pop(key, None)
    return 0


def _rate_limited_response(retry_after):
    resp = jsonify({
        "success": False,
        "error": "注册请求过于频繁，请稍后再试",
        "code": "RATE_LIMITED",
        "retry_after": retry_after,
    })
    resp.status_code = 429
    resp.headers["Retry-After"] = str(retry_after)
    return resp


# ── 安装脚本参数校验 ─────────────────────────────────────────────────────────
def _validate_name(raw):
    name = (raw or "").strip()
    if len(name) > 100:
        raise ValueError("节点名称过长（最多 100 字符）")
    if _CONTROL_RE.search(name):
        raise ValueError("节点名称包含控制字符")
    if any(ch in _FORBIDDEN_CHARS for ch in name):
        raise ValueError("节点名称包含不安全字符（不允许引号、反斜杠、$、;、&、|、<、>）")
    return name


def _validate_host(raw):
    host = (raw or "").strip()
    if not host:
        return ""              # 允许留空，由安装脚本自动探测公网 IP
    if not _valid_host(host):
        raise ValueError("节点地址 host 格式无效")
    return host


def _validate_port(raw):
    try:
        port = int(str(raw if raw not in (None, "") else "7000"))
    except (TypeError, ValueError):
        raise ValueError("端口必须为整数")
    if port < 1 or port > 65535:
        raise ValueError("端口号必须在 1-65535 之间")
    return port


def _validate_panel(raw):
    panel = (raw or "").strip()
    if not panel:
        raise ValueError("面板地址不能为空")
    if _CONTROL_RE.search(panel) or any(ch.isspace() for ch in panel):
        raise ValueError("面板地址包含空白或控制字符")
    if any(ch in _FORBIDDEN_CHARS for ch in panel):
        raise ValueError("面板地址包含不安全字符")
    parts = urlsplit(panel)
    if parts.scheme not in ("http", "https"):
        raise ValueError("面板地址必须以 http:// 或 https:// 开头")
    if parts.username or parts.password:
        raise ValueError("面板地址不允许包含用户名/密码")
    if parts.query or parts.fragment:
        raise ValueError("面板地址不允许包含查询参数或锚点")
    host = parts.hostname or ""
    if not host or not _valid_host(host):
        raise ValueError("面板地址主机名无效")
    try:
        port = parts.port
    except ValueError:
        raise ValueError("面板地址端口无效")
    path = parts.path or ""
    if path and not re.match(r"^/[A-Za-z0-9._~/\-]*$", path):
        raise ValueError("面板地址路径包含不安全字符")
    if ".." in path.split("/"):
        raise ValueError("面板地址路径不允许包含 ..")
    netloc = host
    if ":" in host and not host.startswith("["):
        netloc = "[%s]" % host
    if port:
        netloc = "%s:%d" % (netloc, port)
    return urlunsplit((parts.scheme, netloc, path.rstrip("/"), "", ""))


def _safe_frp_token(raw):
    token = str(raw or "").strip()
    return token if _SAFE_TOKEN_RE.match(token) else None


def _load_embedded_client():
    """内嵌客户端优先取面板内自维护的副本，其次取项目捐赠目录（只读参考）。"""
    api_dir = os.path.dirname(os.path.abspath(__file__))
    webpanel_dir = os.path.dirname(os.path.dirname(api_dir))
    project_root = os.path.dirname(webpanel_dir)
    candidates = (
        os.path.join(webpanel_dir, "app", "static", "client", "node_client.py"),
        os.path.join(project_root, "cloudfrp节点捐赠", "node_client.py"),
    )
    for path in candidates:
        try:
            with open(path, encoding="utf-8") as fh:
                content = fh.read()
            if content.strip():
                return content
        except OSError:
            continue
    return ""


# ── 节点接口 ─────────────────────────────────────────────────────────────────
@bp.route("/api/nodes")
@login_required
def get_nodes():
    nodes = node_service.get_all_nodes()
    from ..services.user_service import user_service as _us
    return jsonify({"nodes": nodes, "is_admin": _us.is_admin(session["username"])})


@bp.route("/api/nodes/stats")
@login_required
def get_nodes_stats():
    return jsonify(node_service.get_stats())


@bp.route("/api/nodes/register", methods=["POST"])
def register_node():
    """Register a donated node (called by the node client, unauthenticated)."""
    data = request.get_json(silent=True) or {}

    if not data.get("name") or not data.get("host"):
        return jsonify({"success": False, "error": "缺少必填字段 name 或 host"}), 400

    host = data.get("host", request.remote_addr)
    try:
        port = int(data.get("port", 7001))
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "端口必须为整数"}), 400
    if port < 1 or port > 65535:
        return jsonify({"success": False, "error": "端口号必须在 1-65535 之间"}), 400

    node_id = str(data.get("node_id") or secrets.token_hex(16))

    # 已注册节点携带正确 node_token 的更新请求不计入限流，保证重跑安装脚本不受影响
    provided_token = str(data.get("node_token") or "")
    existing = node_service.get_node_by_id(node_id) if data.get("node_id") else None
    is_authenticated_update = bool(
        existing and provided_token
        and secrets.compare_digest(provided_token, str(existing.get("node_token") or "")))
    if not is_authenticated_update:
        retry_after = _check_registration_rate(_client_ip())
        if retry_after:
            return _rate_limited_response(retry_after)

    success, message, node_token = node_service.register_node(node_id, {
        "name": (data.get("name") or "").strip()[:100],
        "host": str(host).strip(),
        "port": port,
        "auth_token": data.get("auth_token", ""),
        "donated_by": (data.get("donated_by") or data.get("name") or "匿名").strip()[:100],
        "node_token": data.get("node_token", ""),
    })
    if success:
        node = node_service.get_node_by_id(node_id) or {}
        return jsonify({"success": True, "node_id": node_id,
                        "node_token": node_token, "message": message,
                        "approved": bool(node.get("approved"))})
    return jsonify({"success": False, "error": message}), 400


# legacy alias — POST /api/nodes also maps to registration
@bp.route("/api/nodes", methods=["POST"])
def register_node_alias():
    return register_node()


@bp.route("/api/nodes/<node_id>/heartbeat", methods=["POST"])
def node_heartbeat(node_id):
    """Node heartbeat, authenticated by node_token."""
    data = request.get_json(silent=True) or {}
    node_token = data.get("node_token", "")
    if not node_token:
        return jsonify({"success": False, "error": "缺少节点认证令牌 node_token"}), 401

    stats = data.get("stats", {}) or {}
    try:
        heartbeat_data = {
            "cpu_usage": float(stats.get("cpu_usage", 0)),
            "memory_usage": float(stats.get("memory_usage", 0)),
            "upload_speed": float(stats.get("upload_speed", 0)),
            "download_speed": float(stats.get("download_speed", 0)),
            "total_upload": int(stats.get("total_upload", 0)),
            "total_download": int(stats.get("total_download", 0)),
            "client_count": int(stats.get("client_count", 0)),
            "frps_healthy": bool(stats.get("frps_healthy", False)),
        }
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "统计数据格式错误"}), 400

    proxies_present = "running_proxies" in data
    running_proxies = data.get("running_proxies")
    if proxies_present and not isinstance(running_proxies, list):
        return jsonify({"success": False, "error": "running_proxies 必须为数组"}), 400
    proxy_traffic = data.get("proxy_traffic")
    if proxy_traffic is not None and not isinstance(proxy_traffic, dict):
        return jsonify({"success": False, "error": "proxy_traffic 必须为对象"}), 400

    result = node_service.update_heartbeat(
        node_id, node_token, heartbeat_data,
        running_proxies=running_proxies if proxies_present else None,
        proxy_traffic=proxy_traffic)
    if result is True:
        return jsonify({"success": True})
    if result == "invalid_token":
        return jsonify({"success": False, "error": "节点认证令牌无效",
                        "code": "INVALID_TOKEN"}), 401
    if result == "not_found":
        return jsonify({"success": False, "error": "节点不存在，请先注册",
                        "code": "NODE_NOT_FOUND"}), 404
    return jsonify({"success": False, "error": "心跳处理失败"}), 500


@bp.route("/api/nodes/<node_id>", methods=["DELETE"])
@admin_required
def delete_node(node_id):
    success, message = node_service.delete_node(node_id, session["username"])
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 403


@bp.route("/api/nodes/<node_id>/name", methods=["PUT"])
@login_required
def update_node_name(node_id):
    data = request.json or {}
    success, message = node_service.update_name(node_id, data.get("name", ""),
                                                session["username"])
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 403


TEMPLATE = r"""#!/usr/bin/env bash
# CloudFRP 捐赠节点一键安装（由面板生成，无需任何参数）
# 用法：sudo bash cloudfrp-node-install.sh
# 可选：--uninstall（卸载）  --regenerate-token（更换 FRP Token）  --skip-frps（复用已有 frps）  --insecure（HTTPS 自签证书）
set -euo pipefail

PANEL='@@PANEL@@'
HOST='@@HOST@@'
NODE_NAME='@@NAME@@'
FRPS_PORT='@@PORT@@'
FRPS_TOKEN='@@TOKEN@@'
FRP_VER="0.61.0"

ETC_DIR=/etc/cloudfrp
STATE_DIR=/var/lib/cloudfrp
ENV_FILE="$ETC_DIR/node.env"
FRPS_CONFIG="$ETC_DIR/frps.toml"
NODE_SERVICE=/etc/systemd/system/cloudfrp-node.service
FRPS_SERVICE=/etc/systemd/system/frps.service
CLIENT_DST=/opt/cloudfrp/node_client.py
RUN_WRAPPER=/opt/cloudfrp/run-node.sh
INSTALL_MARKER="$ETC_DIR/.installed-frps"

log()  { printf '\033[1;34m==> \033[0m%s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[✗]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "请用 root 运行：sudo bash $0"

have_systemd() {
  [ -d /run/systemd/system ] || return 1
  command -v systemctl >/dev/null 2>&1 || return 1
  systemctl show -p Version --value >/dev/null 2>&1
}
SYSTEMD=0
have_systemd && SYSTEMD=1

UNINSTALL=0; REGEN=0; SKIP_FRPS=0; INSECURE=0
for arg in "$@"; do
  case "$arg" in
    --uninstall) UNINSTALL=1 ;;
    --regenerate-token) REGEN=1 ;;
    --skip-frps) SKIP_FRPS=1 ;;
    --insecure) INSECURE=1 ;;
    -h|--help) sed -n '2,8p' "$0"; exit 0 ;;
    *) warn "忽略未知参数：$arg" ;;
  esac
done

managed_frps_service() {
  [ -f "$FRPS_SERVICE" ] && grep -q 'Managed-by: cloudfrp-installer' "$FRPS_SERVICE"
}

if [ "$UNINSTALL" -eq 1 ]; then
  log "停止并移除 CloudFRP 节点服务..."
  if [ "$SYSTEMD" -eq 1 ]; then
    systemctl disable --now cloudfrp-node.service 2>/dev/null || true
  elif [ -f "$CLIENT_DST" ]; then
    "$PYBIN" "$CLIENT_DST" --stop >/dev/null 2>&1 || true
  fi
  if managed_frps_service; then
    [ "$SYSTEMD" -eq 1 ] && systemctl disable --now frps.service 2>/dev/null || true
    rm -f "$FRPS_SERVICE"
    if [ -f "$INSTALL_MARKER" ]; then rm -f /usr/local/bin/frps; fi
  fi
  rm -f "$NODE_SERVICE"
  [ "$SYSTEMD" -eq 1 ] && systemctl daemon-reload 2>/dev/null || true
  if command -v crontab >/dev/null 2>&1; then
    crontab -l 2>/dev/null | grep -v 'cloudfrp-node' | crontab - 2>/dev/null || true
  fi
  rm -rf "$ETC_DIR" /opt/cloudfrp "$STATE_DIR"
  log "已卸载节点客户端、配置与由本脚本安装的 frps。"
  log "如需撤销防火墙放行：ufw delete allow ${FRPS_PORT}/tcp 或 firewall-cmd --permanent --remove-port=${FRPS_PORT}/tcp"
  exit 0
fi

case "$FRPS_PORT" in
  ''|*[!0-9]*) die "FRPS 端口无效：$FRPS_PORT" ;;
esac
if [ "$FRPS_PORT" -lt 1 ] || [ "$FRPS_PORT" -gt 65535 ]; then
  die "FRPS 端口必须在 1-65535 之间：$FRPS_PORT"
fi
[ -n "$FRPS_TOKEN" ] || die "FRP Token 为空，请回到面板重新生成安装脚本"

# 配置/状态目录必须在写入 marker、下载 frps 之前就存在（set -e 下 touch 不会自己建目录）
install -d -m 0755 "$ETC_DIR" "$STATE_DIR" /opt/cloudfrp

# ── 幂等：替换前先停止已有服务，并保留既有 Token ────────────────────────────
log "停止已有服务（替换前先停止，避免端口冲突）..."
if [ "$SYSTEMD" -eq 1 ]; then
  systemctl stop cloudfrp-node.service 2>/dev/null || true
  if managed_frps_service; then systemctl stop frps.service 2>/dev/null || true; fi
elif [ -f "$CLIENT_DST" ]; then
  "$PYBIN" "$CLIENT_DST" --stop >/dev/null 2>&1 || true
fi

if [ "$REGEN" -eq 0 ] && [ -f "$ENV_FILE" ]; then
  OLD_TOKEN=$(sed -n 's/^CLOUDFRP_TOKEN="\{0,1\}\([^"#]*\)"\{0,1\}[[:space:]]*$/\1/p' "$ENV_FILE" | head -n1)
  if [ -n "${OLD_TOKEN:-}" ]; then
    log "沿用已有 FRP Token（如需更换请加 --regenerate-token）"
    FRPS_TOKEN="$OLD_TOKEN"
  fi
fi

# ── 依赖：curl 必需；python3-psutil 可选（缺失也能运行） ─────────────────────
if ! command -v curl >/dev/null 2>&1; then
  log "安装 curl ..."
  if command -v apt-get >/dev/null 2>&1; then apt-get update -qq && apt-get install -y curl
  elif command -v dnf >/dev/null 2>&1; then dnf install -y curl
  elif command -v yum >/dev/null 2>&1; then yum install -y curl
  else die "缺少 curl 且无法自动安装，请先安装 curl 后重试"; fi
fi
if ! command -v python3 >/dev/null 2>&1; then
  log "安装 python3 ..."
  if command -v apt-get >/dev/null 2>&1; then apt-get update -qq && apt-get install -y python3
  elif command -v dnf >/dev/null 2>&1; then dnf install -y python3
  elif command -v yum >/dev/null 2>&1; then yum install -y python3
  else die "缺少 python3 且无法自动安装"; fi
fi
PYBIN=$(command -v python3)
[ -x "$PYBIN" ] || die "python3 路径无效：$PYBIN"
if ! "$PYBIN" -c 'import psutil' >/dev/null 2>&1; then
  log "安装 python3-psutil（可选，失败不影响心跳）..."
  { command -v apt-get >/dev/null 2>&1 && apt-get install -y python3-psutil; } \
    || { command -v dnf >/dev/null 2>&1 && dnf install -y python3-psutil; } \
    || { command -v yum >/dev/null 2>&1 && yum install -y python3-psutil; } \
    || "$PYBIN" -m pip install --quiet psutil \
    || warn "psutil 安装失败，客户端将使用 /proc 回退采集"
fi

# ── 节点地址自动探测 ─────────────────────────────────────────────────────────
if [ -z "$HOST" ]; then
  log "自动探测公网 IP..."
  HOST=$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null \
      || curl -4 -fsS --max-time 8 https://ifconfig.me/ip 2>/dev/null \
      || hostname -I 2>/dev/null | awk '{print $1}')
fi
[ -n "$HOST" ] || die "无法探测公网 IP，请在面板填写节点地址后重新下载脚本"
log "节点地址：$HOST   面板：$PANEL   端口：$FRPS_PORT"

# ── 面板健康检查（脚本可验证面板 URL 是否可达） ──────────────────────────────
PANEL_CURL=(-fsS --connect-timeout 5 --max-time 10)
if [ "$INSECURE" -eq 1 ]; then PANEL_CURL+=(-k); fi
health_ok() {
  local body
  body=$(curl "${PANEL_CURL[@]}" "${PANEL}/api/health" 2>/dev/null || true)
  printf '%s' "$body" | grep -q '"ok"[[:space:]]*:[[:space:]]*true'
}
log "检查面板健康状态 ${PANEL}/api/health ..."
HEALTH=0
for _ in 1 2 3; do
  if health_ok; then HEALTH=1; break; fi
  sleep 2
done
if [ "$HEALTH" -ne 1 ]; then
  die "无法访问面板 ${PANEL}/api/health。请确认：1) 地址与端口正确；2) 本机可出站访问面板；3) 面板已启动。修复后重新运行本脚本。"
fi

# ── 判断是否需要安装/启动 frps ───────────────────────────────────────────────
port_in_use() {
  if command -v ss >/dev/null 2>&1; then
    ss -ltn "sport = :$1" 2>/dev/null | grep -q LISTEN
  elif command -v netstat >/dev/null 2>&1; then
    netstat -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]$1\$"
  else
    return 1
  fi
}

MANAGE_FRPS=1
if [ "$SKIP_FRPS" -eq 1 ]; then MANAGE_FRPS=0; fi
if port_in_use "$FRPS_PORT"; then
  if command -v frps >/dev/null 2>&1 \
      || { command -v pgrep >/dev/null 2>&1 && pgrep -x frps >/dev/null 2>&1; }; then
    log "端口 ${FRPS_PORT} 已有 frps 在监听，复用现有 frps（不创建 frps.service）"
    MANAGE_FRPS=0
  else
    die "端口 ${FRPS_PORT} 已被其他进程占用。请释放该端口，或在面板换一个端口重新生成脚本。"
  fi
fi
if [ "$MANAGE_FRPS" -eq 0 ] && ! command -v frps >/dev/null 2>&1; then
  warn "未检测到 frps 可执行文件；节点会上报心跳，但隧道无法转发流量"
fi

# ── frps 管理 API（仅托管模式）：127.0.0.1 随机端口 + 随机凭据 ──────────────
# 节点客户端用它读取当前已连上的 proxy 列表，心跳上报给面板更新隧道在线状态。
FRPS_ADMIN_PORT=""
FRPS_ADMIN_USER=""
FRPS_ADMIN_PASS=""
if [ "$MANAGE_FRPS" -eq 1 ]; then
  if [ -f "$ENV_FILE" ]; then
    FRPS_ADMIN_PORT=$(sed -n 's/^CLOUDFRP_FRPS_ADMIN_PORT="\{0,1\}\([^"#]*\)"\{0,1\}[[:space:]]*$/\1/p' "$ENV_FILE" | head -n1)
    FRPS_ADMIN_USER=$(sed -n 's/^CLOUDFRP_FRPS_ADMIN_USER="\{0,1\}\([^"#]*\)"\{0,1\}[[:space:]]*$/\1/p' "$ENV_FILE" | head -n1)
    FRPS_ADMIN_PASS=$(sed -n 's/^CLOUDFRP_FRPS_ADMIN_PASS="\{0,1\}\([^"#]*\)"\{0,1\}[[:space:]]*$/\1/p' "$ENV_FILE" | head -n1)
  fi
  case "$FRPS_ADMIN_PORT" in ''|*[!0-9]*) FRPS_ADMIN_PORT="" ;; esac
  if [ -z "$FRPS_ADMIN_PORT" ] || [ "$FRPS_ADMIN_PORT" -lt 1 ] || [ "$FRPS_ADMIN_PORT" -gt 65535 ]; then
    FRPS_ADMIN_PORT=""
    for cand in $(seq 7400 7599); do
      if command -v ss >/dev/null 2>&1; then
        ss -ltn 2>/dev/null | grep -q ":$cand " || { FRPS_ADMIN_PORT=$cand; break; }
      else
        FRPS_ADMIN_PORT=$cand
        break
      fi
    done
    [ -n "$FRPS_ADMIN_PORT" ] || FRPS_ADMIN_PORT=7400
  fi
  [ -n "$FRPS_ADMIN_USER" ] || FRPS_ADMIN_USER="cf$(( RANDOM % 9000 + 1000 ))"
  if [ -z "$FRPS_ADMIN_PASS" ]; then
    FRPS_ADMIN_PASS=$(head -c 96 /dev/urandom | tr -dc 'A-Fa-f0-9' | head -c 24)
    [ -n "$FRPS_ADMIN_PASS" ] || FRPS_ADMIN_PASS=$(date +%s%N | tail -c 25)
  fi
fi

# ── 安装 frps（已有则跳过；优先面板，其次镜像） ──────────────────────────────
is_elf() {
  [ -f "$1" ] || return 1
  [ "$(stat -c %s "$1" 2>/dev/null || echo 0)" -ge 5000000 ] || return 1
  [ "$(head -c 4 "$1" | od -An -tx1 | tr -d ' \n')" = "7f454c46" ]
}
is_gzip() {
  [ -f "$1" ] || return 1
  [ "$(stat -c %s "$1" 2>/dev/null || echo 0)" -ge 5000000 ] || return 1
  [ "$(head -c 2 "$1" | od -An -tx1 | tr -d ' \n')" = "1f8b" ]
}

if [ "$MANAGE_FRPS" -eq 1 ] && ! command -v frps >/dev/null 2>&1; then
  case "$(uname -m)" in
    x86_64|amd64)  FRP_ARCH=amd64 ;;
    aarch64|arm64) FRP_ARCH=arm64 ;;
    armv7l|armv6l|armhf) FRP_ARCH=arm ;;
    i386|i686|x86) FRP_ARCH=386 ;;
    *) die "不支持的 CPU 架构：$(uname -m)。请手动安装 frps 到 /usr/local/bin/frps 后重跑。" ;;
  esac
  FRP_FILE="frp_${FRP_VER}_linux_${FRP_ARCH}.tar.gz"
  GH_URL="https://github.com/fatedier/frp/releases/download/v${FRP_VER}/${FRP_FILE}"
  TMPD=$(mktemp -d)
  cleanup() { rm -rf "$TMPD"; }
  trap cleanup EXIT INT TERM
  DL_OK=0

  log "尝试从面板获取 frps (${FRP_ARCH}) ..."
  if curl "${PANEL_CURL[@]}" -o "$TMPD/frps.bin" "${PANEL}/static/bin/frps-linux-${FRP_ARCH}" 2>/dev/null \
      && is_elf "$TMPD/frps.bin"; then
    install -m 0755 "$TMPD/frps.bin" /usr/local/bin/frps
    touch "$INSTALL_MARKER" 2>/dev/null || true
    DL_OK=1
    log "frps 安装完成（来自面板）"
  else
    warn "面板未提供可用的 frps（或架构不匹配），改用镜像下载"
  fi

  if [ "$DL_OK" -eq 0 ]; then
    MIRRORS=(
      "https://ghfast.top/${GH_URL}"
      "https://ghproxy.net/${GH_URL}"
      "https://gh-proxy.com/${GH_URL}"
      "https://mirror.ghproxy.com/${GH_URL}"
      "${GH_URL}"
    )
    for url in "${MIRRORS[@]}"; do
      log "尝试下载：$url"
      rm -f "$TMPD/frp.tgz"
      if curl -fL --retry 3 --retry-delay 2 --connect-timeout 10 --max-time 300 \
            -o "$TMPD/frp.tgz" "$url" 2>/dev/null \
          && is_gzip "$TMPD/frp.tgz" \
          && tar tzf "$TMPD/frp.tgz" >/dev/null 2>&1; then
        tar xzf "$TMPD/frp.tgz" -C "$TMPD"
        FOUND=$(find "$TMPD" -type f -name frps | head -n1)
        if [ -n "$FOUND" ] && is_elf "$FOUND"; then
          install -m 0755 "$FOUND" /usr/local/bin/frps
          touch "$INSTALL_MARKER" 2>/dev/null || true
          DL_OK=1
          log "frps 安装完成（来自镜像）"
          break
        fi
        warn "下载内容校验失败（可能被网关替换为 HTML），继续尝试下一个镜像"
      fi
    done
  fi

  if [ "$DL_OK" -ne 1 ]; then
    cat >&2 <<EOF_MANUAL

[✗] frps 下载失败（面板与镜像均不可达或校验不通过）。

手动解决方法：
  1. 在任意可上网的机器下载：
     https://github.com/fatedier/frp/releases/download/v${FRP_VER}/${FRP_FILE}
  2. 解压后取其中的 frps，上传到本机 /usr/local/bin/frps
  3. chmod +x /usr/local/bin/frps
  4. 重新运行本脚本（检测到 frps 后会跳过下载）

EOF_MANUAL
    exit 1
  fi
fi

# ── 写入客户端与配置（Token 只进 EnvironmentFile，不放到命令行） ─────────────
install -d -m 0755 /opt/cloudfrp "$ETC_DIR" "$STATE_DIR"
umask 077
cat > "$CLIENT_DST" <<'PYEOF_EMBED'
@@CLIENT_PY@@
PYEOF_EMBED
chmod 0755 "$CLIENT_DST"

if [ "$MANAGE_FRPS" -eq 1 ]; then
  cat > "$FRPS_CONFIG" <<EOF_FRPS
# Managed-by: cloudfrp-installer
bindAddr = "0.0.0.0"
bindPort = ${FRPS_PORT}
auth.token = "${FRPS_TOKEN}"
webServer.addr = "127.0.0.1"
webServer.port = ${FRPS_ADMIN_PORT}
webServer.user = "${FRPS_ADMIN_USER}"
webServer.password = "${FRPS_ADMIN_PASS}"
transport.maxPoolCount = 1000
transport.tcpMux = true
log.level = "info"
log.maxDays = 3
EOF_FRPS
  chmod 0600 "$FRPS_CONFIG"
fi

{
  printf 'CLOUDFRP_PANEL="%s"\n' "$PANEL"
  printf 'CLOUDFRP_HOST="%s"\n' "$HOST"
  printf 'CLOUDFRP_PORT="%s"\n' "$FRPS_PORT"
  printf 'CLOUDFRP_NAME="%s"\n' "$NODE_NAME"
  printf 'CLOUDFRP_TOKEN="%s"\n' "$FRPS_TOKEN"
  printf 'CLOUDFRP_INTERVAL="10"\n'
  # frps 始终由独立 systemd 服务托管（或复用系统已有 frps），客户端只负责心跳
  printf 'CLOUDFRP_MANAGE_FRPS="0"\n'
  printf 'CLOUDFRP_STATE_DIR="%s"\n' "$STATE_DIR"
  if [ "$MANAGE_FRPS" -eq 1 ]; then
    printf 'CLOUDFRP_CONFIG="%s"\n' "$FRPS_CONFIG"
    printf 'CLOUDFRP_FRPS_ADMIN_PORT="%s"\n' "$FRPS_ADMIN_PORT"
    printf 'CLOUDFRP_FRPS_ADMIN_USER="%s"\n' "$FRPS_ADMIN_USER"
    printf 'CLOUDFRP_FRPS_ADMIN_PASS="%s"\n' "$FRPS_ADMIN_PASS"
  fi
  if [ "$INSECURE" -eq 1 ]; then
    printf 'CLOUDFRP_INSECURE="1"\n'
  fi
} > "$ENV_FILE"
chmod 0600 "$ENV_FILE"

# ── systemd：frps（仅托管时）与节点客户端 ────────────────────────────────────
FRPS_AFTER=""
if [ "$MANAGE_FRPS" -eq 1 ]; then
  FRPS_AFTER=" frps.service"
  cat > "$FRPS_SERVICE" <<EOF_FRPS_SVC
# Managed-by: cloudfrp-installer
[Unit]
Description=CloudFRP donated node frps
After=network-online.target
Wants=network-online.target
ConditionPathExists=${FRPS_CONFIG}

[Service]
Type=simple
WorkingDirectory=${ETC_DIR}
ExecStart=/usr/local/bin/frps -c ${FRPS_CONFIG}
Restart=always
RestartSec=5
LimitNOFILE=1048576
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF_FRPS_SVC
fi

cat > "$NODE_SERVICE" <<EOF_NODE_SVC
# Managed-by: cloudfrp-installer
[Unit]
Description=CloudFRP donated node client
After=network-online.target${FRPS_AFTER}
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/cloudfrp
EnvironmentFile=${ENV_FILE}
ExecStart=${PYBIN} ${CLIENT_DST} --foreground
Restart=always
RestartSec=10
StartLimitIntervalSec=300
StartLimitBurst=30
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${STATE_DIR}
StateDirectory=cloudfrp
StateDirectoryMode=0700
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX

[Install]
WantedBy=multi-user.target
EOF_NODE_SVC

if [ "$SYSTEMD" -eq 1 ]; then
  systemctl daemon-reload
  if [ "$MANAGE_FRPS" -eq 1 ]; then
    systemctl enable frps.service >/dev/null 2>&1 || true
    systemctl restart frps.service
  fi
  systemctl enable cloudfrp-node.service >/dev/null 2>&1 || true
else
  log "未检测到 systemd，改用后台进程 + cron 开机自启"
  cat > "$RUN_WRAPPER" <<EOF_RUN
#!/bin/sh
set -a
. "$ENV_FILE"
set +a
exec "$PYBIN" "$CLIENT_DST" --daemon
EOF_RUN
  chmod 0700 "$RUN_WRAPPER"
  if command -v crontab >/dev/null 2>&1; then
    { crontab -l 2>/dev/null | grep -v 'cloudfrp-node' || true
      echo "@reboot $RUN_WRAPPER >/dev/null 2>&1"
    } | crontab - 2>/dev/null || warn "写入 cron 自启失败，请在重启后手动运行 $RUN_WRAPPER"
  else
    warn "未检测到 crontab；重启服务器后需手动运行：$RUN_WRAPPER"
  fi
fi

# ── 首次注册验证（打印 Node ID，方便用户确认） ───────────────────────────────
log "验证面板注册..."
set -a
# shellcheck disable=SC1090
. "$ENV_FILE"
set +a
if "$PYBIN" "$CLIENT_DST" --once; then
  log "面板注册验证通过"
else
  warn "首次注册未成功，cloudfrp-node 服务会自动重试（journalctl -u cloudfrp-node -f）"
fi

if [ "$SYSTEMD" -eq 1 ]; then
  systemctl restart cloudfrp-node.service
else
  "$PYBIN" "$CLIENT_DST" --stop >/dev/null 2>&1 || true
  nohup "$RUN_WRAPPER" >/dev/null 2>&1 &
  sleep 1
  "$PYBIN" "$CLIENT_DST" --status || true
fi

# ── 防火墙提示（ufw / firewalld，不存在则静默跳过） ──────────────────────────
if [ "$MANAGE_FRPS" -eq 1 ]; then
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi "Status: active"; then
    ufw allow "${FRPS_PORT}/tcp" >/dev/null 2>&1 || true
    log "已在 ufw 放行 ${FRPS_PORT}/tcp"
  fi
  if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port="${FRPS_PORT}/tcp" >/dev/null 2>&1 || true
    firewall-cmd --reload >/dev/null 2>&1 || true
    log "已在 firewalld 放行 ${FRPS_PORT}/tcp"
  fi
fi

sleep 2
log "完成！当前状态："
if [ "$SYSTEMD" -eq 1 ]; then
  systemctl --no-pager --lines=3 status cloudfrp-node.service || true
  if [ "$MANAGE_FRPS" -eq 1 ]; then
    systemctl --no-pager --lines=3 status frps.service || true
  fi
else
  "$PYBIN" "$CLIENT_DST" --status || true
  if command -v pgrep >/dev/null 2>&1; then pgrep -a frps || true; fi
fi
if [ -f "$STATE_DIR/node.id" ]; then
  log "Node ID: $(cat "$STATE_DIR/node.id")（管理员审核通过后即可被用户选用）"
fi
echo
if [ "$SYSTEMD" -eq 1 ]; then
  echo "日志：journalctl -u cloudfrp-node -f"
else
  echo "日志：tail -f $STATE_DIR/cloudfrp-node.log"
fi
echo "卸载：sudo bash $0 --uninstall"
"""


@bp.route("/api/nodes/donate-install.sh")
@login_required
def donate_install_script():
    """生成捐赠节点一键安装脚本（面板地址/Token/客户端全部内置）。"""
    raw_name = request.args.get("name") or ""
    raw_host = request.args.get("host") or ""
    raw_port = request.args.get("port") or "7000"
    raw_panel = request.args.get("panel") or request.host_url.rstrip("/")

    try:
        name = _validate_name(raw_name)
        host = _validate_host(raw_host)
        port = _validate_port(raw_port)
        panel = _validate_panel(raw_panel)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400

    token = _safe_frp_token(os.environ.get("DEFAULT_AUTH_TOKEN", "yunwang"))
    if token is None:
        return jsonify({
            "success": False,
            "error": "DEFAULT_AUTH_TOKEN 配置包含不安全字符，请检查面板 .env"
        }), 500

    client_py = _load_embedded_client()
    if not client_py.strip():
        return jsonify({
            "success": False,
            "error": "面板缺少内嵌客户端 app/static/client/node_client.py"
        }), 500

    mapping = {
        "PANEL": panel,
        "HOST": host,
        "NAME": name,
        "PORT": str(port),
        "TOKEN": token,
        "CLIENT_PY": client_py,
    }
    placeholder_re = re.compile(r"@@(PANEL|HOST|NAME|PORT|TOKEN|CLIENT_PY)@@")
    script = placeholder_re.sub(lambda m: mapping[m.group(1)], TEMPLATE)

    return Response(script, mimetype="text/x-shellscript", headers={
        "Content-Disposition": 'attachment; filename="cloudfrp-node-install.sh"',
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
    })


@bp.route("/api/nodes/<node_id>/meta", methods=["PUT"])
@admin_required
def update_node_meta(node_id):
    data = request.get_json(silent=True) or {}
    success, message = node_service.update_meta(
        node_id, data.get("description", ""), data.get("allowed_ports", ""),
        session["username"])
    return jsonify({"success": success, "message": message}), (200 if success else 400)


@bp.route("/api/nodes/<node_id>/approve", methods=["PUT"])
@admin_required
def approve_node(node_id):
    data = request.get_json(silent=True) or {}
    approved = bool(data.get("approved", True))
    ok, message = node_service.approve_node(node_id, approved)
    return jsonify({"success": ok, "message": message}), (200 if ok else 404)
