"""Email verification API for high-risk operations."""
import re

from flask import Blueprint, jsonify, request, session

from ..services.user_service import user_service
from ..services import email_service
from .helpers import login_required
from .captcha_api import captcha_ok

bp = Blueprint("api_email", __name__)


@bp.route("/api/email/send-code", methods=["POST"])
@login_required
def send_code():
    data = request.get_json(silent=True) or {}
    if not captcha_ok(data.get("captcha_id")):
        return jsonify({"success": False, "message": "请完成图片验证码"}), 403
    purpose = (data.get("purpose") or "").strip()
    user = user_service.get_by_username(session["username"])
    email = (user.get("email") if user else "") or ""
    ok, message = email_service.issue_code(session["user_id"], purpose, email)
    status = 200 if ok else (503 if not email_service.is_configured() else 400)
    return jsonify({
        "success": ok,
        "message": message,
        "configured": email_service.is_configured(),
        "action": email_service.PURPOSES.get(purpose, ""),
    }), status

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


@bp.route("/api/register/send-code", methods=["POST"])
def register_send_code():
    """注册前向目标邮箱发送验证码（无需登录，账号尚不存在）。"""
    data = request.get_json(silent=True) or request.form or {}
    if not captcha_ok(data.get("captcha_id")):
        return jsonify({"success": False, "message": "请完成图片验证码"}), 403
    email = (data.get("email") or "").strip().lower()
    if not EMAIL_RE.match(email):
        return jsonify({"success": False, "message": "请输入有效的邮箱地址"}), 400
    if user_service.get_by_email(email):
        return jsonify({"success": False, "message": "该邮箱已被注册"}), 400
    ok, message = email_service.issue_code(0, "register", email, target=email)
    status = 200 if ok else (503 if not email_service.is_configured() else 400)
    return jsonify({"success": ok, "message": message,
                    "configured": email_service.is_configured()}), status
