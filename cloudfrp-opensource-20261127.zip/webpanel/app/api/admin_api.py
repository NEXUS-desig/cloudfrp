"""Admin API blueprint: user management."""
import datetime
import glob
import os
import ssl
import time

from flask import Blueprint, request, jsonify, session, send_file

from ..services.user_service import user_service
from ..services.points_service import points_service
from ..services.tunnel_service import tunnel_service
from ..services import backup_service
from .helpers import admin_required, row_to_dict

bp = Blueprint("api_admin", __name__)


def _cert_candidates():
    here = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    root = os.path.dirname(here)
    out = [os.environ.get("CLOUDFRP_CERT_PATH", "")]
    out += sorted(glob.glob(os.path.join(root, "https证书", "*fullchain*.pem")))
    out += sorted(glob.glob(os.path.join(root, "https证书", "*.pem")))
    out += [
        "/etc/letsencrypt/live/panel.example.com/fullchain.pem",
        "/etc/ssl/certs/panel.example.com.pem",
    ]
    return [p for p in out if p and os.path.isfile(p)]


@bp.route("/api/admin/certificate")
@admin_required
def certificate_info():
    paths = _cert_candidates()
    if not paths:
        return jsonify({"found": False, "message": "未找到证书文件（可设置 CLOUDFRP_CERT_PATH）"})
    path = paths[0]
    try:
        info = ssl._ssl._test_decode_cert(path)
        subject = dict(x[0] for x in info.get("subject", ()))
        issuer = dict(x[0] for x in info.get("issuer", ()))
        not_after = info.get("notAfter", "")
        days_left = None
        expired = None
        try:
            exp = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(
                tzinfo=datetime.timezone.utc)
            days_left = (exp - datetime.datetime.now(datetime.timezone.utc)).days
            expired = days_left < 0
        except Exception:
            pass
        key_dir = os.path.dirname(path)
        has_key = any(os.path.isfile(os.path.join(key_dir, name))
                      for name in ("privkey.pem", "private.key", "key.pem"))
        if not has_key:
            try:
                has_key = any(f.lower().endswith(".key") or "private" in f.lower()
                              for f in os.listdir(key_dir))
            except OSError:
                has_key = False
        return jsonify({
            "found": True,
            "path": path,
            "domain": subject.get("commonName", ""),
            "issuer": issuer.get("organizationName") or issuer.get("commonName", ""),
            "not_before": info.get("notBefore", ""),
            "not_after": not_after,
            "days_left": days_left,
            "expired": expired,
            "has_private_key": has_key,
        })
    except Exception as exc:  # noqa: BLE001
        return jsonify({"found": True, "path": path, "error": str(exc),
                        "has_private_key": False})


@bp.route("/api/admin/users")
@admin_required
def get_all_users():
    users = user_service.get_all_users()
    out = []
    for u in users:
        item = row_to_dict(u)
        item["effective_speed"] = user_service.effective_speed(u)
        item["effective_limits"] = user_service.effective_limits(u)
        out.append(item)
    return jsonify({"users": out})


@bp.route("/api/admin/users/<int:user_id>", methods=["DELETE"])
@admin_required
def delete_user(user_id):
    success, message = user_service.delete_user(
        user_id, actor_id=session.get("user_id"), forbid_self=True)
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 400


@bp.route("/api/admin/users/<int:user_id>/password", methods=["PUT"])
@admin_required
def reset_password(user_id):
    data = request.json or {}
    success, message = user_service.reset_password(user_id, data.get("password"))
    if success:
        return jsonify({"success": True, "message": message})
    return jsonify({"error": message}), 400


@bp.route("/api/admin/users/<int:user_id>/tunnels")
@admin_required
def user_tunnels(user_id):
    tunnels = tunnel_service.get_user_tunnels(user_id)
    return jsonify({"tunnels": [row_to_dict(t) for t in tunnels]})


@bp.route("/api/admin/users/<int:user_id>/limits", methods=["PUT"])
@admin_required
def update_limits(user_id):
    data = request.json or {}
    success, message = user_service.update_custom_limits(user_id, data)
    return jsonify({"success": success, "message": message})


@bp.route("/api/admin/users/<int:user_id>/bandwidth", methods=["PUT"])
@admin_required
def update_bandwidth(user_id):
    data = request.json or {}
    success, message = user_service.update_bandwidth(user_id, data.get("limit", 0))
    return jsonify({"success": success, "message": message})


@bp.route("/api/admin/users/<int:user_id>/points", methods=["PUT"])
@admin_required
def update_points(user_id):
    data = request.json or {}
    success, message = points_service.update_user_points(user_id, data.get("points", 0))
    return jsonify({"success": success, "message": message})


@bp.route("/api/admin/users/<int:user_id>/membership", methods=["PUT"])
@admin_required
def update_membership(user_id):
    data = request.json or {}
    success, message = points_service.update_user_membership(
        user_id, data.get("level_id", 0), data.get("days", 30))
    return jsonify({"success": success, "message": message})


# ---------- 容灾备份 ----------

@bp.route("/api/admin/backup/download")
@admin_required
def download_backup():
    try:
        path = backup_service.create_backup("manual")
    except RuntimeError as exc:
        return jsonify({"success": False, "message": str(exc)}), 400
    except Exception as exc:  # noqa: BLE001
        print("[!] 创建备份失败: %s" % exc)
        return jsonify({"success": False, "message": "创建备份失败"}), 500
    return send_file(path, as_attachment=True, download_name=os.path.basename(path))


@bp.route("/api/admin/backup/list")
@admin_required
def backup_list():
    return jsonify({"backups": backup_service.list_backups()})


@bp.route("/api/admin/backup/file/<name>")
@admin_required
def backup_file(name):
    if not name.startswith("cloudfrp-") or not name.endswith(".db") or "/" in name or "\\" in name:
        return jsonify({"success": False, "message": "文件名无效"}), 400
    path = os.path.join(backup_service.BACKUP_DIR, name)
    if not os.path.isfile(path):
        return jsonify({"success": False, "message": "备份不存在"}), 404
    return send_file(path, as_attachment=True, download_name=name)


@bp.route("/api/admin/backup/restore", methods=["POST"])
@admin_required
def restore_backup():
    file = request.files.get("backup")
    if not file or not file.filename:
        return jsonify({"success": False, "message": "请选择备份文件"}), 400
    if not file.filename.lower().endswith(".db"):
        return jsonify({"success": False, "message": "仅支持 .db 备份文件"}), 400
    backup_service.ensure_dir()
    tmp = os.path.join(backup_service.BACKUP_DIR, "upload-%s.db" % int(time.time()))
    file.save(tmp)
    try:
        ok, message = backup_service.validate_backup(tmp)
        if not ok:
            return jsonify({"success": False, "message": message}), 400
        ok, message = backup_service.restore_backup(tmp)
        status = 200 if ok else 500
        return jsonify({"success": ok, "message": message}), status
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
