"""CloudFRP 自研图片验证码：服务端生成 SVG，前端依次点击 3 个字符。

流程：
  1. GET  /api/captcha/new    → {id, svg, target, hint}
  2. POST /api/captcha/verify → {id, picks:[字符索引...]}
  3. 受保护接口携带已验证的 captcha_id，consume_captcha() 一次性消费。
"""
import html
import random
import secrets
import threading
import time

from flask import Blueprint, jsonify, request

bp = Blueprint("api_captcha", __name__)

_TTL = 300
_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_STORE = {}
_LOCK = threading.Lock()


def _cleanup():
    now = time.time()
    with _LOCK:
        for key in [k for k, v in _STORE.items() if v.get("expires", 0) < now]:
            _STORE.pop(key, None)


def _svg(chars):
    width, height = 280, 96
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" '
        'class="cf-cap-svg" role="img" aria-label="CloudFRP 图片验证码">' % (width, height),
        '<rect width="%d" height="%d" fill="#eef3f1"/>' % (width, height),
    ]
    for _ in range(6):
        parts.append(
            '<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#c7d6d2" stroke-width="1"/>'
            % (random.randint(0, width), random.randint(0, height),
               random.randint(0, width), random.randint(0, height)))
    slot = (width - 40) / max(1, len(chars))
    for i, ch in enumerate(chars):
        # 排列成整齐一行，只保留轻微抖动，避免字符看起来“错位”
        x = 20 + slot * i + slot / 2
        y = height // 2 + random.randint(-3, 3)
        rot = random.randint(-6, 6)
        parts.append(
            '<g data-i="%d" class="cf-cap-char" style="cursor:pointer">'
            '<text x="%d" y="%d" transform="rotate(%d %d %d)" text-anchor="middle" '
            'dominant-baseline="middle" font-family="ui-monospace,Consolas,monospace" '
            'font-size="%d" font-weight="700" fill="#0b3a40">%s</text></g>'
            % (i, x, y, rot, x, y, random.randint(32, 36), html.escape(ch)))
    parts.append("</svg>")
    return "".join(parts)


@bp.route("/api/captcha/new")
def new_captcha():
    _cleanup()
    chars = random.sample(_CHARS, 7)
    indexes = sorted(random.sample(range(7), 3))
    target = [chars[i] for i in indexes]
    cid = secrets.token_urlsafe(18)
    with _LOCK:
        if len(_STORE) > 2000:
            for key in sorted(_STORE, key=lambda k: _STORE[k].get("expires", 0))[:1000]:
                _STORE.pop(key, None)
        _STORE[cid] = {
            "indexes": indexes,
            "target": target,
            "expires": time.time() + _TTL,
            "verified": False,
            "attempts": 0,
        }
    return jsonify({
        "id": cid,
        "svg": _svg(chars),
        "target": target,
        "hint": "请依次点击：" + " → ".join(target),
        "ttl": _TTL,
    })


@bp.route("/api/captcha/verify", methods=["POST"])
def verify_captcha():
    data = request.get_json(silent=True) or {}
    cid = str(data.get("id") or "")
    raw_picks = data.get("picks") or []
    with _LOCK:
        entry = _STORE.get(cid)
        if not entry:
            return jsonify({"success": False, "message": "验证码已过期，请刷新"}), 400
        if entry["expires"] < time.time():
            _STORE.pop(cid, None)
            return jsonify({"success": False, "message": "验证码已过期，请刷新"}), 400
        if entry["attempts"] >= 5:
            _STORE.pop(cid, None)
            return jsonify({"success": False, "message": "尝试次数过多，请刷新验证码"}), 400
        entry["attempts"] += 1
        try:
            picks = [int(x) for x in raw_picks]
        except (TypeError, ValueError):
            picks = []
        if picks == entry["indexes"]:
            entry["verified"] = True
            return jsonify({"success": True})
        return jsonify({"success": False, "message": "点击顺序不正确，请重试"}), 400


def client_bypass():
    """启动器/测试客户端携带 X-CloudFRP-Client: launcher 时免图片验证码。"""
    return (request.headers.get("X-CloudFRP-Client") or "").lower() == "launcher"


def captcha_ok(cid):
    return client_bypass() or consume_captcha(cid)


def consume_captcha(cid):
    """一次性消费已验证的验证码；成功返回 True。"""
    cid = str(cid or "")
    if not cid:
        return False
    with _LOCK:
        entry = _STORE.pop(cid, None)
    return bool(entry and entry.get("verified") and entry.get("expires", 0) >= time.time())
