"""FRP server control API blueprint (cross-platform via frps_service)."""
from flask import Blueprint, jsonify

from ..services.frps_service import is_frps_running, start_frps, stop_frps
from .helpers import login_required

bp = Blueprint("api_frps", __name__)


@bp.route("/api/frps/status")
@login_required
def frps_status():
    return jsonify({"running": is_frps_running()})


@bp.route("/api/server/status")
@login_required
def server_status():
    return jsonify({"running": is_frps_running(), "port": 7000})


@bp.route("/api/frps/start", methods=["POST"])
@login_required
def start():
    success, message = start_frps()
    return jsonify({"success": success, "message": message})


@bp.route("/api/frps/stop", methods=["POST"])
@login_required
def stop():
    success, message = stop_frps()
    return jsonify({"success": success, "message": message})
