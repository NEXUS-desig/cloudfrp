"""Public health endpoint (used by the donation installer to verify the panel URL)."""
import os
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request, request

bp = Blueprint("api_health", __name__)

PANEL_VERSION = os.environ.get("CLOUDFRP_VERSION", "1.1.0")


@bp.route("/api/health", methods=["GET"])
def health():
    """轻量、无认证、无数据库依赖的健康检查。

    返回：{"ok": true, "version": "...", "time": "<UTC ISO8601>"}
    """
    resp = jsonify({
        "ok": True,
        "version": PANEL_VERSION,
        "time": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "scheme": request.scheme,
        "host": request.host,
    })
    resp.headers["Cache-Control"] = "no-store"
    return resp
