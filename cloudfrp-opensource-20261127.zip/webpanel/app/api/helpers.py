"""Blueprint helpers: auth decorators and row serialization."""
from functools import wraps

from flask import jsonify, session


def json_error(message, status):
    """统一的 JSON 错误响应（401/403 等）。"""
    return jsonify({"error": message}), status


def login_required(f):
    """Require a logged-in session."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "username" not in session:
            return json_error("未登录", 401)
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    """Require the session to belong to an administrator (users.role)."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "username" not in session:
            return json_error("未登录", 401)
        from ..services.user_service import user_service
        if not user_service.is_admin(session["username"]):
            return json_error("权限不足", 403)
        return f(*args, **kwargs)
    return wrapper


def row_to_dict(row):
    """Convert a DB row (sqlite Row / dict / object) into a plain dict."""
    if row is None:
        return None
    if hasattr(row, "keys"):
        return {k: row[k] for k in row.keys()}
    return dict(row)
