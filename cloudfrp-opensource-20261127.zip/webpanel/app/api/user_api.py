"""User account API blueprint."""
from flask import Blueprint, request, jsonify, session

from ..services.user_service import user_service
from ..services import email_service
from ..services.tunnel_service import tunnel_service
from .helpers import login_required, row_to_dict

bp = Blueprint("api_user", __name__)


@bp.route("/api/check-username")
def check_username():
    user = user_service.get_by_username(request.args.get("username"))
    return jsonify({"exists": user is not None})


@bp.route("/api/check-email")
def check_email():
    user = user_service.get_by_email(request.args.get("email"))
    return jsonify({"exists": user is not None})


@bp.route("/api/user-info")
@login_required
def user_info():
    user = user_service.get_by_username(session["username"])
    try:
        tunnel_count = len(tunnel_service.get_user_tunnels(user["id"]))
    except Exception:
        tunnel_count = 0
    return jsonify({
        "username": user["username"],
        "email": user.get("email", ""),
        "token": user.get("token", ""),
        "points": user.get("points", 0) or 0,
        "membership_level": user.get("membership_level", 0) or 0,
        "membership_expiry": user.get("membership_expiry", ""),
        "created_at": user.get("created_at", ""),
        "tunnel_count": tunnel_count,
        "role": (user.get("role") if hasattr(user, "get") else None) or ("admin" if user["username"] == "admin" else "user"),
        "qq": user.get("qq", ""),
        "avatar_url": user.get("avatar_url", ""),
        "bandwidth_limit": user.get("bandwidth_limit", 0) or 0,
        "speed_limit": user_service.effective_speed(user),
        "limits": user_service.effective_limits(user),
    })


@bp.route("/api/regenerate-token", methods=["POST"])
@login_required
def regenerate_token():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "regenerate_token", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    new_token = user_service.regenerate_token(session["username"])
    return jsonify({"success": True, "token": new_token})


@bp.route("/api/update-password", methods=["POST"])
@login_required
def update_password():
    data = request.json or {}
    success, message = user_service.update_password(
        session["username"], data.get("current_password"), data.get("new_password"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-email", methods=["POST"])
@login_required
def update_email():
    data = request.json or {}
    success, message = user_service.update_email(session["username"], data.get("email"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-username", methods=["POST"])
@login_required
def update_username():
    data = request.json or {}
    success, message = user_service.update_username(session["user_id"], data.get("username"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-qq", methods=["POST"])
@login_required
def update_qq():
    data = request.json or {}
    success, message = user_service.update_qq(session["user_id"], data.get("qq"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-avatar", methods=["POST"])
@login_required
def update_avatar():
    data = request.json or {}
    success, message = user_service.update_avatar(session["user_id"], data.get("avatar_url"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/delete-account", methods=["POST"])
@login_required
def delete_account():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "delete_account", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    success, message = user_service.delete_user(session["user_id"])
    if success:
        session.clear()
    return jsonify({"success": success, "message": message})


@bp.route("/api/stop-all-tunnels", methods=["POST"])
@login_required
def stop_all_tunnels():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "stop_all_tunnels", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    tunnel_service.stop_all(session["user_id"])
    return jsonify({"success": True, "message": "所有隧道已停止"})
