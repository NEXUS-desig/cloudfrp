"""User account API blueprint."""
import io
import os
import time

from flask import Blueprint, request, jsonify, session
from PIL import Image, ImageOps

from ..services.user_service import user_service
from ..services import email_service
from ..services.tunnel_service import tunnel_service
from .helpers import login_required, row_to_dict

bp = Blueprint("api_user", __name__)


@bp.route("/api/check-username")
def check_username():
    user = user_service.get_by_username(request.args.get("username"))
    return jsonify({"exists": user is not None})


@bp.route("/api/check-email")
def check_email():
    user = user_service.get_by_email(request.args.get("email"))
    return jsonify({"exists": user is not None})


@bp.route("/api/user-info")
@login_required
def user_info():
    user = user_service.get_by_username(session["username"])
    try:
        tunnel_count = len(tunnel_service.get_user_tunnels(user["id"]))
    except Exception:
        tunnel_count = 0
    return jsonify({
        "username": user["username"],
        "email": user.get("email", ""),
        "token": user.get("token", ""),
        "points": user.get("points", 0) or 0,
        "membership_level": user.get("membership_level", 0) or 0,
        "membership_expiry": user.get("membership_expiry", ""),
        "created_at": user.get("created_at", ""),
        "tunnel_count": tunnel_count,
        "role": (user.get("role") if hasattr(user, "get") else None) or ("admin" if user["username"] == "admin" else "user"),
        "qq": user.get("qq", ""),
        "avatar_url": user.get("avatar_url", ""),
        "background_url": user.get("background_url", ""),
        "bandwidth_limit": user.get("bandwidth_limit", 0) or 0,
        "speed_limit": user_service.effective_speed(user),
        "limits": user_service.effective_limits(user),
    })


@bp.route("/api/regenerate-token", methods=["POST"])
@login_required
def regenerate_token():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "regenerate_token", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    new_token = user_service.regenerate_token(session["username"])
    return jsonify({"success": True, "token": new_token})


@bp.route("/api/update-password", methods=["POST"])
@login_required
def update_password():
    data = request.json or {}
    success, message = user_service.update_password(
        session["username"], data.get("current_password"), data.get("new_password"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-email", methods=["POST"])
@login_required
def update_email():
    data = request.json or {}
    password = data.get("current_password") or ""
    if not password:
        return jsonify({"success": False, "message": "请输入当前密码"}), 403
    ok, _user = user_service.login(session["username"], password)
    if not ok:
        return jsonify({"success": False, "message": "当前密码错误"}), 403
    success, message = user_service.update_email(session["username"], data.get("email"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-username", methods=["POST"])
@login_required
def update_username():
    data = request.json or {}
    success, message = user_service.update_username(session["user_id"], data.get("username"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/update-qq", methods=["POST"])
@login_required
def update_qq():
    data = request.json or {}
    success, message = user_service.update_qq(session["user_id"], data.get("qq"))
    return jsonify({"success": success, "message": message})


_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_AVATAR_DIR = os.path.join(_APP_DIR, "static", "uploads", "avatars")
_AVATAR_MAX_BYTES = 3 * 1024 * 1024
_AVATAR_SIZE = 256
_MAX_IMAGE_PIXELS = 40_000_000
_BG_DIR = os.path.join(_APP_DIR, "static", "uploads", "backgrounds")
_BG_MAX_BYTES = 8 * 1024 * 1024
_BG_MAX_SIZE = (1920, 1080)


@bp.route("/api/avatar/upload", methods=["POST"])
@login_required
def upload_avatar():
    file = request.files.get("avatar")
    if not file or not file.filename:
        return jsonify({"success": False, "message": "请选择图片文件"}), 400
    raw = file.read(_AVATAR_MAX_BYTES + 1)
    if len(raw) > _AVATAR_MAX_BYTES:
        return jsonify({"success": False, "message": "图片不能超过 3MB"}), 413
    try:
        probe = Image.open(io.BytesIO(raw))
        if probe.width * probe.height > _MAX_IMAGE_PIXELS:
            return jsonify({"success": False, "message": "图片尺寸过大"}), 400
        probe.verify()
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img)
        if img.width > 8000 or img.height > 8000:
            return jsonify({"success": False, "message": "图片尺寸过大"}), 400
        img = ImageOps.fit(img.convert("RGBA"), (_AVATAR_SIZE, _AVATAR_SIZE),
                           Image.LANCZOS, centering=(0.5, 0.5))
    except Exception:
        return jsonify({"success": False, "message": "不是有效的图片文件"}), 400
    try:
        os.makedirs(_AVATAR_DIR, exist_ok=True)
        filename = "u%d.png" % int(session["user_id"])
        img.save(os.path.join(_AVATAR_DIR, filename), format="PNG", optimize=True)
    except OSError:
        return jsonify({"success": False, "message": "头像保存失败"}), 500
    url = "/static/uploads/avatars/%s?v=%d" % (filename, int(time.time()))
    try:
        user_service.update_avatar(session["user_id"], url)
    except Exception as exc:  # noqa: BLE001
        print("[!] 头像写入数据库失败: %s" % exc)
        return jsonify({"success": False, "message": "头像保存失败，请检查数据库字段"}), 500
    return jsonify({"success": True, "avatar_url": url})


@bp.route("/api/background/upload", methods=["POST"])
@login_required
def upload_background():
    file = request.files.get("background")
    if not file or not file.filename:
        return jsonify({"success": False, "message": "请选择图片文件"}), 400
    raw = file.read(_BG_MAX_BYTES + 1)
    if len(raw) > _BG_MAX_BYTES:
        return jsonify({"success": False, "message": "图片不能超过 8MB"}), 413
    try:
        probe = Image.open(io.BytesIO(raw))
        if probe.width * probe.height > _MAX_IMAGE_PIXELS:
            return jsonify({"success": False, "message": "图片尺寸过大"}), 400
        probe.verify()
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img).convert("RGB")
        img.thumbnail(_BG_MAX_SIZE, Image.LANCZOS)
    except Exception:
        return jsonify({"success": False, "message": "不是有效的图片文件"}), 400
    try:
        os.makedirs(_BG_DIR, exist_ok=True)
        filename = "u%d.jpg" % int(session["user_id"])
        img.save(os.path.join(_BG_DIR, filename), format="JPEG", quality=85, optimize=True)
    except OSError:
        return jsonify({"success": False, "message": "背景图保存失败"}), 500
    url = "/static/uploads/backgrounds/%s?v=%d" % (filename, int(time.time()))
    try:
        user_service.update_background(session["user_id"], url)
    except Exception as exc:  # noqa: BLE001
        print("[!] 背景图写入数据库失败: %s" % exc)
        return jsonify({"success": False, "message": "背景图保存失败，请检查数据库字段"}), 500
    return jsonify({"success": True, "background_url": url})


@bp.route("/api/background/remove", methods=["POST"])
@login_required
def remove_background():
    user_service.update_background(session["user_id"], "")
    path = os.path.join(_BG_DIR, "u%d.jpg" % int(session["user_id"]))
    try:
        if os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass
    return jsonify({"success": True})


@bp.route("/api/update-avatar", methods=["POST"])
@login_required
def update_avatar():
    data = request.json or {}
    success, message = user_service.update_avatar(session["user_id"], data.get("avatar_url"))
    return jsonify({"success": success, "message": message})


@bp.route("/api/delete-account", methods=["POST"])
@login_required
def delete_account():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "delete_account", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    success, message = user_service.delete_user(session["user_id"])
    if success:
        session.clear()
    return jsonify({"success": success, "message": message})


@bp.route("/api/stop-all-tunnels", methods=["POST"])
@login_required
def stop_all_tunnels():
    data = request.json or {}
    ok, msg = email_service.consume_code(session["user_id"], "stop_all_tunnels", data.get("email_code", ""))
    if not ok:
        return jsonify({"error": msg, "code": "EMAIL_CODE_REQUIRED"}), 403
    tunnel_service.stop_all(session["user_id"])
    return jsonify({"success": True, "message": "所有隧道已停止"})
