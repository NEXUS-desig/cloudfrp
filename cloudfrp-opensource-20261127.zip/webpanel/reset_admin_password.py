"""重置任意账号的密码（运维用）。

用法：
    python reset_admin_password.py                # 交互式，默认账号 admin
    python reset_admin_password.py <username>
    python reset_admin_password.py <username> <new_password>

需在 webpanel 目录下运行（读取 .env 与 frp_panel.db）。
"""
import getpass
import sys

from app.database import db
from app.services.user_service import user_service


def main() -> int:
    username = sys.argv[1] if len(sys.argv) > 1 else "admin"

    if len(sys.argv) > 2:
        new = sys.argv[2]
    elif sys.stdin.isatty():
        new = getpass.getpass(f"新密码（账号 {username}）：")
        if new != getpass.getpass("再输一次："):
            print("两次输入不一致")
            return 1
    else:
        print("用法：python reset_admin_password.py <username> <new_password>")
        return 2

    user = user_service.get_by_username(username)
    if not user:
        print(f"账号不存在：{username}")
        return 1
    ok, msg = user_service.reset_password(user["id"], new)
    print(msg if ok else f"失败：{msg}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
