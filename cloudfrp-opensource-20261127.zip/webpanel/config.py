"""
配置文件 - 集中管理所有配置项
"""
import os
from dotenv import load_dotenv

# 加载 .env 文件
env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
load_dotenv(env_path)


class Config:
    """应用配置类"""
    
    # Flask 配置
    SECRET_KEY = os.environ.get('SECRET_KEY', '')
    if not SECRET_KEY or SECRET_KEY == 'your_secret_key_here':
        import secrets
        SECRET_KEY = secrets.token_hex(32)
    
    PERMANENT_SESSION_LIFETIME = 30 * 24 * 60 * 60  # 30天
    
    # 数据库配置
    USE_MYSQL = os.environ.get('USE_MYSQL', 'false').lower() == 'true'
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = int(os.environ.get('DB_PORT', '3306'))
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
    DB_NAME = os.environ.get('DB_NAME', 'frp_panel')
    
    # SQLite 配置
    SQLITE_DB_PATH = os.path.join(os.path.dirname(__file__), 'frp_panel.db')
    
    # FRP 默认配置
    DEFAULT_AUTH_TOKEN = os.environ.get('DEFAULT_AUTH_TOKEN', 'yunwang')
    DEFAULT_SERVER_PORT = int(os.environ.get('DEFAULT_SERVER_PORT', '7000'))
    DEFAULT_DASHBOARD_PORT = int(os.environ.get('DEFAULT_DASHBOARD_PORT', '7500'))
    
    # 面板配置
    PANEL_PORT = int(os.environ.get('PANEL_PORT', '3592'))
    PANEL_HOST = os.environ.get('PANEL_HOST', '0.0.0.0')
    DEBUG = os.environ.get('DEBUG', 'false').lower() == 'true'
    
    # 日志配置
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_DIR = os.path.join(os.path.dirname(__file__), 'logs')


# 全局配置实例
config = Config()
