@echo off
chcp 936
echo 当前目录: %CD%
echo 脚本目录: %~dp0
cd /d "%~dp0"
echo 切换后目录: %CD%
echo.
echo 检查 Python:
python --version
echo Python 退出码: %errorlevel%
echo.
echo 检查 Flask:
pip show flask
echo Flask 退出码: %errorlevel%
echo.
echo 检查文件存在:
if exist app.py (echo app.py 存在) else (echo app.py 不存在)
echo.
echo 尝试运行:
python app.py
pause
